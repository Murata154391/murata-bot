// ════════════════════════════════════════
//   📊 MURATA STATS - VERIFIED SYSTEM
// ════════════════════════════════════════

import fs from 'fs'
import path from 'path'
import os from 'os'

let handler = async (m, { conn, isROwner, isOwner }) => {

  // ── للمالك فقط ──
  if (!isROwner) {
    return m.reply(
      `*〄━═─━━⌬《•🌗•》⌬━━─═━〄*\n  ┊ׁ۪❈ֺ۪┊ִׁ✧ هـذا الأمـر مخصص لـلمـالـك فقط ✧\n*〄━═─━━⌬《•🌗•》⌬━━─═━〄*`
    )
  }

  await m.react('📊')

  // ── وقت التشغيل ──
  const uptime = process.uptime()
  const days   = Math.floor(uptime / 86400)
  const hours  = Math.floor((uptime % 86400) / 3600)
  const mins   = Math.floor((uptime % 3600) / 60)
  const secs   = Math.floor(uptime % 60)
  const uptimeStr = `${days > 0 ? days + 'ي ' : ''}${hours}س ${mins}د ${secs}ث`

  // ── الذاكرة ──
  const mem      = process.memoryUsage()
  const heapUsed = (mem.heapUsed / 1024 / 1024).toFixed(1)
  const heapTotal= (mem.heapTotal / 1024 / 1024).toFixed(1)
  const rss      = (mem.rss / 1024 / 1024).toFixed(1)
  const totalRam = (os.totalmem() / 1024 / 1024 / 1024).toFixed(1)
  const freeRam  = (os.freemem()  / 1024 / 1024 / 1024).toFixed(1)
  const usedRam  = (totalRam - freeRam).toFixed(1)

  // ── المعالج ──
  const cpus    = os.cpus()
  const cpuName = cpus[0]?.model?.split(' ').slice(0,3).join(' ') || 'Unknown'
  const cpuLoad = (os.loadavg()[0] * 100 / cpus.length).toFixed(1)

  // ── عدد البلوجنات والأوامر ──
  const pluginCount   = Object.keys(global.plugins || {}).length
  let   commandCount  = 0
  try {
    commandCount = Object.values(global.plugins || {})
      .filter(p => p?.command).length
  } catch (e) {}

  // ── إحصائيات قاعدة البيانات ──
  const db         = global.db?.data || {}
  const totalUsers = Object.keys(db.users  || {}).length
  const totalChats = Object.keys(db.chats  || {}).length
  const premUsers  = Object.values(db.users || {}).filter(u => u?.premiumTime > 0).length
  const bannedUsers= Object.values(db.users || {}).filter(u => u?.banned).length
  const regUsers   = Object.values(db.users || {}).filter(u => u?.registered).length

  // ── إحصائيات الأوامر ──
  const stats     = db.stats || {}
  const statsList = Object.entries(stats)
    .sort((a, b) => (b[1].total || 0) - (a[1].total || 0))
    .slice(0, 5)
  const topCmds   = statsList.length > 0
    ? statsList.map(([name, s], i) =>
        `  ${['🥇','🥈','🥉','4️⃣','5️⃣'][i]} \`${name.replace('.js','')}\` ┄ *${s.total}* مرة`
      ).join('\n')
    : '  لا توجد إحصائيات بعد'

  // ── معلومات البوت ──
  const botNumber = conn.user?.id?.split(':')[0] || 'غير معروف'
  const botName   = global.namebot || '🦅 MURATA BOT'
  const platform  = conn.authState?.creds?.platform || 'standard'
  const version   = global.vs || '1.0.0'

  // ── الجروبات والخاص ──
  let groupCount = 0, privateCount = 0
  try {
    const chats = Object.keys(db.chats || {})
    groupCount   = chats.filter(c => c.endsWith('@g.us')).length
    privateCount = chats.filter(c => c.endsWith('@s.whatsapp.net')).length
  } catch (e) {}

  const text = `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*
*⃝🦅┆📊 إحـصـائـيـات ${botName}*
*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*

*⃝🤖┆مـعـلـومـات الـبـوت:*
┌───────────────┈
│⃝🦅 الـرقـم: \`${botNumber}\`
│⃝🌙 الـمـنـصـة: \`${platform}\`
│⃝🦅 الإصـدار: \`v${version}\`
│⃝🌙 وقـت الـتـشـغـيـل: \`${uptimeStr}\`
│⃝🦅 الـبـلـوجـنـات: \`${pluginCount}\` | الأوامـر: \`${commandCount}\`
└───────────────┈

*⃝💾┆الـذاكـرة والـمـعـالـج:*
┌───────────────┈
│⃝🦅 الـهـيـب: \`${heapUsed}/${heapTotal} MB\`
│⃝🌙 الـرام: \`${usedRam}/${totalRam} GB\`
│⃝🦅 RSS: \`${rss} MB\`
│⃝🌙 حـمـل الـمـعـالـج: \`${cpuLoad}%\`
│⃝🦅 الـمـعـالـج: \`${cpuName}\`
└───────────────┈

*⃝👥┆إحـصـائـيـات الـمـسـتـخـدمـيـن:*
┌───────────────┈
│⃝🦅 الإجـمـالـي: \`${totalUsers}\`
│⃝🌙 مـسـجـلـيـن: \`${regUsers}\`
│⃝🦅 VIP: \`${premUsers}\`
│⃝🌙 مـحـظـوريـن: \`${bannedUsers}\`
└───────────────┈

*⃝💬┆إحـصـائـيـات الـمـحـادثـات:*
┌───────────────┈
│⃝🦅 الـجـروبـات: \`${groupCount}\`
│⃝🌙 الـخـاص: \`${privateCount}\`
│⃝🦅 الإجـمـالـي: \`${totalChats}\`
└───────────────┈

*⃝🏆┆أكـثـر الأوامـر اسـتـخـدامـاً:*
${topCmds}

*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*
 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙`

  await conn.sendMessage(m.chat, {
    text,
    contextInfo: {
      forwardedNewsletterMessageInfo: {
        newsletterJid:  global.ch?.ch1 || '120363423359642420@newsletter',
        newsletterName: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑽𝑬𝑹𝑰𝑭𝑰𝑬𝑫 𝑺𝒀𝑺𝑻𝑬𝑴'
      },
      isForwarded: true,
      forwardingScore: 9999
    }
  }, { quoted: m })

  await m.react('✅')
}

handler.command  = /^احصائيات|إحصائيات|stats$/i
handler.rowner   = true
handler.tags     = ['owner']
export default handler
