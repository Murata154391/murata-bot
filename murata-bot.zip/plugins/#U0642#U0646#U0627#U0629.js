import { generateWAMessageFromContent, generateWAMessageContent } from '@whiskeysockets/baileys'
import { createRequire } from 'module'
const require = createRequire(import.meta.url)
const yts = require('yt-search')

// ── جلسات الانتظار ──
const waitingSessions = new Map()

let handler = async (m, { conn, text, usedPrefix, command }) => {

  // ── فحص الجلسة ──
  const session = waitingSessions.get(m.sender)
  if (session && m.text && !m.text.startsWith(usedPrefix)) {
    waitingSessions.delete(m.sender)
    await doYoutubeSearch(conn, m, m.text, usedPrefix)
    return
  }

  // ── قائمة رئيسية ──
  if (!text) {
    const interactiveMessage = {
      body: { text: `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🎬┆مـرحـبـاً فـي بـحـث اليـوتـيـوب*\n*⃝🦅┆ابحث عن أي قناة أو فيديو*\n*⃝🌙┆مثال: ${usedPrefix}قناة حسنين*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*` },
      footer: { text: '🦅 𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻' },
      header: { hasMediaAttachment: false },
      nativeFlowMessage: {
        buttons: [{
          name: 'single_select',
          buttonParamsJson: JSON.stringify({
            title: '🎬 اختر نوع البحث',
            sections: [{
              title: '🔍 أنواع البحث',
              rows: [
                { title: '📺 بحث عن قناة',      description: 'ابحث عن قناة يوتيوب',         id: `${usedPrefix}قناة _قناة` },
                { title: '🎬 بحث عن فيديو',     description: 'ابحث عن فيديو معين',          id: `${usedPrefix}قناة _فيديو` },
                { title: '🎵 بحث عن أغنية',     description: 'ابحث عن أغنية أو موسيقى',     id: `${usedPrefix}قناة _اغنية` },
                { title: '⚽ بحث رياضي',        description: 'أهداف ومباريات',               id: `${usedPrefix}قناة _رياضة` },
                { title: '🎮 بحث ألعاب',        description: 'فيديوهات ألعاب',               id: `${usedPrefix}قناة _العاب` },
                { title: '📰 بحث أخبار',        description: 'آخر الأخبار',                  id: `${usedPrefix}قناة _اخبار` },
              ]
            }]
          })
        }]
      }
    }
    const msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: { message: { interactiveMessage } }
    }, { userJid: conn.user.jid, quoted: m })
    return conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
  }

  // ── اختار نوع ← ينتظر الإدخال ──
  const typeMap = {
    '_قناة':   { msg: '📺 *اكتب اسم القناة التي تريد البحث عنها:*\nمثال: حسنين / MrBeast / قناة العربية', prefix: '' },
    '_فيديو':  { msg: '🎬 *اكتب عنوان الفيديو الذي تريد البحث عنه:*\nمثال: أفضل لحظات 2024', prefix: '' },
    '_اغنية':  { msg: '🎵 *اكتب اسم الأغنية أو الفنان:*\nمثال: ماهر زين / عمر خالد', prefix: 'music' },
    '_رياضة':  { msg: '⚽ *اكتب اسم الفريق أو اللاعب:*\nمثال: رونالدو / ريال مدريد / ملخص مباراة', prefix: 'sports goals' },
    '_العاب':  { msg: '🎮 *اكتب اسم اللعبة:*\nمثال: فورتنايت / ماينكرافت / GTA', prefix: 'gameplay' },
    '_اخبار':  { msg: '📰 *اكتب موضوع الأخبار:*\nمثال: أخبار السعودية / عاجل', prefix: 'news' },
  }

  if (typeMap[text]) {
    const t = typeMap[text]
    waitingSessions.set(m.sender, { prefix: t.prefix })
    setTimeout(() => waitingSessions.delete(m.sender), 60000)
    await m.react('⏳')
    return conn.reply(m.chat,
      `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🦅┆${t.msg}*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`, m
    )
  }

  // ── بحث مباشر ──
  await doYoutubeSearch(conn, m, text, usedPrefix)
}

// ── دالة الجلسة عند الرد ──
handler.all = async function (m) {
  const session = waitingSessions.get(m.sender)
  if (!session) return
  if (!m.text || m.text.startsWith('.')) return
  waitingSessions.delete(m.sender)
  const searchText = session.prefix ? `${m.text} ${session.prefix}` : m.text
  await doYoutubeSearch(this, m, searchText, '.')
}

// ── دالة البحث ──
async function doYoutubeSearch(conn, m, input, usedPrefix) {
  await m.react('🎬')

  const groupName = m.isGroup
    ? (await conn.groupMetadata(m.chat).catch(() => null))?.subject || '𝑴𝑼𝑹𝑨𝑻𝑨'
    : '𝑴𝑼𝑹𝑨𝑻𝑨 𝑺𝒀𝑺𝑻𝑬𝑴'
  const fkontak = {
    key: { fromMe: false, participant: '0@s.whatsapp.net', remoteJid: m.chat },
    message: {
      contactMessage: {
        displayName: groupName,
        vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:${groupName}\nORG:𝑴𝑼𝑹𝑨𝑻𝑨 𝑺𝒀𝑺𝑻𝑬𝑴;\nTEL;type=CELL;type=VOICE;waid=${m.chat.split('@')[0]}:+${m.chat.split('@')[0]}\nEND:VCARD`
      }
    }
  }

  // ── رسالة انتظار ──
  const waitingMsg = generateWAMessageFromContent(m.chat, {
    extendedTextMessage: {
      text: `> ⏳ *جـاري الـبـحـث فـي الـيـوتـيـوب عـن:* ${input} ...`,
      contextInfo: {
        forwardedNewsletterMessageInfo: { newsletterJid: '120363423359642420@newsletter', newsletterName: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑽𝑬𝑹𝑰𝑭𝑰𝑬𝑫 𝑺𝒀𝑺𝑻𝑬𝑴' },
        isForwarded: true, quotedMessage: fkontak.message, participant: '0@s.whatsapp.net'
      }
    }
  }, { quoted: fkontak })
  await conn.relayMessage(m.chat, waitingMsg.message, { messageId: waitingMsg.key.id })

  try {
    const search = await yts(input)
    const videos = search.videos.slice(0, 6)

    if (!videos?.length) {
      await m.react('❌')
      return conn.reply(m.chat,
        `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🦅┆❌ مـا لـقـيـنـا نـتـائـج لـ: 「 ${input} 」*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`, m
      )
    }

    const cards = []
    for (const video of videos) {
      try {
        const { imageMessage } = await generateWAMessageContent(
          { image: { url: video.thumbnail } },
          { upload: conn.waUploadToServer }
        )
        cards.push({
          body:   { text: `🎬 *${video.title}*\n\n⏱️ *المدة:* ${video.timestamp}\n📅 *نُشر:* ${video.ago}\n👀 *المشاهدات:* ${video.views}` },
          header: { hasMediaAttachment: true, imageMessage },
          nativeFlowMessage: {
            buttons: [
              { name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: '🎥 مـشـاهـدة الـمـقـطـع', url: video.url }) },
              { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🎵 تحميل صوت', id: `${usedPrefix}اغنيه ${video.url}` }) }
            ]
          }
        })
      } catch { continue }
    }

    if (!cards.length) {
      await m.react('❌')
      return conn.reply(m.chat, `*⃝🦅┆⚠️ فـشـل تـحـمـيـل الـنـتـائـج، حـاول مـرة ثـانـيـة*`, m)
    }

    const finalMessage = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: `> 🔎 *نـتـائـج بـحـث الـيـوتـيـوب بـواسـطـة مُـوراتـا 🦅*` },
            carouselMessage: { cards },
            contextInfo: {
              forwardedNewsletterMessageInfo: { newsletterJid: '120363423359642420@newsletter', newsletterName: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑽𝑬𝑹𝑰𝑭𝑰𝑬𝑫 𝑺𝒀𝑺𝑻𝑬𝑴' },
              isForwarded: true, quotedMessage: fkontak.message, participant: '0@s.whatsapp.net'
            }
          }
        }
      }
    }, { quoted: fkontak })
    await conn.relayMessage(m.chat, finalMessage.message, { messageId: finalMessage.key.id })

    // ── أزرار بعد النتائج ──
    const moreMsg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: { message: { interactiveMessage: {
        body:   { text: `*⃝🦅┆هـل تـريـد الـمـزيـد؟*` },
        footer: { text: '🦅 𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻' },
        header: { hasMediaAttachment: false },
        nativeFlowMessage: { buttons: [
          { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🔄 نتائج أخرى', id: `${usedPrefix}قناة ${input}` }) },
          { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🔍 بحث جديد', id: `${usedPrefix}قناة` }) },
        ]}
      }}}
    }, { userJid: conn.user.jid, quoted: m })
    await conn.relayMessage(m.chat, moreMsg.message, { messageId: moreMsg.key.id })
    await m.react('✅')

  } catch (err) {
    console.log('YouTube Error:', err)
    await m.react('❌')
    return conn.reply(m.chat, `*⃝🦅┆⚠️ حـدث خـطـأ، حـاول مـرة ثـانـيـة*`, m)
  }
}

handler.command = /^قناة|يوتيوب|yt$/i
handler.tags    = ['downloader']
handler.help    = ['قناة']
export default handler