import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

const timeout = 60000;

const players = [
    { name: 'Cristiano Ronaldo', img: 'https://img.a.transfermarkt.technology/portrait/big/8198-1682683695.jpg' },
    { name: 'Lionel Messi', img: 'https://img.a.transfermarkt.technology/portrait/big/28003-1698332964.jpg' },
    { name: 'Kylian Mbappé', img: 'https://img.a.transfermarkt.technology/portrait/big/342229-1701698933.jpg' },
    { name: 'Erling Haaland', img: 'https://img.a.transfermarkt.technology/portrait/big/418560-1681821400.jpg' },
    { name: 'Vinicius Jr', img: 'https://img.a.transfermarkt.technology/portrait/big/371998-1699455082.jpg' },
    { name: 'Jude Bellingham', img: 'https://img.a.transfermarkt.technology/portrait/big/581678-1699879685.jpg' },
    { name: 'Mohamed Salah', img: 'https://img.a.transfermarkt.technology/portrait/big/148455-1698072492.jpg' },
    { name: 'Kevin De Bruyne', img: 'https://img.a.transfermarkt.technology/portrait/big/88755-1697701935.jpg' },
    { name: 'Lamine Yamal', img: 'https://img.a.transfermarkt.technology/portrait/big/939987-1708000226.jpg' },
    { name: 'Pedri', img: 'https://img.a.transfermarkt.technology/portrait/big/766361-1698072696.jpg' },
    { name: 'Rodrigo Hernández', img: 'https://img.a.transfermarkt.technology/portrait/big/357565-1698073053.jpg' },
    { name: 'Toni Kroos', img: 'https://img.a.transfermarkt.technology/portrait/big/37574-1698072887.jpg' },
    { name: 'Robert Lewandowski', img: 'https://img.a.transfermarkt.technology/portrait/big/38253-1697702088.jpg' },
    { name: 'Harry Kane', img: 'https://img.a.transfermarkt.technology/portrait/big/132098-1698073149.jpg' },
    { name: 'Phil Foden', img: 'https://img.a.transfermarkt.technology/portrait/big/406635-1697702268.jpg' },
    { name: 'Bukayo Saka', img: 'https://img.a.transfermarkt.technology/portrait/big/433177-1698073384.jpg' },
    { name: 'Antoine Griezmann', img: 'https://img.a.transfermarkt.technology/portrait/big/125781-1698073527.jpg' },
    { name: 'Neymar Jr', img: 'https://img.a.transfermarkt.technology/portrait/big/68290-1698073680.jpg' },
    { name: 'Riyad Mahrez', img: 'https://img.a.transfermarkt.technology/portrait/big/98769-1698073862.jpg' },
    { name: 'Sadio Mané', img: 'https://img.a.transfermarkt.technology/portrait/big/200512-1697703047.jpg' },
    { name: 'Virgil van Dijk', img: 'https://img.a.transfermarkt.technology/portrait/big/139208-1697703234.jpg' },
    { name: 'Joshua Kimmich', img: 'https://img.a.transfermarkt.technology/portrait/big/161056-1697703427.jpg' },
    { name: 'Son Heung-min', img: 'https://img.a.transfermarkt.technology/portrait/big/167967-1698073973.jpg' },
    { name: 'Marcus Rashford', img: 'https://img.a.transfermarkt.technology/portrait/big/258923-1697703589.jpg' },
    { name: 'Bruno Fernandes', img: 'https://img.a.transfermarkt.technology/portrait/big/240306-1697703950.jpg' },
    { name: 'Federico Valverde', img: 'https://img.a.transfermarkt.technology/portrait/big/349765-1698074271.jpg' },
    { name: 'Gavi', img: 'https://img.a.transfermarkt.technology/portrait/big/870456-1698074508.jpg' },
    { name: 'Achraf Hakimi', img: 'https://img.a.transfermarkt.technology/portrait/big/394942-1697703993.jpg' },
    { name: 'Jack Grealish', img: 'https://img.a.transfermarkt.technology/portrait/big/203460-1697703738.jpg' },
    { name: 'Bernardo Silva', img: 'https://img.a.transfermarkt.technology/portrait/big/189117-1697704089.jpg' },
];

let handler = async (m, { conn, command }) => {
    conn.gamePlayer = conn.gamePlayer || {};
    let id = m.chat;

    if (command.startsWith('_لاعب_')) {
        let game = conn.gamePlayer[id];

        if (!game) {
            return conn.reply(m.chat, `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🦅┆لا توجد لعبة نشطة الان*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`, m);
        }

        let idx = parseInt(command.split('_')[2]);
        if (isNaN(idx) || idx < 1 || idx > 4) return;

        let selectedAnswer = game.options[idx - 1];
        let isCorrect = game.correctAnswer === selectedAnswer;

        clearTimeout(game.timer);
        delete conn.gamePlayer[id];

        if (isCorrect) {
            global.db.data.users[m.sender].exp += 500;
            await conn.reply(m.chat, `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🦅┆✅ إجابة صحيحة مبروك*\n*⃝🌙┆🏆 الجائزة: 500xp*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`, m);
        } else {
            await conn.reply(m.chat, `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🦅┆❌ إجابة خاطئة*\n*⃝🌙┆📌 الإجابة الصحيحة: ${game.correctAnswer}*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`, m);
        }

    } else {
        try {
            if (conn.gamePlayer[id]) {
                return conn.reply(m.chat, `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🦅┆يوجد لعبة سابقة لم تنتهي*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`, m);
            }

            const item = players[Math.floor(Math.random() * players.length)];
            const { name, img } = item;

            let options = [name];
            while (options.length < 4) {
                let r = players[Math.floor(Math.random() * players.length)].name;
                if (!options.includes(r)) options.push(r);
            }
            options.sort(() => Math.random() - 0.5);

            const media = await prepareWAMessageMedia({ image: { url: img } }, { upload: conn.waUploadToServer });

            const interactiveMessage = {
                body: {
                    text: `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🦅┆⚽ احزر اللاعب*\n*⃝🌙┆⏱️ الوقت: 60 ثانية*\n*⃝🦅┆🏆 الجائزة: 500xp*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`,
                },
                footer: { text: '𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙\n© ʙʏ 𝑴𝑼𝑹𝑨𝑻𝑨' },
                header: {
                    title: 'ㅤ',
                    subtitle: 'من هذا اللاعب؟ ⇊',
                    hasMediaAttachment: true,
                    imageMessage: media.imageMessage,
                },
                nativeFlowMessage: {
                    buttons: options.map((option, index) => ({
                        name: 'quick_reply',
                        buttonParamsJson: JSON.stringify({
                            display_text: `${index % 2 === 0 ? '⃝🦅' : '⃝🌙'}『${option}』`,
                            id: `._لاعب_${index + 1}`
                        })
                    })),
                },
            };

            let msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: { message: { interactiveMessage } },
            }, { userJid: conn.user.jid, quoted: m });

            conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

            conn.gamePlayer[id] = {
                correctAnswer: name,
                options,
                timer: setTimeout(async () => {
                    if (conn.gamePlayer[id]) {
                        await conn.reply(m.chat, `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🦅┆⏰ انتهى الوقت*\n*⃝🌙┆📌 الإجابة الصحيحة: ${name}*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`, m);
                        delete conn.gamePlayer[id];
                    }
                }, timeout),
            };

        } catch (e) {
            console.error(e);
            conn.reply(m.chat, `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🦅┆⚠️ حدث خطأ*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`, m);
        }
    }
};

handler.help = ['لاعب'];
handler.tags = ['لعبة'];
handler.command = /^(لاعب|_لاعب_\d+)$/i;

export default handler;
