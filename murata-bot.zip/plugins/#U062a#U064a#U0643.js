// ════════════════════════════════════════
//   🎬 MURATA TIKTOK - EPIC EDITION 🦅
// ════════════════════════════════════════

import { generateWAMessageContent, generateWAMessageFromContent } from '@whiskeysockets/baileys'
import { createRequire } from 'module'
const require = createRequire(import.meta.url)
const axios = require('axios')

const GROQ_API_KEY = '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'

// ── تنظيف TLS ──
const { emitWarning } = process
process.emitWarning = (w, ...a) => {
  if (typeof w === 'string' && w.includes('NODE_TLS_REJECT_UNAUTHORIZED')) return
  return emitWarning(w, ...a)
}
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'

// ── ثوابت ──
const NEWSLETTER = {
  jid:  '120363423359642420@newsletter',
  name: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑽𝑬𝑹𝑰𝑭𝑰𝑬𝑫 𝑺𝒀𝑺𝑻𝑬𝑴'
}

// ── مساعد: بناء fkontak ──
const makeFkontak = (jid, name) => ({
  key: { fromMe: false, participant: '0@s.whatsapp.net', remoteJid: jid },
  message: {
    contactMessage: {
      displayName: name,
      vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:${name}\nORG:𝑴𝑼𝑹𝑨𝑻𝑨 𝑺𝒀𝑺𝑻𝑬𝑴;\nTEL;type=CELL;waid=${jid.split('@')[0]}:+${jid.split('@')[0]}\nEND:VCARD`
    }
  }
})

// ── مساعد: رسالة الانتظار ──
const sendWaiting = async (conn, jid, fkontak, text) => {
  const msg = generateWAMessageFromContent(jid, {
    extendedTextMessage: {
      text,
      contextInfo: {
        forwardedNewsletterMessageInfo: NEWSLETTER,
        isForwarded: true,
        quotedMessage: fkontak.message,
        participant: '0@s.whatsapp.net'
      }
    }
  }, { quoted: fkontak })
  await conn.relayMessage(jid, msg.message, { messageId: msg.key.id })
}

// ── مساعد: ترجمة Groq ──
const translateGroq = async (text, isEdit) => {
  try {
    const res = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
      model: 'llama-3.3-70b-versatile',
      max_tokens: 50,
      messages: [{
        role: 'system',
        content: 'Translate any text to the best English TikTok search query. Return ONLY the English query, nothing else.'
      }, {
        role: 'user',
        content: `Translate to English TikTok search: "${text}"`
      }]
    }, {
      headers: { 'Authorization': `Bearer ${GROQ_API_KEY}`, 'Content-Type': 'application/json' },
      timeout: 8000
    })
    const translated = res.data?.choices?.[0]?.message?.content?.trim()
    if (translated) return isEdit ? `${translated} edit montage 4k` : translated
  } catch (e) { console.log('Groq failed:', e.message) }
  return isEdit ? `${text} edit montage` : text
}

// ── مساعد: بناء الكاروسيل ──
const buildCards = async (conn, videos, input, isEdit, max = 6) => {
  const cards = []
  const used  = new Set()
  let   i     = 1

  for (const v of videos) {
    if (cards.length >= max) break
    if (used.has(v.play)) continue
    try {
      const { videoMessage } = await generateWAMessageContent(
        { video: { url: v.play } },
        { upload: conn.waUploadToServer }
      )
      cards.push({
        body: {
          text: isEdit
            ? `✨ *ايديت ${i}:* ${input}\n🎬 𝐄𝐃𝐈𝐓 #${i}`
            : `🎬 *فيديو ${i}:* ${input}\n🎥 𝐕𝐈𝐃𝐄𝐎 #${i}`
        },
        header: { hasMediaAttachment: true, videoMessage },
        nativeFlowMessage: {
          buttons: [{
            name: 'cta_url',
            buttonParamsJson: JSON.stringify({
              display_text: isEdit ? '⬇️ تحميل الايديت' : '▶️ مشاهدة الفيديو',
              url: v.play
            })
          }]
        }
      })
      used.add(v.play)
      i++
    } catch (e) { continue }
  }
  return cards
}

// ══════════════════════════════════════
let handler = async (m, { conn, text, usedPrefix, command }) => {
  const query = text?.trim()
  const isArabic = command === 'تيك2' || command === 'عربي'

  // ── بدون نص: قائمة تفاعلية ──
  if (!query) {
    const interactiveMessage = {
      body: {
        text: `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🎬┆مـرحـبـاً بـك فـي بـوت تـيـك تـوك*\n*⃝🦅┆اكتب ما تريد:*\n*⃝🌙┆${usedPrefix}تيك ايديت كريستيانو*\n*⃝🦅┆${usedPrefix}تيك فيديو اهداف*\n*⃝🌙┆${usedPrefix}تيك2 فيد اترو (عربي)*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`
      },
      footer: { text: '🦅 𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻' },
      header: { hasMediaAttachment: false },
      nativeFlowMessage: {
        buttons: [{
          name: 'single_select',
          buttonParamsJson: JSON.stringify({
            title: '🎬 اختر النوع',
            sections: [{
              title: '🌍 بحث عالمي (تيك)',
              rows: [
                { title: '✨ ايديت / مونتاج',    description: 'ابحث عن ايديتات احترافية',  id: `${usedPrefix}تيك ايديت ` },
                { title: '🎬 فيديو عادي',         description: 'ابحث عن أي فيديو',           id: `${usedPrefix}تيك فيديو ` },
                { title: '⚽ ايديت كرة قدم',      description: 'مونتاجات وأهداف',            id: `${usedPrefix}تيك ايديت كرة قدم` },
                { title: '🎮 ايديت ألعاب',        description: 'مونتاجات ألعاب',             id: `${usedPrefix}تيك ايديت gaming` },
              ]
            }, {
              title: '🇸🇦 بحث عربي (تيك2)',
              rows: [
                { title: '✨ ايديت عربي',         description: 'ايديتات عربية محلية',        id: `${usedPrefix}تيك2 ايديت ` },
                { title: '🎬 فيد عربي',           description: 'فيديوهات عربية',             id: `${usedPrefix}تيك2 فيد ` },
                { title: '🎵 ايديت موسيقى عربية', description: 'مونتاجات أغاني عربية',       id: `${usedPrefix}تيك2 ايديت موسيقى` },
              ]
            }]
          })
        }]
      }
    }

    const msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: { message: { interactiveMessage } }
    }, { userJid: conn.user.jid, quoted: m })
    return conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
  }

  // ── تحديد النوع ──
  const isEdit    = /^(ايديت|مونتاج)\s*/i.test(query)
  const cleanText = query.replace(/^(ايديت|مونتاج|فيد|فيديو)\s*/i, '').trim()

  await m.react('🎬')

  // ── رسالة الانتظار ──
  const groupName = m.isGroup
    ? (await conn.groupMetadata(m.chat).catch(() => null))?.subject || '𝑴𝑼𝑹𝑨𝑻𝑨'
    : '𝑴𝑼𝑹𝑨𝑻𝑨 𝑺𝒀𝑺𝑻𝑬𝑴'

  const fkontak = makeFkontak(m.chat, groupName)

  await sendWaiting(conn, m.chat, fkontak,
    `${isEdit ? '✨' : '⏳'} *جـاري البحث عن ${isEdit ? 'ايديتات' : 'فيديوهات'}${isArabic ? ' عربية' : ''}:*\n「 ${query} 」\n*⃝🦅┆ثـوانـي...*`
  )

  // ── البحث ──
  let searchQuery
  if (isArabic) {
    searchQuery = isEdit ? `${cleanText} مونتاج` : cleanText
  } else {
    searchQuery = await translateGroq(cleanText, isEdit)
  }
  console.log(`🦅 TikTok Search: ${searchQuery} | عربي: ${isArabic}`)

  // ── جلب الفيديوهات ──
  const { data } = await axios.get('https://tikwm.com/api/feed/search', {
    params: {
      keywords: searchQuery,
      count: 20,
      region: isArabic ? 'SA' : 'US'
    },
    timeout: 15000
  })

  const videos = data?.data?.videos
  if (!Array.isArray(videos) || videos.length === 0) {
    await m.react('❌')
    return conn.reply(
      m.chat,
      `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🦅┆❌ مـا لـقـيـنـا نـتـائـج لـ:*\n*⃝🌙┆「 ${query} 」*\n*⃝🦅┆💡 جـرب كـلـمـات ثـانـيـة*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`,
      m
    )
  }

  // ── بناء الكاروسيل ──
  const cards = await buildCards(conn, videos, query, isEdit)

  if (!cards.length) {
    await m.react('❌')
    return conn.reply(m.chat, `*⃝🦅┆⚠️ فـشـل تـحـمـيـل الـفـيـديـوهـات، حـاول مـرة ثـانـيـة*`, m)
  }

  // ── إرسال الكاروسيل ──
  const finalMsg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: isEdit
              ? `> ✨ *تـم اخـتـيـار أفـضـل ${cards.length} ايديتات بـواسـطـة مُـوراتـا 🦅*`
              : `> 🎬 *تـم الـعـثـور عـلـى ${cards.length} فيديوهات بـواسـطـة مُـوراتـا 🦅*`
          },
          carouselMessage: { cards },
          contextInfo: {
            forwardedNewsletterMessageInfo: NEWSLETTER,
            isForwarded: true,
            quotedMessage: fkontak.message,
            participant: '0@s.whatsapp.net'
          }
        }
      }
    }
  }, { quoted: fkontak })

  await conn.relayMessage(m.chat, finalMsg.message, { messageId: finalMsg.key.id })
  await m.react('✅')
}

handler.command = /^تيك$|^تيك2$|^tiktok$/i
export default handler
