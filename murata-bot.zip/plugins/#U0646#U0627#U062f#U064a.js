import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

const timeout = 60000;

const clubs = [
    { name: 'ريال مدريد', img: 'https://upload.wikimedia.org/wikipedia/en/5/56/Real_Madrid_CF.svg' },
    { name: 'برشلونة', img: 'https://upload.wikimedia.org/wikipedia/en/4/47/FC_Barcelona_%28crest%29.svg' },
    { name: 'مانشستر سيتي', img: 'https://upload.wikimedia.org/wikipedia/en/e/eb/Manchester_City_FC_badge.svg' },
    { name: 'مانشستر يونايتد', img: 'https://upload.wikimedia.org/wikipedia/en/7/7a/Manchester_United_FC_crest.svg' },
    { name: 'ليفربول', img: 'https://upload.wikimedia.org/wikipedia/en/0/0c/Liverpool_FC.svg' },
    { name: 'بايرن ميونيخ', img: 'https://upload.wikimedia.org/wikipedia/commons/1/1b/FC_Bayern_M%C3%BCnchen_logo_%282017%29.svg' },
    { name: 'باريس سان جيرمان', img: 'https://upload.wikimedia.org/wikipedia/en/a/a7/Paris_Saint-Germain_F.C..svg' },
    { name: 'يوفنتوس', img: 'https://upload.wikimedia.org/wikipedia/commons/b/bc/Juventus_FC_2017_icon_%28black%29.svg' },
    { name: 'آرسنال', img: 'https://upload.wikimedia.org/wikipedia/en/5/53/Arsenal_FC.svg' },
    { name: 'تشيلسي', img: 'https://upload.wikimedia.org/wikipedia/en/c/cc/Chelsea_FC.svg' },
    { name: 'أتلتيكو مدريد', img: 'https://upload.wikimedia.org/wikipedia/en/f/f4/Atletico_de_Madrid_2017_logo.svg' },
    { name: 'بوروسيا دورتموند', img: 'https://upload.wikimedia.org/wikipedia/commons/6/67/Borussia_Dortmund_logo.svg' },
    { name: 'إنتر ميلان', img: 'https://upload.wikimedia.org/wikipedia/commons/0/05/FC_Internazionale_Milano_2021.svg' },
    { name: 'ميلان', img: 'https://upload.wikimedia.org/wikipedia/commons/d/d0/Logo_of_AC_Milan.svg' },
    { name: 'توتنهام', img: 'https://upload.wikimedia.org/wikipedia/en/b/b4/Tottenham_Hotspur.svg' },
    { name: 'بنفيكا', img: 'https://upload.wikimedia.org/wikipedia/en/a/a8/SL_Benfica_logo.svg' },
    { name: 'أياكس', img: 'https://upload.wikimedia.org/wikipedia/en/7/79/Ajax_Amsterdam.svg' },
    { name: 'بورتو', img: 'https://upload.wikimedia.org/wikipedia/en/f/f1/FC_Porto.svg' },
    { name: 'روما', img: 'https://upload.wikimedia.org/wikipedia/en/f/f7/AS_Roma_logo_%282013%29.svg' },
    { name: 'نابولي', img: 'https://upload.wikimedia.org/wikipedia/commons/2/2d/SSC_Napoli_2007.svg' },
    { name: 'سيفيلا', img: 'https://upload.wikimedia.org/wikipedia/en/3/3b/Sevilla_FC_logo.svg' },
    { name: 'فياريال', img: 'https://upload.wikimedia.org/wikipedia/en/b/b9/Villarreal_CF_logo-en.svg' },
    { name: 'ويست هام', img: 'https://upload.wikimedia.org/wikipedia/en/c/c2/West_Ham_United_FC_logo.svg' },
    { name: 'الهلال', img: 'https://upload.wikimedia.org/wikipedia/en/f/fd/Al-Hilal_FC_Logo.svg' },
    { name: 'النصر', img: 'https://upload.wikimedia.org/wikipedia/en/f/fd/Al_Nassr_FC_Logo.svg' },
    { name: 'الاتحاد', img: 'https://upload.wikimedia.org/wikipedia/en/c/c4/Al-Ittihad_FC_%28Jeddah%29_crest.svg' },
    { name: 'ليون', img: 'https://upload.wikimedia.org/wikipedia/en/e/e9/Olympique_Lyonnais_logo_2022.svg' },
    { name: 'مارسيليا', img: 'https://upload.wikimedia.org/wikipedia/commons/d/d8/Olympique_Marseille_logo.svg' },
    { name: 'لاتسيو', img: 'https://upload.wikimedia.org/wikipedia/en/5/5d/SS_Lazio_Badge.svg' },
    { name: 'فيورنتينا', img: 'https://upload.wikimedia.org/wikipedia/commons/b/b6/ACF_Fiorentina_2022.svg' },
];

let handler = async (m, { conn, command }) => {
    conn.gameClub = conn.gameClub || {};
    let id = m.chat;

    if (command.startsWith('_نادي_')) {
        let game = conn.gameClub[id];

        if (!game) {
            return conn.reply(m.chat, `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🦅┆لا توجد لعبة نشطة الان*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`, m);
        }

        let idx = parseInt(command.split('_')[2]);
        if (isNaN(idx) || idx < 1 || idx > 4) return;

        let selectedAnswer = game.options[idx - 1];
        let isCorrect = game.correctAnswer === selectedAnswer;

        clearTimeout(game.timer);
        delete conn.gameClub[id];

        if (isCorrect) {
            global.db.data.users[m.sender].exp += 500;
            await conn.reply(m.chat, `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🦅┆✅ إجابة صحيحة مبروك*\n*⃝🌙┆🏆 الجائزة: 500xp*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`, m);
        } else {
            await conn.reply(m.chat, `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🦅┆❌ إجابة خاطئة*\n*⃝🌙┆📌 الإجابة الصحيحة: ${game.correctAnswer}*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`, m);
        }

    } else {
        try {
            if (conn.gameClub[id]) {
                return conn.reply(m.chat, `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🦅┆يوجد لعبة سابقة لم تنتهي*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`, m);
            }

            const item = clubs[Math.floor(Math.random() * clubs.length)];
            const { name, img } = item;

            let options = [name];
            while (options.length < 4) {
                let r = clubs[Math.floor(Math.random() * clubs.length)].name;
                if (!options.includes(r)) options.push(r);
            }
            options.sort(() => Math.random() - 0.5);

            const media = await prepareWAMessageMedia({ image: { url: img } }, { upload: conn.waUploadToServer });

            const interactiveMessage = {
                body: {
                    text: `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🦅┆🏟️ احزر النادي*\n*⃝🌙┆⏱️ الوقت: 60 ثانية*\n*⃝🦅┆🏆 الجائزة: 500xp*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`,
                },
                footer: { text: '𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙\n© ʙʏ 𝑴𝑼𝑹𝑨𝑻𝑨' },
                header: {
                    title: 'ㅤ',
                    subtitle: 'ما هذا النادي؟ ⇊',
                    hasMediaAttachment: true,
                    imageMessage: media.imageMessage,
                },
                nativeFlowMessage: {
                    buttons: options.map((option, index) => ({
                        name: 'quick_reply',
                        buttonParamsJson: JSON.stringify({
                            display_text: `${index % 2 === 0 ? '⃝🦅' : '⃝🌙'}『${option}』`,
                            id: `._نادي_${index + 1}`
                        })
                    })),
                },
            };

            let msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: { message: { interactiveMessage } },
            }, { userJid: conn.user.jid, quoted: m });

            conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

            conn.gameClub[id] = {
                correctAnswer: name,
                options,
                timer: setTimeout(async () => {
                    if (conn.gameClub[id]) {
                        await conn.reply(m.chat, `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🦅┆⏰ انتهى الوقت*\n*⃝🌙┆📌 الإجابة الصحيحة: ${name}*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`, m);
                        delete conn.gameClub[id];
                    }
                }, timeout),
            };

        } catch (e) {
            console.error(e);
            conn.reply(m.chat, `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🦅┆⚠️ حدث خطأ*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`, m);
        }
    }
};

handler.help = ['نادي'];
handler.tags = ['لعبة'];
handler.command = /^(نادي|_نادي_\d+)$/i;

export default handler;
