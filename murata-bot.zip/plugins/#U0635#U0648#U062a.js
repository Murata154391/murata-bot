import { generateWAMessageFromContent, proto } from '@whiskeysockets/baileys'
import axios from 'axios'

const { emitWarning } = process
process.emitWarning = (warning, ...args) => {
  if (typeof warning === 'string' && warning.includes('NODE_TLS_REJECT_UNAUTHORIZED')) return
  return emitWarning(warning, ...args)
}
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'

// ══════════ ثوابت ══════════
const NEWSLETTER_JID  = '120363423359642420@newsletter'
const NEWSLETTER_NAME = '𝑴𝑼𝑹𝑨𝑻𝑨  𝑽𝑬𝑹𝑰𝑭𝑰𝑬𝑫  𝑺𝒀𝑺𝑻𝑬𝑴'
const CHANNEL_URL     = 'https://whatsapp.com/channel/0029Vb76oO3BA1euG0eIvA3a'
const D  = '*⌬──══─┈•⤣🎵⤤•┈─══──⌬*'
const DS = '*┃*'

// ══════════ makeFkontak ══════════
async function makeFkontak() {
  try {
    const res   = await fetch('https://cdn.russellxz.click/64bba973.jpg')
    const thumb = Buffer.from(await res.arrayBuffer())
    return {
      key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' },
      message: { locationMessage: { name: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 🦅', jpegThumbnail: thumb } },
      participant: '0@s.whatsapp.net'
    }
  } catch { return undefined }
}

// ══════════ sendInteractive - نفس نظام اللودو ══════════
async function sendInteractive(conn, jid, bodyText, footerText, buttons) {
  try {
    const payload = {
      body:   { text: bodyText },
      footer: { text: footerText || '🦅 𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻' },
      header: { hasMediaAttachment: false, subtitle: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 🦅' },
      nativeFlowMessage: {
        buttons,
        messageParamsJson: JSON.stringify({
          bottom_sheet: { in_thread_buttons_limit: 1, list_title: '🎵 MURATA SOUND', button_title: '⭐ الأوامر ⭐' },
          tap_target_configuration: { description: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑺𝑶𝑼𝑵𝑫 🎵', canonical_url: CHANNEL_URL, domain: 'whatsapp.com', button_index: 0 }
        })
      }
    }
    const interactiveMessage = proto.Message.InteractiveMessage.fromObject(payload)
    const fkontak = await makeFkontak()
    const msg = generateWAMessageFromContent(jid, { interactiveMessage }, { userJid: conn.user.jid, quoted: fkontak })
    await conn.relayMessage(jid, msg.message, { messageId: msg.key.id })
  } catch {
    await conn.sendMessage(jid, {
      text: bodyText,
      contextInfo: {
        forwardedNewsletterMessageInfo: { newsletterJid: NEWSLETTER_JID, newsletterName: NEWSLETTER_NAME },
        isForwarded: true
      }
    })
  }
}

// ══════════ أزرار رئيسية ══════════
function mainFlow() {
  return [
    {
      name: 'single_select',
      buttonParamsJson: JSON.stringify({
        title: '🎵 أوامر الصوت',
        sections: [{
          title: `${D}`,
          rows: [
            { title: '⌬──══─┈•⤣🎧⤤•┈─══──⌬', description: '🎧 بحث بكلمة أو اسم', id: '.صوت' },
            { title: '⌬──══─┈•⤣🔗⤤•┈─══──⌬', description: '🔗 استخراج رابط تيك توك', id: '.صوت' },
            { title: '⌬──══─┈•⤣🎵⤤•┈─══──⌬', description: '🎵 تحميل أغنية يوتيوب', id: '.شغل' }
          ]
        }],
        has_multiple_buttons: true
      })
    },
    {
      name: 'quick_reply',
      buttonParamsJson: JSON.stringify({ display_text: '🔁 بحث جديد', id: '.صوت' })
    },
    {
      name: 'cta_url',
      buttonParamsJson: JSON.stringify({ display_text: '📢 قناة MURATA', url: CHANNEL_URL, merchant_url: CHANNEL_URL })
    }
  ]
}

// ══════════ أزرار بعد النجاح ══════════
function doneFlow() {
  return [
    {
      name: 'single_select',
      buttonParamsJson: JSON.stringify({
        title: '🎵 ماذا تريد؟',
        sections: [{
          title: `${D}`,
          rows: [
            { title: '⌬──══─┈•⤣🔁⤤•┈─══──⌬', description: '🔁 بحث جديد تيك توك', id: '.صوت' },
            { title: '⌬──══─┈•⤣🎵⤤•┈─══──⌬', description: '🎵 تحميل أغنية يوتيوب', id: '.شغل' }
          ]
        }],
        has_multiple_buttons: true
      })
    },
    {
      name: 'quick_reply',
      buttonParamsJson: JSON.stringify({ display_text: '🔁 بحث ثاني', id: '.صوت' })
    },
    {
      name: 'cta_url',
      buttonParamsJson: JSON.stringify({ display_text: '📢 قناة MURATA', url: CHANNEL_URL, merchant_url: CHANNEL_URL })
    }
  ]
}

// ══════════ Handler ══════════
const handler = async (m, { conn, text }) => {
  const jid   = m.chat
  const input = text?.trim() || ''

  await conn.sendMessage(jid, { react: { text: '🎵', key: m.key } })

  // ══ بدون مدخل ══
  if (!input) {
    return sendInteractive(conn, jid,
      `${D}\n` +
      `${DS} 🎵 *تيك توك - استخراج صوت*\n` +
      `${D}\n` +
      `${DS} 📝 *طريقة الاستخدام:*\n` +
      `${DS} *.صوت كلمة البحث*\n` +
      `${DS} *.صوت رابط تيك توك*\n` +
      `${D}\n` +
      `${DS} 💡 *أمثلة:*\n` +
      `${DS} .صوت ماشي صح\n` +
      `${DS} .صوت نشيد اسلامي\n` +
      `${DS} .صوت https://tiktok.com/...\n` +
      `${D}`,
      '🎵 𝑴𝑼𝑹𝑨𝑻𝑨 𝑺𝑶𝑼𝑵𝑫', mainFlow())
  }

  // ══ رسالة انتظار ══
  await sendInteractive(conn, jid,
    `${D}\n` +
    `${DS} 🔍 *جـاري البحث...*\n` +
    `${D}\n` +
    `${DS} 🎵 ${input.length > 40 ? 'رابط تيك توك' : input}\n` +
    `${DS} ⏳ يرجى الانتظار...\n` +
    `${D}`,
    '⏳ جاري البحث...', mainFlow())

  try {
    let audioUrl = null
    let title    = ''
    let duration = 0

    // ══ رابط مباشر ══
    if (input.startsWith('http')) {
      const { data } = await axios.get('https://tikwm.com/api/', {
        params: { url: input, hd: 1 },
        timeout: 20000,
        headers: { 'User-Agent': 'Mozilla/5.0', 'Referer': 'https://tikwm.com/' }
      })
      const d  = data?.data
      audioUrl = d?.music_info?.play || d?.music || d?.play || d?.hdplay
      title    = d?.title || 'صوت تيك توك'
      duration = d?.duration || 0

    // ══ بحث بكلمات ══
    } else {
      const queries   = [input, `${input} trending`, `${input} viral`, `${input} 2025`]
      let allVideos   = []

      for (const q of queries) {
        try {
          const { data } = await axios.get('https://tikwm.com/api/feed/search', {
            params: { keywords: q, count: 30, cursor: 0, web: 1, hd: 1 },
            timeout: 15000,
            headers: { 'User-Agent': 'Mozilla/5.0', 'Referer': 'https://tikwm.com/' }
          })
          const vids = data?.data?.videos
          if (Array.isArray(vids) && vids.length) allVideos = [...allVideos, ...vids]
        } catch { continue }
      }

      if (!allVideos.length) {
        return sendInteractive(conn, jid,
          `${D}\n${DS} ❌ *ما لقيت نتيجة!*\n${D}\n${DS} 🔍 البحث: ${input}\n${DS} 💡 جرب كلمات مختلفة\n${D}`,
          '❌ لا توجد نتائج', mainFlow())
      }

      const filtered = allVideos
        .filter(v => {
          const music = v?.music_info?.play || v?.music
          return music && music.startsWith('http') && v?.duration >= 5 && v?.duration <= 300
        })
        .sort((a, b) => (b.play_count || 0) - (a.play_count || 0))

      if (!filtered.length) {
        return sendInteractive(conn, jid,
          `${D}\n${DS} ❌ *ما لقيت صوت مناسب!*\n${D}\n${DS} 🔍 البحث: ${input}\n${DS} 💡 جرب كلمات مختلفة\n${D}`,
          '❌ لا يوجد صوت', mainFlow())
      }

      const v  = filtered[0]
      audioUrl = v.music_info?.play || v.music
      title    = v.title || 'صوت تيك توك'
      duration = v.duration || 0
    }

    // ══ تحقق من الرابط ══
    if (!audioUrl || !audioUrl.startsWith('http')) {
      return sendInteractive(conn, jid,
        `${D}\n${DS} ❌ *تعذر الحصول على الصوت!*\n${D}\n${DS} 💡 حاول مرة ثانية\n${D}`,
        '❌ فشل', mainFlow())
    }

    // ══ تحميل الصوت ══
    const audioBuffer = await axios.get(audioUrl, {
      responseType: 'arraybuffer',
      timeout: 30000,
      headers: { 'User-Agent': 'Mozilla/5.0' }
    })

    const mins   = Math.floor(duration / 60)
    const secs   = duration % 60
    const durStr = duration ? `${mins}:${String(secs).padStart(2, '0')}` : 'غير محدد'

    // ══ رسالة المعلومات بأزرار ══
    await sendInteractive(conn, jid,
      `${D}\n` +
      `${DS} ✅ *تم استخراج الصوت!*\n` +
      `${D}\n` +
      `${DS} 🎧 *الوصف:* ${title.substring(0, 50)}\n` +
      `${DS} ⏱️ *المدة:* ${durStr}\n` +
      `${DS} 🔍 *البحث:* ${input.length > 30 ? 'رابط مباشر' : input}\n` +
      `${D}\n` +
      `${DS} 🦅 _𝑴𝑼𝑹𝑨𝑻𝑨  𝑺𝒀𝑺𝑻𝑬𝑴_\n` +
      `${D}`,
      '✅ اكتمل الاستخراج', doneFlow())

    // ══ إرسال الصوت ══
    await conn.sendMessage(jid, {
      audio: Buffer.from(audioBuffer.data),
      mimetype: 'audio/mpeg',
      ptt: false,
      contextInfo: {
        forwardedNewsletterMessageInfo: { newsletterJid: NEWSLETTER_JID, newsletterName: NEWSLETTER_NAME },
        isForwarded: true
      }
    }, { quoted: m })

    await conn.sendMessage(jid, { react: { text: '🎶', key: m.key } })

  } catch (err) {
    console.log('صوت error:', err?.message || err)
    return sendInteractive(conn, jid,
      `${D}\n${DS} ⚠️ *حدث خطأ!*\n${D}\n${DS} 📝 ${err?.message || 'خطأ غير معروف'}\n${DS} 💡 حاول مرة ثانية\n${D}`,
      '⚠️ خطأ', mainFlow())
  }
}

handler.command = /^صوت$/i
handler.tags    = ['media']
handler.help    = ['صوت [كلمة البحث أو رابط تيك توك]']

export default handler
