import { generateWAMessageFromContent, proto } from '@whiskeysockets/baileys'
import axios from 'axios'

// ══════════ ثوابت ══════════
const GROQ_KEY        = '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'
const NEWSLETTER_JID  = '120363423359642420@newsletter'
const NEWSLETTER_NAME = '𝑴𝑼𝑹𝑨𝑻𝑨  𝑽𝑬𝑹𝑰𝑭𝑰𝑬𝑫  𝑺𝒀𝑺𝑻𝑬𝑴'
const CHANNEL_URL     = 'https://whatsapp.com/channel/0029Vb76oO3BA1euG0eIvA3a'
const D  = '*⌬──══─┈•⤣🤖⤤•┈─══──⌬*'
const DS = '*┃*'

const conversationHistory = {}

// ══════════ makeFkontak ══════════
async function makeFkontak() {
  try {
    const res   = await fetch('https://cdn.russellxz.click/64bba973.jpg')
    const thumb = Buffer.from(await res.arrayBuffer())
    return {
      key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' },
      message: { locationMessage: { name: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 🦅', jpegThumbnail: thumb } },
      participant: '0@s.whatsapp.net'
    }
  } catch { return undefined }
}

// ══════════ sendInteractive ══════════
async function sendInteractive(conn, jid, bodyText, footerText, buttons, mentions = []) {
  try {
    const payload = {
      body:   { text: bodyText },
      footer: { text: footerText || '🦅 𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻' },
      header: { hasMediaAttachment: false, subtitle: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 🦅' },
      nativeFlowMessage: {
        buttons,
        messageParamsJson: JSON.stringify({
          bottom_sheet: { in_thread_buttons_limit: 1, list_title: '🤖 MURATA AI', button_title: '⭐ الأوامر ⭐' },
          tap_target_configuration: { description: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑨𝑰 🤖', canonical_url: CHANNEL_URL, domain: 'whatsapp.com', button_index: 0 }
        })
      }
    }
    const interactiveMessage = proto.Message.InteractiveMessage.fromObject(payload)
    const fkontak = await makeFkontak()
    const msg = generateWAMessageFromContent(jid, { interactiveMessage }, { userJid: conn.user.jid, quoted: fkontak })
    if (mentions.length) {
      msg.message.interactiveMessage.contextInfo = {
        ...(msg.message.interactiveMessage.contextInfo || {}),
        mentionedJid: mentions
      }
    }
    await conn.relayMessage(jid, msg.message, { messageId: msg.key.id })
  } catch {
    await conn.sendMessage(jid, {
      text: bodyText,
      mentions,
      contextInfo: {
        forwardedNewsletterMessageInfo: { newsletterJid: NEWSLETTER_JID, newsletterName: NEWSLETTER_NAME },
        isForwarded: true
      }
    })
  }
}

// ══════════ أزرار رئيسية ══════════
function mainFlow() {
  return [
    {
      name: 'single_select',
      buttonParamsJson: JSON.stringify({
        title: '🤖 أوامر موراتا AI',
        sections: [{
          title: `${D}`,
          rows: [
            { title: '⌬──══─┈•⤣🤖⤤•┈─══──⌬', description: '🤖 سؤال جديد', id: '.موراتا' },
            { title: '⌬──══─┈•⤣🗑️⤤•┈─══──⌬', description: '🗑️ مسح المحادثة', id: '.مسح' }
          ]
        }],
        has_multiple_buttons: true
      })
    },
    {
      name: 'quick_reply',
      buttonParamsJson: JSON.stringify({ display_text: '🤖 سؤال جديد', id: '.موراتا' })
    },
    {
      name: 'cta_url',
      buttonParamsJson: JSON.stringify({ display_text: '📢 قناة MURATA', url: CHANNEL_URL, merchant_url: CHANNEL_URL })
    }
  ]
}

// ══════════ أزرار بعد الرد ══════════
function doneFlow() {
  return [
    {
      name: 'single_select',
      buttonParamsJson: JSON.stringify({
        title: '🤖 ماذا تريد؟',
        sections: [{
          title: `${D}`,
          rows: [
            { title: '⌬──══─┈•⤣🤖⤤•┈─══──⌬', description: '🤖 سؤال آخر', id: '.موراتا' },
            { title: '⌬──══─┈•⤣🗑️⤤•┈─══──⌬', description: '🗑️ مسح المحادثة', id: '.مسح' }
          ]
        }],
        has_multiple_buttons: true
      })
    },
    {
      name: 'quick_reply',
      buttonParamsJson: JSON.stringify({ display_text: '🤖 سؤال آخر', id: '.موراتا' })
    },
    {
      name: 'cta_url',
      buttonParamsJson: JSON.stringify({ display_text: '📢 قناة MURATA', url: CHANNEL_URL, merchant_url: CHANNEL_URL })
    }
  ]
}

// ══════════ Handler ══════════
let handler = async (m, { conn, text, command }) => {
  const jid          = m.chat
  const sender       = m.sender
  const senderNumber = sender.replace(/:[0-9]+/, '').split('@')[0]
  const input        = text?.trim() || ''

  await m.react('🤖')

  // ══ مسح المحادثة ══
  if (command === 'مسح') {
    delete conversationHistory[sender]
    return sendInteractive(conn, jid,
      `${D}\n` +
      `${DS} 🗑️ *تم مسح المحادثة!*\n` +
      `${D}\n` +
      `${DS} 👤 @${senderNumber}\n` +
      `${DS} 💡 ابدأ محادثة جديدة\n` +
      `${D}`,
      '🗑️ تم المسح', mainFlow(), [sender])
  }

  // ══ بدون سؤال ══
  if (!input) {
    return sendInteractive(conn, jid,
      `${D}\n` +
      `${DS} 🤖 *مُـوراتـا AI*\n` +
      `${D}\n` +
      `${DS} 📝 *طريقة الاستخدام:*\n` +
      `${DS} *.موراتا سؤالك هنا*\n` +
      `${D}\n` +
      `${DS} 💡 *أمثلة:*\n` +
      `${DS} .موراتا ما هو الذكاء الاصطناعي؟\n` +
      `${DS} .موراتا اكتب لي قصيدة\n` +
      `${DS} .موراتا ترجم هذا النص\n` +
      `${D}`,
      '🤖 𝑴𝑼𝑹𝑨𝑻𝑨 𝑨𝑰', mainFlow(), [sender])
  }

  // ══ رسالة انتظار ══
  await sendInteractive(conn, jid,
    `${D}\n` +
    `${DS} 🤖 *مُـوراتـا يـفـكـر...*\n` +
    `${D}\n` +
    `${DS} 💬 ${input.substring(0, 50)}${input.length > 50 ? '...' : ''}\n` +
    `${DS} ⏳ يرجى الانتظار...\n` +
    `${D}`,
    '⏳ جاري التفكير...', mainFlow())

  try {
    // ══ تاريخ المحادثة ══
    if (!conversationHistory[sender]) conversationHistory[sender] = []
    conversationHistory[sender].push({ role: 'user', content: input })
    if (conversationHistory[sender].length > 10) {
      conversationHistory[sender] = conversationHistory[sender].slice(-10)
    }

    // ══ طلب Groq ══
    const { data } = await axios.post(
      'https://api.groq.com/openai/v1/chat/completions',
      {
        model: 'llama-3.3-70b-versatile',
        messages: [
          {
            role: 'system',
            content: 'أنت مساعد ذكي اسمك "مُوراتا" تتكلم العربية بشكل ممتاز وتكون مفيداً ومختصراً في ردودك.'
          },
          ...conversationHistory[sender]
        ],
        temperature: 0.9,
        max_tokens: 1000
      },
      {
        timeout: 30000,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${GROQ_KEY}`
        }
      }
    )

    const reply = data?.choices?.[0]?.message?.content

    // ══ فشل الرد ══
    if (!reply) {
      return sendInteractive(conn, jid,
        `${D}\n${DS} ❌ *ما قدرت أجيب رد!*\n${D}\n${DS} 💡 حاول مرة ثانية\n${D}`,
        '❌ فشل', mainFlow())
    }

    conversationHistory[sender].push({ role: 'assistant', content: reply })

    // ══ رسالة الرد بأزرار ══
    return sendInteractive(conn, jid,
      `${D}\n` +
      `${DS} 🤖 *| مُـوراتـا AI*\n` +
      `${D}\n` +
      `${reply}\n` +
      `${D}\n` +
      `${DS} 👤 السائل: @${senderNumber}\n` +
      `${DS} 🦅 _𝑴𝑼𝑹𝑨𝑻𝑨  𝑺𝒀𝑺𝑻𝑬𝑴_\n` +
      `${D}`,
      '✅ 𝑴𝑼𝑹𝑨𝑻𝑨 𝑨𝑰', doneFlow(), [sender])

  } catch (err) {
    console.log('موراتا error:', err?.message || err)
    return sendInteractive(conn, jid,
      `${D}\n${DS} ⚠️ *حدث خطأ!*\n${D}\n${DS} 📝 ${err?.message || 'خطأ غير معروف'}\n${DS} 💡 حاول مرة ثانية\n${D}`,
      '⚠️ خطأ', mainFlow())
  }
}

handler.help     = ['موراتا [سؤالك]', 'مسح']
handler.tags     = ['ai']
handler.command  = /^(موراتا|مسح)$/i

export default handler
