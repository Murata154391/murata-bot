import { existsSync } from 'fs'
import { join } from 'path'
import { prepareWAMessageMedia, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys'
import { performance } from 'perf_hooks'

let handler = async (m, { conn, usedPrefix: _p }) => {
  try {
    let old = performance.now()
    let neww = performance.now()
    let speed = (neww - old).toFixed(4)

    const user = await conn.getName(m.sender)
    const fecha = new Date().toLocaleDateString('ar-SA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })
    const hora = new Date().toLocaleTimeString('ar-SA')

let menuText = `*⌬══𝐄𝐍𝐓𝐄𝐑𝐓𝐀𝐈𝐍𝐌𝐄𝐍𝐓══⌬*\n`
menuText += `*┃ 🪪 الــاســم:* ${user}\n`
menuText += `*┃ 📲 الــرقــم:* ${m.sender.split('@')[0]}\n`
menuText += `*┃ 🔌 الــبــيــنــق:* ${speed}ms\n`
menuText += `*┃ 📅 الــتــاريــخ:* ${fecha}\n`
menuText += `*┃ ⏰ الــوقــت:* ${hora}\n`
menuText += `*⌬──══─┈•⤣🌙⤤•┈─══──⌬*\n\n`
menuText += `*⌬──══─┈•⤣⛄⤤•┈─══──⌬*\n`
menuText += `*┃ *『 ⌬╎⛄❯ ورع 』*\n`
menuText += `*┃ *『 ⌬╎⛄❯ تحدي 』*\n`
menuText += `*┃ *『 ⌬╎⛄❯ فزوره 』*\n`
menuText += `*┃ *『 ⌬╎⛄❯ حرب 』*\n`
menuText += `*┃ *『 ⌬╎⛄❯ صفع 』*\n`
menuText += `*┃ *『 ⌬╎⛄❯ شخصيه 』*\n`
menuText += `*┃ *『 ⌬╎⛄❯ نصايح 』*\n`
menuText += `*┃ *『 ⌬╎⛄❯ رياضيات 』*\n`
menuText += `*┃ *『 ⌬╎⛄❯ متفجرات 』*\n`
menuText += `*⌬──══─┈•⤣⛄⤤•┈─══──⌬*\n\n`

    await conn.sendMessage(m.chat, { react: { text: '🎭', key: m.key } })

    const localImagePath = join(process.cwd(), 'src', 'menu10.jpg')
    const channel = 'https://whatsapp.com/channel/0029Vb76oO3BA1euG0eIvA3a'
    const developerNumber = '201030943917'
    const developerContact = `https://wa.me/${developerNumber}`

    const nativeFlowPayload = {
      body: { text: menuText },
      footer: { text: '◌𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻' },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'single_select',
            buttonParamsJson: JSON.stringify({
              title: "📂 الأقسام الرئيسية",
              sections: [{
                title: "⌬──══─┈•⤣🌙⤤•┈─══──⌬\n║  اختر القسم المطلوب  ║\n⌬──══─┈•⤣🌙⤤•┈─══──⌬",
                rows: [
                  {"title":"⌬──══─┈•⤣🪐⤤•┈─══──⌬","description":"🏅 قــســم الــاداريــة ◌𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻","id":".ق1"},
                  {"title":"⌬──══─┈•⤣🪐⤤•┈─══──⌬","description":"🎨 قــســم الــاســتــيــكــر ◌𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻","id":".ق2"},
                  {"title":"⌬──══─┈•⤣🪐⤤•┈─══──⌬","description":"🎮 قــســم الــالــعــاب ◌𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻","id":".ق3"},
                  {"title":"⌬──══─┈•⤣🪐⤤•┈─══──⌬","description":"🔍 قــســم الــبــحــث و الــتــحــمــيــل ◌𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻","id":".ق4"},
                  {"title":"⌬──══─┈•⤣🪐⤤•┈─══──⌬","description":"🧰 قــســم الــادوات ◌𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻","id":".ق5"},
                  {"title":"⌬──══─┈•⤣🪐⤤•┈─══──⌬","description":"📦 قــســم الــمــوارد ◌𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻","id":".ق6"},
                  {"title":"⌬──══─┈•⤣🪐⤤•┈─══──⌬","description":"🤖 قــســم الــذكــاء الــاصــطــنــاعــي ◌𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻","id":".ق7"},
                  {"title":"⌬──══─┈•⤣🪐⤤•┈─══──⌬","description":"🎌 قــســم الــنــقــابــات ◌𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻","id":".ق8"},
                  {"title":"⌬──══─┈•⤣🪐⤤•┈─══──⌬","description":"🖼️ قــســم الــصــور ◌𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻","id":".ق9"},
                  {"title":"⌬──══─┈•⤣🪐⤤•┈─══──⌬","description":"⛄ قــســم الــتــســلــيــه ◌𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻","id":".ق10"}
                ]
              }],
              has_multiple_buttons: true
            })
          },
          {
            name: 'quick_reply',
            buttonParamsJson: JSON.stringify({ display_text: 'تنــصيب 𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 ⭐', id: '.تنصيب' })
          },
          {
            name: 'cta_url',
            buttonParamsJson: JSON.stringify({ display_text: "📢 القناة الرسمية", url: channel, merchant_url: channel })
          },
          {
            name: 'cta_url',
            buttonParamsJson: JSON.stringify({ display_text: '👑 التواصل مع المطور', url: developerContact, merchant_url: developerContact })
          }
        ],
        messageParamsJson: JSON.stringify({
          limited_time_offer: { text: `🦅 ${speed}ms`, url: developerContact, copy_code: `المطور: +${developerNumber}`, expiration_time: Date.now() + 86400000 },
          bottom_sheet: { in_thread_buttons_limit: 1, divider_indices: [1,2,3,4,5,6,7,8,9,999], list_title: "📂 قائمة أقسام البوت", button_title: "⭐ عرض الأقسام ⭐" },
          tap_target_configuration: { description: "ابدأ الآن مع 𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻", canonical_url: developerContact, domain: "https://wa.me/201030943917", button_index: 0 }
        })
      }
    }

    if (existsSync(localImagePath)) {
      try {
        const media = await prepareWAMessageMedia({ image: { url: localImagePath } }, { upload: conn.waUploadToServer })
        nativeFlowPayload.header = { hasMediaAttachment: true, subtitle: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 🦅', imageMessage: media.imageMessage }
      } catch (e) {
        nativeFlowPayload.header = { hasMediaAttachment: false, subtitle: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 🦅' }
      }
    } else {
      nativeFlowPayload.header = { hasMediaAttachment: false, subtitle: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 🦅' }
    }

    const interactiveMessage = proto.Message.InteractiveMessage.fromObject(nativeFlowPayload)
    const fkontak = await makeFkontak()
    const msg = generateWAMessageFromContent(m.chat, { interactiveMessage }, { userJid: conn.user.jid, quoted: fkontak })
    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

  } catch (e) {
    console.error('خطأ:', e)
    await conn.sendMessage(m.chat, { text: `𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 🦅\n\n⚠️ خطأ في تحميل القائمة` }, { quoted: m })
  }
}

async function makeFkontak() {
  try {
    const res = await fetch('https://cdn.russellxz.click/64bba973.jpg')
    const thumb2 = Buffer.from(await res.arrayBuffer())
    return {
      key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' },
      message: { locationMessage: { name: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 🦅', jpegThumbnail: thumb2 } },
      participant: '0@s.whatsapp.net'
    }
  } catch { return undefined }
}

async function getUptime() {
  let totalSeconds = process.uptime()
  let hours = Math.floor(totalSeconds / 3600)
  let minutes = Math.floor((totalSeconds % 3600) / 60)
  let seconds = Math.floor(totalSeconds % 60)
  return `${hours.toString().padStart(2,'0')}:${minutes.toString().padStart(2,'0')}:${seconds.toString().padStart(2,'0')}`
}

handler.help = ['ق10']
handler.tags = ['main']
handler.command = /^(ق10)$/i

export default handler
