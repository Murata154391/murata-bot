import { generateWAMessageFromContent, proto } from '@whiskeysockets/baileys'
import yts from 'yt-search'
import axios from 'axios'

// ══════════ ثوابت ══════════
const NEWSLETTER_JID  = '120363423359642420@newsletter'
const NEWSLETTER_NAME = '𝑴𝑼𝑹𝑨𝑻𝑨  𝑽𝑬𝑹𝑰𝑭𝑰𝑬𝑫  𝑺𝒀𝑺𝑻𝑬𝑴'
const CHANNEL_URL     = 'https://whatsapp.com/channel/0029Vb76oO3BA1euG0eIvA3a'
const D  = '*⌬──══─┈•⤣🎵⤤•┈─══──⌬*'
const DS = '*┃*'

// ══════════ makeFkontak ══════════
async function makeFkontak() {
  try {
    const res   = await fetch('https://cdn.russellxz.click/64bba973.jpg')
    const thumb = Buffer.from(await res.arrayBuffer())
    return {
      key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' },
      message: { locationMessage: { name: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 🦅', jpegThumbnail: thumb } },
      participant: '0@s.whatsapp.net'
    }
  } catch { return undefined }
}

// ══════════ sendInteractive - نفس نظام اللودو ══════════
async function sendInteractive(conn, jid, bodyText, footerText, buttons) {
  try {
    const payload = {
      body:   { text: bodyText },
      footer: { text: footerText || '🦅 𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻' },
      header: { hasMediaAttachment: false, subtitle: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 🦅' },
      nativeFlowMessage: {
        buttons,
        messageParamsJson: JSON.stringify({
          bottom_sheet: { in_thread_buttons_limit: 1, list_title: '🎵 MURATA MUSIC', button_title: '⭐ الأوامر ⭐' },
          tap_target_configuration: { description: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑴𝑼𝑺𝑰𝑪 🎵', canonical_url: CHANNEL_URL, domain: 'whatsapp.com', button_index: 0 }
        })
      }
    }
    const interactiveMessage = proto.Message.InteractiveMessage.fromObject(payload)
    const fkontak = await makeFkontak()
    const msg = generateWAMessageFromContent(jid, { interactiveMessage }, { userJid: conn.user.jid, quoted: fkontak })
    await conn.relayMessage(jid, msg.message, { messageId: msg.key.id })
  } catch {
    await conn.sendMessage(jid, {
      text: bodyText,
      contextInfo: {
        forwardedNewsletterMessageInfo: { newsletterJid: NEWSLETTER_JID, newsletterName: NEWSLETTER_NAME },
        isForwarded: true
      }
    })
  }
}

// ══════════ أزرار رئيسية ══════════
function mainFlow() {
  return [
    {
      name: 'single_select',
      buttonParamsJson: JSON.stringify({
        title: '🎵 أوامر الموسيقى',
        sections: [{
          title: `${D}`,
          rows: [
            { title: '⌬──══─┈•⤣🎵⤤•┈─══──⌬', description: '🎵 تحميل أغنية يوتيوب', id: '.شغل' },
            { title: '⌬──══─┈•⤣🎧⤤•┈─══──⌬', description: '🎧 استخراج صوت تيك توك', id: '.صوت' }
          ]
        }],
        has_multiple_buttons: true
      })
    },
    {
      name: 'quick_reply',
      buttonParamsJson: JSON.stringify({ display_text: '🎵 تحميل أغنية', id: '.شغل' })
    },
    {
      name: 'cta_url',
      buttonParamsJson: JSON.stringify({ display_text: '📢 قناة MURATA', url: CHANNEL_URL, merchant_url: CHANNEL_URL })
    }
  ]
}

// ══════════ أزرار بعد النجاح ══════════
function doneFlow() {
  return [
    {
      name: 'single_select',
      buttonParamsJson: JSON.stringify({
        title: '🎵 ماذا تريد؟',
        sections: [{
          title: `${D}`,
          rows: [
            { title: '⌬──══─┈•⤣🔁⤤•┈─══──⌬', description: '🔁 تحميل أغنية ثانية', id: '.شغل' },
            { title: '⌬──══─┈•⤣🎧⤤•┈─══──⌬', description: '🎧 استخراج صوت تيك توك', id: '.صوت' }
          ]
        }],
        has_multiple_buttons: true
      })
    },
    {
      name: 'quick_reply',
      buttonParamsJson: JSON.stringify({ display_text: '🔁 أغنية ثانية', id: '.شغل' })
    },
    {
      name: 'cta_url',
      buttonParamsJson: JSON.stringify({ display_text: '📢 قناة MURATA', url: CHANNEL_URL, merchant_url: CHANNEL_URL })
    }
  ]
}

// ══════════ Handler ══════════
const handler = async (m, { conn, args, text }) => {
  const jid   = m.chat
  const query = text?.trim() || ''

  await conn.sendMessage(jid, { react: { text: '🎧', key: m.key } })

  // ══ بدون بحث ══
  if (!query) {
    return sendInteractive(conn, jid,
      `${D}\n` +
      `${DS} 🎧 *يوتيوب - تحميل صوت*\n` +
      `${D}\n` +
      `${DS} 📝 *طريقة الاستخدام:*\n` +
      `${DS} *.شغل اسم الأغنية*\n` +
      `${D}\n` +
      `${DS} 💡 *أمثلة:*\n` +
      `${DS} .شغل ماشي صح\n` +
      `${DS} .شغل فيروز\n` +
      `${D}`,
      '🎵 𝑴𝑼𝑹𝑨𝑻𝑨 𝑴𝑼𝑺𝑰𝑪', mainFlow())
  }

  // ══ رسالة انتظار ══
  await sendInteractive(conn, jid,
    `${D}\n` +
    `${DS} 🔍 *جـاري البحث...*\n` +
    `${D}\n` +
    `${DS} 🎵 ${query}\n` +
    `${DS} ⏳ يرجى الانتظار...\n` +
    `${D}`,
    '⏳ جاري البحث...', mainFlow())

  try {
    const search = await yts(query)
    const video  = search.videos[0]

    // ══ ما لقى نتيجة ══
    if (!video) {
      return sendInteractive(conn, jid,
        `${D}\n` +
        `${DS} ❌ *ما لقيت نتيجة!*\n` +
        `${D}\n` +
        `${DS} 🔍 البحث: ${query}\n` +
        `${DS} 💡 جرب كلمات مختلفة\n` +
        `${D}`,
        '❌ لا توجد نتائج', mainFlow())
    }

    // ══ صورة + معلومات ══
    await conn.sendMessage(jid, {
      image: { url: video.thumbnail },
      caption:
        `${D}\n` +
        `${DS} 🎧 *جـاري التحميل...*\n` +
        `${D}\n` +
        `${DS} 📌 *العنوان:* ${video.title}\n` +
        `${DS} ⏱️ *المدة:* ${video.timestamp}\n` +
        `${DS} 📅 *نُشر:* ${video.ago}\n` +
        `${DS} 👀 *المشاهدات:* ${video.views?.toLocaleString?.() || video.views}\n` +
        `${D}\n` +
        `${DS} ⏳ جاري استخراج الصوت...\n` +
        `${D}`,
      contextInfo: {
        forwardedNewsletterMessageInfo: { newsletterJid: NEWSLETTER_JID, newsletterName: NEWSLETTER_NAME },
        isForwarded: true
      }
    }, { quoted: m })

    // ══ جلب الصوت ══
    let link     = ''
    let attempts = 0

    while (!link && attempts < 15) {
      attempts++
      const res = await axios.get(`https://youtube-mp36.p.rapidapi.com/dl?id=${video.videoId}`, {
        headers: {
          'X-RapidAPI-Key':  '5cc09ae315msh6da3f2202274304p1fd204jsn76046bb9d8e5',
          'X-RapidAPI-Host': 'youtube-mp36.p.rapidapi.com'
        },
        timeout: 30000
      })

      if (res.data?.status === 'ok' && res.data?.link) {
        link = res.data.link

        const audioRes = await axios.get(link, {
          responseType: 'arraybuffer',
          timeout: 120000,
          headers: { 'User-Agent': 'Mozilla/5.0', 'Referer': 'https://youtube-mp36.p.rapidapi.com/' }
        })

        if (audioRes.data?.byteLength > 10000) {
          await conn.sendMessage(jid, {
            audio: Buffer.from(audioRes.data),
            mimetype: 'audio/mpeg',
            fileName: `${video.title}.mp3`,
            contextInfo: {
              forwardedNewsletterMessageInfo: { newsletterJid: NEWSLETTER_JID, newsletterName: NEWSLETTER_NAME },
              isForwarded: true
            }
          }, { quoted: m })

          await conn.sendMessage(jid, { react: { text: '✅', key: m.key } })

          return sendInteractive(conn, jid,
            `${D}\n` +
            `${DS} ✅ *تم التحميل بنجاح!*\n` +
            `${D}\n` +
            `${DS} 🎵 ${video.title}\n` +
            `${DS} ⏱️ ${video.timestamp}\n` +
            `${D}\n` +
            `${DS} 🦅 _𝑴𝑼𝑹𝑨𝑻𝑨  𝑺𝒀𝑺𝑻𝑬𝑴_\n` +
            `${D}`,
            '✅ اكتمل التحميل', doneFlow())
        }
      } else {
        await new Promise(r => setTimeout(r, 3000))
      }
    }

    // ══ فشل ══
    return sendInteractive(conn, jid,
      `${D}\n${DS} ❌ *فشل التحميل!*\n${D}\n${DS} 💡 حاول مرة ثانية\n${D}`,
      '❌ فشل', mainFlow())

  } catch (e) {
    console.error('شغل error:', e.message)
    return sendInteractive(conn, jid,
      `${D}\n${DS} ⚠️ *حدث خطأ!*\n${D}\n${DS} 📝 ${e.message}\n${DS} 💡 حاول مرة ثانية\n${D}`,
      '⚠️ خطأ', mainFlow())
  }
}

handler.command = /^شغل$/i
handler.tags    = ['media']
handler.help    = ['شغل [اسم الأغنية]']

export default handler
