// ╔══════════════════════════════════════════╗
// ║  🎮 𝑳𝑼𝑫𝑶 𝑴𝑼𝑹𝑨𝑻𝑨 ● 𝑬𝑷𝑰𝑪 𝑬𝑫𝑰𝑻𝑰𝑶𝑵 🦅  ║
// ╚══════════════════════════════════════════╝

import { generateWAMessageFromContent, proto } from '@whiskeysockets/baileys'

if (!global.ludoRooms)  global.ludoRooms  = {}
if (!global.ludoTimers) global.ludoTimers = {}

// ══════════ ثوابت ══════════
const RANK_POINTS  = { 1: 500, 2: 200, 3: 0, 4: -200 }
const TRAP_BONUS   = 30
const QUAKE_BONUS  = 20
const SPEED_BONUS  = 150
const TURN_TIMEOUT = 30
const DEV_URL      = 'https://wa.me/201030943917'
const CHANNEL_URL  = 'https://whatsapp.com/channel/0029Vb76oO3BA1euG0eIvA3a'

// ══════════ زخرفة ══════════
const D = '*⌬──══─┈•⤣🎮⤤•┈─══──⌬*'
const DS = '*┃*'
const COLORS = ['🔴','🟢','🟡','🔵']
const BOT_NAME = '🤖 𝑴𝑼𝑹𝑨𝑻𝑨-𝑨𝑰'

// ══════════ helpers ══════════
const mention = id => `@${id.replace(/:[0-9]+/, '').split('@')[0]}`
const jidClean = id => id.replace(/:[0-9]+/, '')

// ══════════ makeFkontak ══════════
async function makeFkontak() {
  try {
    const res = await fetch('https://cdn.russellxz.click/64bba973.jpg')
    const thumb2 = Buffer.from(await res.arrayBuffer())
    return {
      key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' },
      message: { locationMessage: { name: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 🦅', jpegThumbnail: thumb2 } },
      participant: '0@s.whatsapp.net'
    }
  } catch { return undefined }
}

// ══════════ إرسال nativeFlow ══════════
async function sendInteractive(conn, jid, bodyText, footerText, buttons, mentionsList = []) {
  try {
    const payload = {
      body:   { text: bodyText },
      footer: { text: footerText || '◌𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 🦅' },
      header: { hasMediaAttachment: false, subtitle: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 🦅' },
      nativeFlowMessage: {
        buttons,
        messageParamsJson: JSON.stringify({
          bottom_sheet: { in_thread_buttons_limit: 1, list_title: '🎮 لودو MURATA', button_title: '⭐ الأوامر ⭐' },
          tap_target_configuration: { description: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑳𝑼𝑫𝑶 🎮', canonical_url: DEV_URL, domain: 'wa.me', button_index: 0 }
        })
      }
    }
    const interactiveMessage = proto.Message.InteractiveMessage.fromObject(payload)
    const fkontak = await makeFkontak()
    const msg = generateWAMessageFromContent(jid,
      { interactiveMessage },
      { userJid: conn.user.jid, quoted: fkontak }
    )
    const realMentions = mentionsList.filter(id => !id.startsWith('bot_')).map(jidClean)
    if (realMentions.length) {
      msg.message.interactiveMessage.contextInfo = {
        ...(msg.message.interactiveMessage.contextInfo || {}),
        mentionedJid: realMentions
      }
    }
    await conn.relayMessage(jid, msg.message, { messageId: msg.key.id })
  } catch (e) {
    await sendMsg(conn, jid, bodyText, mentionsList)
  }
}

// ══════════ أزرار الطاولة (انتظار) ══════════
function waitingFlow() {
  return [
    {
      name: 'single_select',
      buttonParamsJson: JSON.stringify({
        title: '📋 أوامر الطاولة',
        sections: [{
          title: `${D}`,
          rows: [
            { title: '⌬──══─┈•⤣🎮⤤•┈─══──⌬', description: '✋ انضم للطاولة', id: '.انضمام' },
            { title: '⌬──══─┈•⤣🎮⤤•┈─══──⌬', description: '▶️ ابدأ اللعبة', id: '.ابدأ' },
            { title: '⌬──══─┈•⤣🤖⤤•┈─══──⌬', description: '🤖 إضافة ذكاء - سهل 🟢', id: '.ذكاء سهل' },
            { title: '⌬──══─┈•⤣🤖⤤•┈─══──⌬', description: '🤖 إضافة ذكاء - متوسط 🟡', id: '.ذكاء متوسط' },
            { title: '⌬──══─┈•⤣🤖⤤•┈─══──⌬', description: '🤖 إضافة ذكاء - صعب 🔴', id: '.ذكاء صعب' },
            { title: '⌬──══─┈•⤣🤖⤤•┈─══──⌬', description: '🤖 إضافة ذكاء - خبير 👑', id: '.ذكاء خبير' },
            { title: '⌬──══─┈•⤣📊⤤•┈─══──⌬', description: '📊 الحالة الحالية', id: '.الحالة' },
            { title: '⌬──══─┈•⤣❌⤤•┈─══──⌬', description: '❌ إنهاء الطاولة', id: '.إنهاء' }
          ]
        }],
        has_multiple_buttons: true
      })
    },
    {
      name: 'cta_url',
      buttonParamsJson: JSON.stringify({ display_text: '📢 قناة MURATA', url: CHANNEL_URL, merchant_url: CHANNEL_URL })
    }
  ]
}

// ══════════ أزرار الدور ══════════
function turnFlow(cp) {
  return [
    {
      name: 'single_select',
      buttonParamsJson: JSON.stringify({
        title: '⚡ قدراتي وأوامري',
        sections: [
          {
            title: `${D}`,
            rows: [
              { title: '⌬──══─┈•⤣🎲⤤•┈─══──⌬', description: '🎲 رمي الزار - الأمر الرئيسي', id: '.رمي' },
              { title: '⌬──══─┈•⤣📊⤤•┈─══──⌬', description: '📊 عرض اللوحة الكاملة', id: '.الحالة' },
              { title: '⌬──══─┈•⤣⚡⤤•┈─══──⌬', description: '⚡ عرض كل قدراتي', id: '.باورز' }
            ]
          },
          {
            title: '*⌬──══─┈•⤣⚡⤤•┈─══──⌬*',
            rows: [
              { title: '⌬──══─┈•⤣⏩⤤•┈─══──⌬', description: `⏩ دبل الزار [${cp.doubles||0}/3] - نسبة 30%`, id: '.دبل' },
              { title: '⌬──══─┈•⤣🛡️⤤•┈─══──⌬', description: `🛡️ الدرع [${cp.shields||0}/1] - يصد الهجمات`, id: '.حماية' },
              { title: '⌬──══─┈•⤣🌍⤤•┈─══──⌬', description: `🌍 الزلزال [${cp.earthquakes||0}/3] - يضرب الكل`, id: '.زلزال' },
              { title: '⌬──══─┈•⤣💫⤤•┈─══──⌬', description: `💫 النجمة [${cp.stars||0}/1] - تحصين دور كامل`, id: '.نجمة' },
              { title: '⌬──══─┈•⤣⚡⤤•┈─══──⌬', description: `⚡ الصاعقة [${cp.lightnings||0}/1] - ترجع المتصدر لنص`, id: '.صاعقة' },
              { title: '⌬──══─┈•⤣🌪️⤤•┈─══──⌬', description: `🌪️ العاصفة [${cp.storms||0}/2] - سرقة خطوات`, id: '.عاصفة' },
              { title: '⌬──══─┈•⤣🔁⤤•┈─══──⌬', description: `🔁 عكس الأدوار [${cp.reverses||0}/1]`, id: '.عكس' },
              { title: '⌬──══─┈•⤣🃏⤤•┈─══──⌬', description: '🃏 بطاقة الحظ - مفاجأة عشوائية', id: '.بطاقة' },
              { title: '⌬──══─┈•⤣🎲⤤•┈─══──⌬', description: '🎲 ارمي الزار الآن!', id: '.رمي' },
              { title: '⌬──══─┈•⤣🚪⤤•┈─══──⌬', description: '🚪 انسحاب من اللعبة', id: '.انسحاب' }
            ]
          }
        ],
        has_multiple_buttons: true
      })
    },
    {
      name: 'quick_reply',
      buttonParamsJson: JSON.stringify({ display_text: '🎲 رمي الزار', id: '.رمي' })
    },
    {
      name: 'quick_reply',
      buttonParamsJson: JSON.stringify({ display_text: '⚡ قدراتي', id: '.باورز' })
    }
  ]
}


// ══════════ زر الرمي السريع ══════════
function rollOnlyFlow() {
  return [
    {
      name: 'quick_reply',
      buttonParamsJson: JSON.stringify({ display_text: '🎲 رمي الزار', id: '.رمي' })
    },
    {
      name: 'quick_reply',
      buttonParamsJson: JSON.stringify({ display_text: '⚡ قدراتي', id: '.باورز' })
    }
  ]
}

// ══════════ أزرار المشاهد ══════════
function watcherFlow() {
  return [
    {
      name: 'single_select',
      buttonParamsJson: JSON.stringify({
        title: '📋 أوامر المشاهد',
        sections: [{
          title: `${D}`,
          rows: [
            { title: '⌬──══─┈•⤣⚡⤤•┈─══──⌬', description: '⚡ عرض قدراتي', id: '.باورز' },
            { title: '⌬──══─┈•⤣📊⤤•┈─══──⌬', description: '📊 عرض اللوحة', id: '.الحالة' },
            { title: '⌬──══─┈•⤣🚪⤤•┈─══──⌬', description: '🚪 انسحاب من اللعبة', id: '.انسحاب' }
          ]
        }],
        has_multiple_buttons: true
      })
    }
  ]
}

// ══════════ إرسال عادي ══════════
async function sendMsg(conn, jid, text, mentions = []) {
  const verifiedQuoted = {
    key: { fromMe: false, participant: '0@s.whatsapp.net', remoteJid: '0@s.whatsapp.net' },
    message: {
      videoMessage: { caption: ` 𝑴𝑼𝑹𝑨𝑻𝑨 | 🦅 `, jpegThumbnail: Buffer.alloc(0), gifPlayback: true },
      extendedTextMessage: { text: `𝑮𝑰𝑭  𝑴𝑼𝑹𝑨𝑻𝑨 ●`, title: 'WhatsApp Business', matchedText: 'verified' }
    }
  }
  return conn.sendMessage(jid, {
    text,
    mentions: mentions.filter(id => !id.startsWith('bot_')).map(jidClean),
    contextInfo: {
      forwardedNewsletterMessageInfo: {
        newsletterJid: global.ch1 || '120363423359642420@newsletter',
        newsletterName: global.namebot || '🦅 𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻'
      },
      isForwarded: true
    }
  }, { quoted: verifiedQuoted })
}


// ══════════ إرسال زر الرمي بعد القدرة ══════════
async function sendRollBtn(conn, jid, text, mentions = []) {
  const realMentions = mentions.filter(id => !id.startsWith('bot_'))
  await sendInteractive(conn, jid, text, '🎲 𝑴𝑼𝑹𝑨𝑻𝑨 𝑳𝑼𝑫𝑶', rollOnlyFlow(), realMentions)
}

// ══════════ لوحة اللعبة ══════════
function buildBoard(room) {
  const WIN = room.target
  let b = `${D}\n`
  b += `${DS} 🎮 *𝑴𝑼𝑹𝑨𝑻𝑨 𝑳𝑼𝑫𝑶 ●*\n`
  b += `${D}\n`
  room.players.forEach((p, i) => {
    const prog  = Math.min(8, Math.floor((room.positions[i] / WIN) * 8))
    const track = '▰'.repeat(prog) + '🔘' + '▱'.repeat(Math.max(0, 7 - prog))
    const icons = (p.isShielded ? '🛡️' : '') + (p.isStarred ? '💫' : '') + (p.isBot ? '🤖' : '')
    const name  = p.isBot ? BOT_NAME : mention(p.id)
    const arrow = i === room.turn ? ' *◄*' : ''
    b += `${DS} ${COLORS[i]} ${name}${arrow} ${icons}\n`
    b += `${DS} ${track} *[${room.positions[i]}/${WIN}]*\n`
  })
  b += `${D}`
  return b
}

// ══════════ init اللاعب ══════════
function initPlayer(p) {
  p.traps=2; p.shields=1; p.doubles=1; p.earthquakes=1
  p.swaps=0; p.storms=1; p.stars=1; p.lightnings=1
  p.snipers=1; p.reverses=1
  p.isShielded=false; p.shieldTurns=0
  p.isStarred=false;  p.starTurns=0
  p.usedPower=false;  p.isDoubled=false
}

function addPoints(num, pts)    { return pts }
function removePoints(num, pts) { return 0 }

// ══════════ تايمر ══════════
function clearLudoTimer(jid) {
  if (global.ludoTimers[jid]) { clearTimeout(global.ludoTimers[jid]); delete global.ludoTimers[jid] }
}

function startTurnTimer(conn, jid, room) {
  clearLudoTimer(jid)
  const cp = room.players[room.turn]
  if (cp?.isBot) {
    global.ludoTimers[jid] = setTimeout(() => executeBotTurn(conn, jid), 2000)
    return
  }
  global.ludoTimers[jid] = setTimeout(async () => {
    const r = global.ludoRooms[jid]
    if (!r || r.status !== 'playing') return
    const skipped = r.players[r.turn]
    r.skipStreak = (r.skipStreak || 0) + 1

    if (r.skipStreak >= 3) {
      r.skipStreak = 0
      const kickIdx = r.turn
      r.turn = r.isReversed ? (r.turn-1+r.players.length)%r.players.length : (r.turn+1)%r.players.length
      if (r.turn > kickIdx) r.turn--
      r.players.splice(kickIdx,1); r.positions.splice(kickIdx,1); r.throwCounts?.splice(kickIdx,1)
      if (r.players.length < 2) {
        const w = r.players[0]
        clearLudoTimer(jid); delete global.ludoRooms[jid]
        return sendMsg(conn, jid,
          `${D}\n${DS} ⏰ *انتهت بسبب الغياب!*\n${D}\n${DS} 👋 مطرود: ${mention(skipped.id)}\n${DS} 🏆 فائز: ${w.isBot?BOT_NAME:mention(w.id)}\n${D}`,
          [skipped.id, w.id])
      }
      await sendMsg(conn, jid,
        `${D}\n${DS} ⚠️ *طُرد من اللعبة!*\n${D}\n${DS} 😴 ${mention(skipped.id)} - غاب 3 مرات\n${DS} 🎲 الدور: ${r.players[r.turn].isBot?BOT_NAME:mention(r.players[r.turn].id)}\n${D}`,
        r.players.map(p=>p.id).concat(skipped.id))
    } else {
      r.turn = r.isReversed ? (r.turn-1+r.players.length)%r.players.length : (r.turn+1)%r.players.length
      const np = r.players[r.turn]
      await sendMsg(conn, jid,
        `${D}\n${DS} ⏰ *انتهى الوقت!*\n${D}\n${DS} 😴 ${mention(skipped.id)} تخطي (${r.skipStreak}/3)\n${DS} 🎲 الدور: ${np.isBot?BOT_NAME:mention(np.id)}\n${DS} ⏱️ ${TURN_TIMEOUT} ثانية\n${D}`,
        r.players.map(p=>p.id))
    }
    if (global.ludoRooms[jid]) startTurnTimer(conn, jid, global.ludoRooms[jid])
  }, TURN_TIMEOUT * 1000)
}

// ══════════ ذكاء البوت ══════════
function botThink(room, botIdx) {
  const cp   = room.players[botIdx]
  const pos  = room.positions[botIdx]
  const WIN  = room.target
  const diff = cp.difficulty || 'medium'
  const lead = Math.max(...room.positions.filter((_,i)=>i!==botIdx))
  const rand = Math.random() * 100

  if (diff==='easy') return 'رمي'

  if (diff==='medium') {
    if (pos>=WIN-6 && cp.doubles>0 && !cp.usedPower) return 'دبل'
    if (lead-pos>12 && cp.lightnings>0 && !cp.usedPower && rand<50) return 'صاعقة'
    if (cp.traps>0 && !cp.usedPower && rand<40) {
      const v = room.players.filter((p,i)=>i!==botIdx&&!p.isBot)
      if (v.length) return {power:'فخ',target:v[0].id}
    }
    return 'رمي'
  }

  if (diff==='hard') {
    if (pos>=WIN-8 && cp.doubles>0 && !cp.usedPower) return 'دبل'
    if (lead-pos>8 && cp.lightnings>0 && !cp.usedPower) return 'صاعقة'
    if (cp.traps>0 && !cp.usedPower && rand<70) {
      const v = room.players.filter((_,i)=>i!==botIdx)
      const top = v.reduce((a,b)=>room.positions[room.players.indexOf(b)]>room.positions[room.players.indexOf(a)]?b:a, v[0])
      if (top) return {power:'فخ',target:top.id}
    }
    if (cp.earthquakes>0 && room.players.length>=3 && !cp.usedPower && rand<60) return 'زلزال'
    if (pos<5 && cp.shields>0 && !cp.usedPower && rand<50) return 'حماية'
    return 'رمي'
  }

  // expert
  if (pos>=WIN-10 && cp.doubles>0 && !cp.usedPower) return 'دبل'
  if (lead-pos>6 && cp.lightnings>0 && !cp.usedPower) return 'صاعقة'
  if (cp.earthquakes>0 && room.players.length>=3 && !cp.usedPower && rand<75) return 'زلزال'
  if (cp.traps>0 && !cp.usedPower) {
    const v = room.players.filter((_,i)=>i!==botIdx)
    const top = v.reduce((a,b)=>{const ai=room.players.indexOf(a),bi=room.players.indexOf(b);return room.positions[bi]>room.positions[ai]?b:a}, v[0])
    if (top) return {power:'فخ',target:top.id}
  }
  if (cp.storms>0 && !cp.usedPower && rand<60) {
    const v = room.players.filter((_,i)=>i!==botIdx)
    if (v.length) return {power:'عاصفة',target:v[0].id}
  }
  if (cp.shields>0 && !cp.isShielded && !cp.usedPower && rand<40) return 'حماية'
  if (cp.stars>0 && !cp.isStarred && !cp.usedPower && rand<30) return 'نجمة'
  return 'رمي'
}

// ══════════ تنفيذ قدرة البوت ══════════
async function applyBotPower(conn, jid, room, botIdx, power, targetId) {
  const cp = room.players[botIdx]

  if (power==='دبل' && cp.doubles>0) {
    cp.doubles--; cp.usedPower=true
    const ok = Math.random()*100<=30; cp.isDoubled=ok
    await sendMsg(conn, jid, ok
      ? `${D}\n${DS} 🤖 *𝑴𝑼𝑹𝑨𝑻𝑨-𝑨𝑰 استخدم الدبل!* ⏩\n${DS} 🔥 الرمية القادمة مضاعفة!\n${D}`
      : `${D}\n${DS} 🤖 *𝑴𝑼𝑹𝑨𝑻𝑨-𝑨𝑰 جرب الدبل ❌ فشل!*\n${D}`, [])

  } else if (power==='صاعقة' && cp.lightnings>0) {
    cp.lightnings--; cp.usedPower=true
    let li=-1, mx=-1
    room.positions.forEach((pos,i)=>{if(i!==botIdx&&pos>mx){mx=pos;li=i}})
    if (li!==-1 && !room.players[li].isShielded && !room.players[li].isStarred) {
      const old=room.positions[li]; room.positions[li]=Math.floor(old/2)
      await sendMsg(conn, jid,
        `${D}\n${DS} ⚡ *𝑴𝑼𝑹𝑨𝑻𝑨-𝑨𝑰 أطلق صاعقة!*\n${D}\n${DS} 🎯 ${mention(room.players[li].id)}\n${DS} 📉 ${old} ← ${room.positions[li]}\n${D}`,
        room.players.map(p=>p.id))
    }

  } else if (power==='زلزال' && cp.earthquakes>0) {
    cp.earthquakes--; cp.usedPower=true
    let dmg=''
    room.players.forEach((p,i)=>{
      if(p.id===cp.id) return
      if(p.isStarred||p.isShielded){if(p.isShielded)p.isShielded=false;dmg+=`\n${DS} 🛡️ ${mention(p.id)}: محمي`;return}
      const red=Math.floor(Math.random()*4)+5; room.positions[i]=Math.max(0,room.positions[i]-red)
      dmg+=`\n${DS} 📉 ${mention(p.id)}: -${red}`
    })
    await sendMsg(conn, jid,
      `${D}\n${DS} 🌍 *𝑴𝑼𝑹𝑨𝑻𝑨-𝑨𝑰 فجّر زلزالاً!*${dmg}\n${D}`,
      room.players.map(p=>p.id))

  } else if (power==='فخ' && cp.traps>0 && targetId) {
    cp.traps--; cp.usedPower=true
    const ti=room.players.findIndex(p=>p.id===targetId)
    if (ti!==-1 && !room.players[ti].isStarred && !room.players[ti].isShielded) {
      const red=Math.floor(Math.random()*3)+3; room.positions[ti]=Math.max(0,room.positions[ti]-red)
      await sendMsg(conn, jid,
        `${D}\n${DS} 🕸️ *𝑴𝑼𝑹𝑨𝑻𝑨-𝑨𝑰 نصب فخاً!*\n${DS} 🎯 ${mention(targetId)}: -${red} خطوة\n${D}`,
        room.players.map(p=>p.id))
    }

  } else if (power==='عاصفة' && cp.storms>0 && targetId) {
    cp.storms--; cp.usedPower=true
    const ti=room.players.findIndex(p=>p.id===targetId)
    if (ti!==-1 && !room.players[ti].isStarred) {
      const steal=Math.floor(Math.random()*4)+3, oldT=room.positions[ti]
      room.positions[ti]=Math.max(0,room.positions[ti]-steal)
      const actual=oldT-room.positions[ti]; room.positions[botIdx]=Math.min(room.target,room.positions[botIdx]+actual)
      await sendMsg(conn, jid,
        `${D}\n${DS} 🌪️ *𝑴𝑼𝑹𝑨𝑻𝑨-𝑨𝑰 أطلق عاصفة!*\n${DS} 💨 سرق ${actual} من ${mention(targetId)}\n${D}`,
        room.players.map(p=>p.id))
    }

  } else if (power==='حماية' && cp.shields>0 && !cp.isShielded) {
    cp.shields--; cp.usedPower=true; cp.isShielded=true; cp.shieldTurns=3
    await sendMsg(conn, jid, `${D}\n${DS} 🛡️ *𝑴𝑼𝑹𝑨𝑻𝑨-𝑨𝑰 فعّل الدرع!*\n${D}`, [])

  } else if (power==='نجمة' && cp.stars>0 && !cp.isStarred) {
    cp.stars--; cp.usedPower=true; cp.isStarred=true; cp.starTurns=room.players.length
    await sendMsg(conn, jid, `${D}\n${DS} 💫 *𝑴𝑼𝑹𝑨𝑻𝑨-𝑨𝑰 فعّل النجمة!*\n${D}`, [])
  }
}

// ══════════ تنفيذ دور البوت ══════════
async function executeBotTurn(conn, jid) {
  const room = global.ludoRooms[jid]
  if (!room || room.status !== 'playing') return
  const cp = room.players[room.turn]
  if (!cp?.isBot) return

  const botIdx    = room.turn
  const diffEmoji = {easy:'🟢',medium:'🟡',hard:'🔴',expert:'👑'}[cp.difficulty||'medium']||'🟡'
  const decision  = botThink(room, botIdx)

  await sendMsg(conn, jid,
    `${D}\n${DS} 🤖 *𝑴𝑼𝑹𝑨𝑻𝑨-𝑨𝑰 يفكر...* ${diffEmoji}\n${DS} ${cp.color} اللاعب ${botIdx+1}\n${D}`, [])

  await new Promise(r=>setTimeout(r,1500))

  if (typeof decision==='object') await applyBotPower(conn,jid,room,botIdx,decision.power,decision.target)
  else if (decision!=='رمي')      await applyBotPower(conn,jid,room,botIdx,decision,null)

  await new Promise(r=>setTimeout(r,1000))
  if (global.ludoRooms[jid]) await doRoll(conn, jid, global.ludoRooms[jid], botIdx, true)
}

// ══════════ رمي الزار ══════════
async function doRoll(conn, jid, room, playerIdx, isBot=false) {
  clearLudoTimer(jid)
  const cp  = room.players[playerIdx]
  const WIN = room.target || 30

  ;['doubles','traps','swaps','shields','earthquakes','storms','stars','lightnings','snipers','reverses']
    .forEach(k=>{if(cp[k]===undefined)cp[k]=0})

  const base = Math.floor(Math.random()*6)+1
  const dice = cp.isDoubled ? base*2 : base
  const rem  = WIN - room.positions[playerIdx]
  let moveMsg=''

  if (dice<=rem) { room.positions[playerIdx]+=dice; moveMsg=`✅ تقدّمت *${dice}* خطوة!` }
  else             moveMsg=`⚠️ الزار (${dice}) أكبر من المطلوب (${rem})`

  if (!room.throwCounts) room.throwCounts=room.players.map(()=>0)
  room.throwCounts[playerIdx]=(room.throwCounts[playerIdx]||0)+1
  room.skipStreak=0

  // ══ فوز ══
  if (room.positions[playerIdx]===WIN) {
    if (!room.finishOrder) room.finishOrder=[]
    room.finishOrder.push({id:cp.id,throws:room.throwCounts[playerIdx],isBot:cp.isBot})
    room.players.filter(p=>!room.finishOrder.find(f=>f.id===p.id))
      .forEach(p=>room.finishOrder.push({id:p.id,throws:room.throwCounts[room.players.indexOf(p)]||0,isBot:p.isBot}))

    const medals=['🥇','🥈','🥉','🏅']
    let w=`${D}\n${DS} 🏆 *𝑮𝑨𝑴𝑬 𝑶𝑽𝑬𝑹! 𝑴𝑼𝑹𝑨𝑻𝑨 ●* 🏆\n${D}\n`
    room.finishOrder.forEach((e,i)=>{
      const rPts=RANK_POINTS[i+1]??-200, fast=i===0&&e.throws<=15*room.players.length
      const total=rPts+(fast?SPEED_BONUS:0), name=e.isBot?BOT_NAME:mention(e.id)
      let nb=null
      if(!e.isBot) nb=total>=0?addPoints(e.id.split('@')[0],total):removePoints(e.id.split('@')[0],Math.abs(total))
      w+=`${DS} ${medals[i]||'🏅'} ${name}\n`
      w+=`${DS} ${total>=0?'+':''}${total} نقطة${fast?` ⚡+${SPEED_BONUS}`:''}${nb!==null?` | ${nb.toLocaleString()}`:''}\n`
    })
    w+=`${D}\n🎊 *مبروك! 𝑴𝑼𝑹𝑨𝑻𝑨 ●*`
    clearLudoTimer(jid); delete global.ludoRooms[jid]
    return sendMsg(conn, jid, w, room.players.map(p=>p.id))
  }

  // ══ مكافآت ══
  let rewards=''
  const rng=()=>Math.random()*100
  if(rng()<=10&&cp.doubles<3){let a=Math.min(3-cp.doubles,rng()<=3?2:1);cp.doubles+=a;rewards+=`\n${DS} 🎁 +${a} دبل (${cp.doubles}/3)`}
  if(rng()<=15&&cp.traps<3) {let a=Math.min(3-cp.traps,rng()<=5?2:1);cp.traps+=a;rewards+=`\n${DS} 🎁 +${a} فخ (${cp.traps}/3)`}
  if(rng()<=5&&cp.shields<1)     {cp.shields=1;rewards+=`\n${DS} 🎁 درع!`}
  if(rng()<=4&&cp.earthquakes<3) {cp.earthquakes++;rewards+=`\n${DS} 🎁 زلزال (${cp.earthquakes}/3)`}
  if(rng()<=2&&cp.swaps<1)       {cp.swaps=1;rewards+=`\n${DS} 🎁 تبديل!`}
  if(rng()<=5&&cp.storms<2)      {cp.storms++;rewards+=`\n${DS} 🎁 عاصفة (${cp.storms}/2)`}
  if(rng()<=3&&cp.snipers<2)     {cp.snipers++;rewards+=`\n${DS} 🎁 قناص (${cp.snipers}/2)`}

  if(cp.isShielded){cp.shieldTurns--;if(cp.shieldTurns<=0){cp.isShielded=false;rewards+=`\n${DS} 🛡️ انتهى الدرع`}}
  if(cp.isStarred) {cp.starTurns--;  if(cp.starTurns<=0)  {cp.isStarred=false; rewards+=`\n${DS} 💫 انتهت النجمة`}}

  cp.usedPower=false; cp.isDoubled=false
  room.moveCount=(room.moveCount||0)+1

  const board      = buildBoard(room)
  const playerName = isBot ? BOT_NAME : mention(cp.id)
  const diceEmoji  = ['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣'][Math.min(dice,6)-1]

  // ══ تحديد الدور التالي ══
  let nextTxt = ''
  if (base===6) {
    nextTxt=`\n${DS} 🌟 *رمية ذهبية!* ${playerName} يرمي مرة أخرى!`
    if(isBot&&global.ludoRooms[jid]) setTimeout(()=>executeBotTurn(conn,jid),2000)
  } else {
    room.turn = room.isReversed
      ? (room.turn-1+room.players.length)%room.players.length
      : (room.turn+1)%room.players.length
    const np=room.players[room.turn]
    nextTxt=`\n${DS} 🎯 *التالي:* ${np.isBot?BOT_NAME:mention(np.id)}`
  }

  const fullText =
    `${D}\n${DS} 🎲 *رمية ${playerName}*\n${D}\n` +
    board + '\n' +
    `${D}\n` +
    `${DS} ${diceEmoji} *الزار: ${dice}*${cp.isDoubled?' *(مضاعف!)*':''}\n` +
    `${DS} ${moveMsg}` +
    (rewards||'') + nextTxt +
    `\n${DS} ⏱️ ${TURN_TIMEOUT} ثانية\n${D}`

  // ══ كل اللاعبين يظهرون كتاج ══
  const allMentions = room.players.map(p=>p.id)
  const nextPlayer  = room.players[room.turn]

  if (base!==6 && nextPlayer && !nextPlayer.isBot) {
    await sendInteractive(conn, jid, fullText, `⏱️ ${TURN_TIMEOUT} ثانية | 🎮 𝑴𝑼𝑹𝑨𝑻𝑨 𝑳𝑼𝑫𝑶`, rollOnlyFlow(), allMentions)
  } else {
    await sendMsg(conn, jid, fullText, allMentions)
  }

  if (global.ludoRooms[jid] && base!==6) startTurnTimer(conn, jid, global.ludoRooms[jid])
}

// ╔══════════════════════════════════════════╗
// ║            HANDLER الرئيسي              ║
// ╚══════════════════════════════════════════╝
const handler = async (m, { conn, args, text, usedPrefix, command, isOwner, isAdmin, isBotAdmin, isROwner, isPrems, groupMetadata, participants }) => {

  const jid    = m.chat
  const sender = m.sender
  const sNum   = sender.replace(/:[0-9]+/,'').split('@')[0]
  const cmd    = command

  const send  = (txt, ments=[]) => sendMsg(conn, jid, txt, ments)
  const react = (e) => conn.sendMessage(jid, { react: { text: e, key: m.key } })

  // ══ getMentioned - يدعم @تاج والرقم المكتوب ══
  const getMentioned = () => {
    // أولاً: منشن عادي @tag
    const fromTag =
      m.mentionedJid?.[0] ||
      m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || null
    if (fromTag) return fromTag

    // ثانياً: رقم مكتوب مثل .فخ 0501234567
    const numArg = (args[0] || '').replace(/[^0-9]/g, '')
    if (numArg.length >= 9) {
      const r = global.ludoRooms[jid]
      if (r) {
        const match = r.players.find(p => {
          const clean = p.id.replace(/:[0-9]+/, '').split('@')[0]
          return clean.endsWith(numArg) || numArg.endsWith(clean.slice(-9))
        })
        if (match) return match.id
        return `${numArg}@s.whatsapp.net`
      }
    }
    return null
  }

  // ══ .لودو ══
  if (cmd==='لودو') {
    if (global.ludoRooms[jid]) return send(
      `${D}\n${DS} ⚠️ فيه لعبة شغالة!\n${DS} استخدم *.إنهاء* أولاً\n${D}`, [sender])

    const target=parseInt(args[0])||30
    if (target<10||target>100) return send(
      `${D}\n${DS} ❌ الهدف بين *10* و*100*\n${DS} مثال: *.لودو 50*\n${D}`, [sender])

    global.ludoRooms[jid]={
      status:'waiting',
      players:[{id:sender,name:m.name||'لاعب',color:COLORS[0]}],
      positions:[0], turn:0, target,
      moveCount:0, throwCounts:[0], finishOrder:[], isReversed:false, skipStreak:0
    }

    let txt=`${D}\n`
    txt+=`${DS} 🎮 *𝑳𝑼𝑫𝑶 𝑴𝑼𝑹𝑨𝑻𝑨 ●* 🦅\n`
    txt+=`${D}\n`
    txt+=`${DS} 👑 المنشئ: ${mention(sender)}\n`
    txt+=`${DS} 👥 العدد: [1/4]\n`
    txt+=`${DS} 🎯 الهدف: *${target}* خطوة\n`
    txt+=`${DS} ⏱️ التايمر: *${TURN_TIMEOUT}* ثانية\n`
    txt+=`${D}\n`
    txt+=`${DS} 🏆 *المكافآت:*\n`
    txt+=`${DS} 🥇 +500 | 🥈 +200 | 🥉 0 | 💀 -200\n`
    txt+=`${DS} ⚡ سرعة: *+${SPEED_BONUS}* بونص!\n`
    txt+=`${D}\n`
    txt+=`${DS} 🤖 *مستويات البوت:*\n`
    txt+=`${DS} 🟢 سهل | 🟡 متوسط | 🔴 صعب | 👑 خبير\n`
    txt+=`${D}`

    return sendInteractive(conn, jid, txt, '🎮 𝑴𝑼𝑹𝑨𝑻𝑨 𝑳𝑼𝑫𝑶 ● جاهز!', waitingFlow(), [sender])
  }

  // ══ .ذكاء ══
  if (cmd==='ذكاء') {
    if(!global.ludoRooms[jid]) return send(`${D}\n${DS} ❌ أنشئ طاولة *.لودو*\n${D}`,[])
    const room=global.ludoRooms[jid]
    if(room.status==='playing') return send(`${D}\n${DS} ⚠️ اللعبة بدأت!\n${D}`,[])
    if(room.players.length>=4)  return send(`${D}\n${DS} ❌ الطاولة ممتلئة!\n${D}`,[])
    if(!room.players.find(p=>p.id===sender)) return send(`${D}\n${DS} ⚠️ فقط المنشئ يضيف بوت!\n${D}`,[])
    const bots=room.players.filter(p=>p.isBot).length
    if(bots>=3) return send(`${D}\n${DS} ❌ أقصى 3 بوتات\n${D}`,[])

    const lv=(args[0]||'').toLowerCase()
    let difficulty='medium', diffLabel='متوسط 🟡', diffEmoji='🟡'
    if(['سهل','easy','1'].includes(lv))         {difficulty='easy';  diffLabel='سهل 🟢';  diffEmoji='🟢'}
    else if(['صعب','hard','3'].includes(lv))    {difficulty='hard';  diffLabel='صعب 🔴';  diffEmoji='🔴'}
    else if(['خبير','expert','4'].includes(lv)) {difficulty='expert';diffLabel='خبير 👑'; diffEmoji='👑'}

    room.players.push({id:`bot_${bots+1}@s.whatsapp.net`,name:BOT_NAME,color:COLORS[room.players.length],isBot:true,difficulty})
    room.positions.push(0); room.throwCounts.push(0)

    return sendInteractive(conn, jid,
      `${D}\n${DS} 🤖 *𝑴𝑼𝑹𝑨𝑻𝑨-𝑨𝑰 انضم!*\n${D}\n`+
      `${DS} ${COLORS[room.players.length-1]} البوت #${bots+1}\n`+
      `${DS} ${diffEmoji} المستوى: *${diffLabel}*\n`+
      `${DS} 👥 العدد الآن: [${room.players.length}/4]\n`+
      `${D}\n${DS} 📝 *.ابدأ* للعب\n${D}`,
      '🤖 𝑴𝑼𝑹𝑨𝑻𝑨-𝑨𝑰 جاهز!', waitingFlow(), [sender])
  }

  // ══ .ابدأ ══
  if (cmd==='ابدأ') {
    if(!global.ludoRooms[jid]) return send(`${D}\n${DS} ❌ *.لودو* لإنشاء روم\n${D}`,[])
    const room=global.ludoRooms[jid]
    if(room.status==='playing') return send(`${D}\n${DS} ◀️ اللعبة بدأت!\n${D}`,[])
    if(room.players.length<2)   return send(`${D}\n${DS} ❌ تحتاج لاعبين أكثر! (${room.players.length}/4)\n${D}`,[])

    await react('🔥')
    room.status='playing'; room.throwCounts=room.players.map(()=>0); room.skipStreak=0
    room.players.forEach(initPlayer)

    let msg=`${D}\n${DS} 🔥 *𝑩𝑨𝑻𝑻𝑳𝑬 𝑺𝑻𝑨𝑹𝑻𝑺! 𝑴𝑼𝑹𝑨𝑻𝑨 ●*\n${D}\n`
    room.players.forEach((p,i)=>{
      const nm=p.isBot?`${BOT_NAME} [${({easy:'سهل',medium:'متوسط',hard:'صعب',expert:'خبير'})[p.difficulty]||'متوسط'}]`:mention(p.id)
      msg+=`${DS} ${COLORS[i]} ${nm}\n${DS} 🕸️×2 🛡️×1 ⏩×1 🌍×1 🌪️×1 💫×1 ⚡×1 🎯×1 🔁×1\n`
    })
    const fp=room.players[0]
    msg+=`${D}\n${DS} 🎲 الأول: ${fp.isBot?BOT_NAME:mention(fp.id)}\n${DS} ⏱️ ${TURN_TIMEOUT} ثانية لكل دور\n${D}`

    const allMentions=room.players.map(p=>p.id)
    if (!fp.isBot) await sendInteractive(conn, jid, msg, '🔥 𝑩𝑨𝑻𝑻𝑳𝑬 𝑺𝑻𝑨𝑹𝑻𝑺!', turnFlow(fp), allMentions)
    else           await sendMsg(conn, jid, msg, allMentions)
    startTurnTimer(conn, jid, room)
    return
  }

  // ══ .انضمام ══
  if (cmd==='انضمام') {
    if(!global.ludoRooms[jid]) return
    const room=global.ludoRooms[jid]
    if(!room.rejoinList) room.rejoinList={}

    if(room.withdrawnData?.[sender]) {
      if(room.rejoinList[sender]>=1) return send(`${D}\n${DS} ❌ استنفدت فرصتك!\n${D}`,[sender])
      if(room.players.length>=4)    return send(`${D}\n${DS} ❌ الروم ممتلئ!\n${D}`,[])
      const saved=room.withdrawnData[sender]
      room.players.push(saved.player); room.positions.push(saved.position); room.throwCounts.push(saved.throwCount||0)
      room.rejoinList[sender]=1; delete room.withdrawnData[sender]
      return sendRollBtn(conn, jid, `${D}\n${DS} ✅ *عاد المحارب!*\n${D}\n${DS} 👤 ${mention(sender)}\n${DS} 📍 [${saved.position}/${room.target}]\n${D}`,[sender])
    }

    if(room.status==='playing') return send(`${D}\n${DS} ⚠️ اللعبة بدأت!\n${D}`,[])
    if(room.players.length>=4)  return send(`${D}\n${DS} ❌ الروم ممتلئ!\n${D}`,[sender])
    if(room.players.find(p=>p.id===sender)) return send(`${D}\n${DS} 🔥 أنت منضم بالفعل!\n${D}`,[sender])

    room.players.push({id:sender,name:m.name||'لاعب',color:COLORS[room.players.length]})
    room.positions.push(0); room.throwCounts.push(0)
    const cnt=room.players.length

    await sendInteractive(conn, jid,
      `${D}\n${DS} ⚔️ *محارب جديد!*\n${D}\n`+
      `${DS} ${COLORS[cnt-1]} ${mention(sender)}\n`+
      `${DS} 👥 [${cnt}/4]\n`+
      `${D}`,
      '⚔️ انضم للمعركة!', waitingFlow(), [sender])

    if(cnt===4) {
      room.status='playing'; room.throwCounts=room.players.map(()=>0); room.skipStreak=0
      room.players.forEach(initPlayer)
      let msg=`${D}\n${DS} 🔥 *بدأت تلقائياً! [4/4]*\n${D}\n`
      room.players.forEach((p,i)=>{msg+=`${DS} ${COLORS[i]} ${p.isBot?BOT_NAME:mention(p.id)}\n`})
      msg+=`${D}\n${DS} 🎲 الأول: ${mention(room.players[0].id)}\n${DS} ⏱️ ${TURN_TIMEOUT} ثانية\n${D}`
      const allMentions=room.players.map(p=>p.id)
      await sendInteractive(conn, jid, msg, '🔥 𝑩𝑨𝑻𝑻𝑳𝑬 𝑺𝑻𝑨𝑹𝑻𝑺!', turnFlow(room.players[0]), allMentions)
      startTurnTimer(conn, jid, room)
    }
  }

  // ══ .انسحاب ══
  if (cmd==='انسحاب') {
    if(!global.ludoRooms[jid]) return
    const room=global.ludoRooms[jid]
    const pi=room.players.findIndex(p=>p.id===sender)
    if(pi===-1) return
    clearLudoTimer(jid)
    if(!room.withdrawnData) room.withdrawnData={}
    room.withdrawnData[sender]={player:{...room.players[pi]},position:room.positions[pi],throwCount:room.throwCounts?.[pi]||0}
    const wp=room.players[pi]
    if(room.turn===pi) room.turn=(room.turn+1)%room.players.length
    else if(room.turn>pi) room.turn--
    room.players.splice(pi,1); room.positions.splice(pi,1); room.throwCounts?.splice(pi,1)
    await react('👋')

    if(room.players.length<2) {
      const w=room.players[0]; const nb=!w.isBot?addPoints(w.id.split('@')[0],RANK_POINTS[1]):null
      delete global.ludoRooms[jid]
      return send(
        `${D}\n${DS} 🚪 *انسحاب وانتهاء!*\n${D}\n`+
        `${DS} 👋 ${mention(sender)}\n`+
        `${DS} 🏆 فائز: ${w.isBot?BOT_NAME:mention(w.id)}\n`+
        (nb?`${DS} 💎 +${RANK_POINTS[1]} نقطة\n`:'')+
        `${D}`,[sender,w.id])
    }

    const np=room.players[room.turn]
    const withdrawMentions = room.players.map(p=>p.id).concat(sender)
    const withdrawTxt = `${D}\n${DS} 🚪 *غادر محارب!*\n${D}\n`+
      `${DS} 👤 ${mention(sender)} (${wp.color})\n`+
      `${DS} 💡 عودة: *.انضمام*\n`+
      `${DS} 🎲 الدور: ${np.isBot?BOT_NAME:mention(np.id)}\n`+
      `${DS} ⏱️ ${TURN_TIMEOUT} ثانية\n${D}`
    if (!np.isBot) {
      await sendInteractive(conn, jid, withdrawTxt, '🎮 𝑴𝑼𝑹𝑨𝑻𝑨 𝑳𝑼𝑫𝑶', rollOnlyFlow(), withdrawMentions)
    } else {
      await sendMsg(conn, jid, withdrawTxt, withdrawMentions)
    }
    startTurnTimer(conn, jid, room)
  }

  // ══ .إنهاء ══
  if (cmd==='إنهاء'||cmd==='انهاء') {
    if(!global.ludoRooms[jid]) return send(`${D}\n${DS} ⚠️ لا توجد طاولة\n${D}`,[])
    const room=global.ludoRooms[jid]
    if(!isOwner&&!room.players.some(p=>p.id===sender)) return send(`${D}\n${DS} ⚠️ المشاركون فقط\n${D}`,[])
    clearLudoTimer(jid); delete global.ludoRooms[jid]
    await react('⛔️')
    return send(`${D}\n${DS} 🚫 *تم إنهاء الطاولة!*\n${DS} 👤 ${mention(sender)}\n${DS} 💡 *.لودو* لطاولة جديدة\n${D}`,[sender])
  }

  // ══ .الحالة ══
  if (cmd==='الحالة') {
    if(!global.ludoRooms[jid]) return send(`${D}\n${DS} ❌ لا توجد لعبة!\n${D}`,[])
    const room=global.ludoRooms[jid]
    const txt=buildBoard(room)+`\n${D}\n`+
      `${DS} 📊 *إحصائيات:*\n`+
      `${DS} الحالة: ${room.status==='playing'?'▶️ شغّالة':'⏳ انتظار'}\n`+
      `${DS} اللاعبون: ${room.players.length}/4\n`+
      `${DS} الهدف: *${room.target}* خطوة\n`+
      `${DS} الأدوار: ${room.moveCount||0}\n`+
      `${DS} الاتجاه: ${room.isReversed?'⬅️ معكوس':'➡️ عادي'}\n${D}`
    const isPlaying = room.status === 'playing'
    const cp2 = isPlaying ? room.players[room.turn] : null
    const isMyTurn = cp2 && jidClean(cp2.id) === jidClean(sender)
    const statusMentions = room.players.map(p=>p.id)
    if (isPlaying && isMyTurn && !cp2.isBot) {
      await sendInteractive(conn, jid, txt, '📊 𝑴𝑼𝑹𝑨𝑻𝑨 𝑳𝑼𝑫𝑶', rollOnlyFlow(), statusMentions)
    } else if (!isPlaying) {
      await sendInteractive(conn, jid, txt, '📊 𝑴𝑼𝑹𝑨𝑻𝑨 𝑳𝑼𝑫𝑶', waitingFlow(), statusMentions)
    } else {
      await sendMsg(conn, jid, txt, statusMentions)
    }
    return
  }

  // ══ .باورز ══
  if (cmd==='باورز') {
    if(!global.ludoRooms[jid]) return send(`${D}\n${DS} ❌ لا توجد لعبة!\n${D}`,[])
    const room=global.ludoRooms[jid]
    const pl=room.players.find(p=>p.id===sender)
    if(!pl) return send(`${D}\n${DS} ⚠️ أنت لست مشاركاً!\n${D}`,[])
    const idx=room.players.indexOf(pl)
    const sh=pl.isShielded?`✅ (${pl.shieldTurns} رميات)`:'❌'
    const st=pl.isStarred?`✅ (${pl.starTurns} رميات)`:'❌'

    let txt=`${D}\n${DS} ⚡ *مخزن القدرات 𝑴𝑼𝑹𝑨𝑻𝑨*\n${D}\n`
    txt+=`${DS} 👤 ${mention(sender)} ${pl.color}\n${D}\n`
    txt+=`${DS} 🕸️ *فخ:*      [${pl.traps??0}/3]\n`
    txt+=`${DS} ⏩ *دبل:*     [${pl.doubles??0}/3] *(30%)*\n`
    txt+=`${DS} 🛡️ *درع:*     [${pl.shields??0}/1] ${sh}\n`
    txt+=`${DS} 🌍 *زلزال:*  [${pl.earthquakes??0}/3]\n`
    txt+=`${DS} 🔄 *تبديل:*  [${pl.swaps??0}/1]\n`
    txt+=`${DS} 🌪️ *عاصفة:*  [${pl.storms??0}/2]\n`
    txt+=`${DS} 💫 *نجمة:*   [${pl.stars??0}/1] ${st}\n`
    txt+=`${DS} ⚡ *صاعقة:* [${pl.lightnings??0}/1]\n`
    txt+=`${DS} 🎯 *قناص:*   [${pl.snipers??0}/2]\n`
    txt+=`${DS} 🔁 *عكس:*    [${pl.reverses??0}/1]\n${D}\n`
    txt+=`${DS} 📍 موقعك: [${room.positions[idx]}/${room.target}]\n`
    txt+=`${DS} 🎲 رمياتك: ${room.throwCounts?.[idx]||0}\n${D}\n`
    txt+=`${DS} ⚠️ *استخدم القدرة قبل الرمي*\n${D}`
    await react('⚡')
    const isMyTurnP = room.status==='playing' && jidClean(room.players[room.turn]?.id)===jidClean(sender)
    if (isMyTurnP) {
      return sendInteractive(conn, jid, txt, '⚡ قدراتك جاهزة!', turnFlow(pl), [sender])
    }
    return sendInteractive(conn, jid, txt, '⚡ مخزن القدرات', rollOnlyFlow(), [sender])
  }

  // ══ تحقق اللعبة شغالة ══
  if(!global.ludoRooms[jid]) return
  const room=global.ludoRooms[jid]
  if(room.status!=='playing') return
  const cp=room.players[room.turn]

  // ══ .رمي ══
  if (cmd==='رمي') {
    if(jidClean(sender)!==jidClean(cp.id))
      return send(`${D}\n${DS} ⚠️ *ليس دورك!*\n${DS} 🎯 الحالي: ${cp.isBot?BOT_NAME:mention(cp.id)}\n${D}`,[cp.id])
    await react('🎲')
    return doRoll(conn, jid, room, room.turn, false)
  }

  // ══ قفل الأزرار لغير صاحب الدور ══
  const powerCmds=['فخ','حماية','دبل','زلزال','تبديل','بطاقة','عاصفة','نجمة','صاعقة','قناص','عكس']
  if(jidClean(sender)!==jidClean(cp.id)) {
    if(powerCmds.includes(cmd))
      return send(`${D}\n${DS} 🔒 *انتظر دورك!*\n${DS} 🎯 الحالي: ${cp.isBot?BOT_NAME:mention(cp.id)}\n${D}`,[cp.id])
    return
  }

  const chk=()=>{
    if(cp.usedPower){ sendRollBtn(conn, jid, `${D}\n${DS} ⚠️ استخدمت قدرة بالفعل!\n${DS} 📝 *.رمي*\n${D}`,[sender]); return false }
    return true
  }

  // ══ .فخ ══
  if (cmd==='فخ') {
    if(!cp.traps||cp.traps<=0) return sendRollBtn(conn, jid, `${D}\n${DS} ❌ لا تملك فخاخ!\n${D}`,[sender])
    if(!chk()) return
    const t=getMentioned()
    if(!t) return sendRollBtn(conn, jid, `${D}\n${DS} ⚠️ منشن الخصم!\n${DS} *.فخ @شخص* أو *.فخ رقم*\n${D}`,[sender])
    const ti=room.players.findIndex(p=>jidClean(p.id)===jidClean(t))
    if(ti===-1||jidClean(t)===jidClean(sender)) return sendRollBtn(conn, jid, `${D}\n${DS} ⚠️ هدف غير صحيح!\n${D}`,[sender])
    await react('🕸️'); cp.traps--; cp.usedPower=true
    if(room.players[ti].isStarred)  return sendRollBtn(conn, jid, `${D}\n${DS} 💫 النجمة حمت ${mention(t)}!\n${DS} 🎫 فخ متبقي: ${cp.traps}\n${DS} 📝 *.رمي*\n${D}`,[sender,t])
    if(room.players[ti].isShielded) { room.players[ti].isShielded=false; return sendRollBtn(conn, jid, `${D}\n${DS} 🛡️ تحطم الدرع!\n${DS} ${mention(t)} خسر درعه\n${DS} 🎫 فخ متبقي: ${cp.traps}\n${DS} 📝 *.رمي*\n${D}`,[sender,t]) }
    const c=Math.random()*100, red=c<=1?Math.floor(Math.random()*6)+10:c<=16?Math.floor(Math.random()*4)+6:Math.floor(Math.random()*3)+3
    const old=room.positions[ti]; room.positions[ti]=Math.max(0,room.positions[ti]-red)
    addPoints(sNum,TRAP_BONUS)
    return sendRollBtn(conn, jid, `${D}\n${DS} 🕸️ *الفخ نجح!*\n${D}\n${DS} 🎯 ${mention(t)}\n${DS} 📉 -${old-room.positions[ti]} خطوة\n${DS} 💎 +${TRAP_BONUS} نقطة!\n${DS} 🎫 فخ متبقي: ${cp.traps}\n${DS} 📝 *.رمي*\n${D}`,room.players.map(p=>p.id))
  }

  // ══ .حماية ══
  if (cmd==='حماية') {
    if(!cp.shields||cp.shields<=0) return sendRollBtn(conn, jid, `${D}\n${DS} ❌ لا تملك دروع!\n${D}`,[sender])
    if(cp.isShielded) return sendRollBtn(conn, jid, `${D}\n${DS} 🛡️ الدرع مفعّل! (${cp.shieldTurns} رميات)\n${D}`,[sender])
    if(!chk()) return
    cp.shields--; cp.usedPower=true; cp.isShielded=true; cp.shieldTurns=3
    await react('🛡️')
    return sendRollBtn(conn, jid, `${D}\n${DS} 🛡️ *الدرع مفعّل!*\n${D}\n${DS} ⏳ 3 رميات\n${DS} 🎫 درع متبقي: ${cp.shields}\n${DS} 📝 *.رمي*\n${D}`,[sender])
  }

  // ══ .دبل ══
  if (cmd==='دبل') {
    if(!cp.doubles||cp.doubles<=0) return sendRollBtn(conn, jid, `${D}\n${DS} ❌ لا تملك دبل!\n${D}`,[sender])
    if(!chk()) return
    cp.doubles--; cp.usedPower=true
    await react('⏩')
    const ok=Math.random()*100<=30; cp.isDoubled=ok
    return sendRollBtn(conn, jid, ok
      ? `${D}\n${DS} 🔥 *نجح الدبل!* ⏩\n${D}\n${DS} 🎲 الرمية القادمة مضاعفة!\n${DS} 🎫 دبل متبقي: ${cp.doubles}\n${DS} 📝 *.رمي*\n${D}`
      : `${D}\n${DS} ❌ *فشل الدبل!*\n${D}\n${DS} 🎲 الرمية عادية\n${DS} 🎫 دبل متبقي: ${cp.doubles}\n${DS} 📝 *.رمي*\n${D}`,[sender])
  }

  // ══ .زلزال ══
  if (cmd==='زلزال') {
    if(!cp.earthquakes||cp.earthquakes<=0) return sendRollBtn(conn, jid, `${D}\n${DS} ❌ لا تملك زلازل!\n${D}`,[sender])
    if(!chk()) return
    await react('🌍'); cp.earthquakes--; cp.usedPower=true
    let dmg='', hits=0
    room.players.forEach((p,i)=>{
      if(jidClean(p.id)===jidClean(sender)) return
      if(p.isStarred)  {dmg+=`\n${DS} 💫 ${mention(p.id)}: محمي!`;return}
      if(p.isShielded) {p.isShielded=false;dmg+=`\n${DS} 🛡️ ${mention(p.id)}: تحطم درعه!`;return}
      const red=Math.floor(Math.random()*4)+5, old=room.positions[i]
      room.positions[i]=Math.max(0,room.positions[i]-red)
      dmg+=`\n${DS} 📉 ${mention(p.id)}: -${old-room.positions[i]}`; hits++
    })
    if(hits>0){const b=QUAKE_BONUS*hits; addPoints(sNum,b); dmg+=`\n${DS} 💎 +${b} نقطة!`}
    return sendRollBtn(conn, jid, `${D}\n${DS} 🌋 *زلزال مدمّر!*\n${D}\n${DS} 💥 ${mention(sender)}${dmg}\n${DS} 🎫 زلزال متبقي: ${cp.earthquakes}\n${DS} 📝 *.رمي*\n${D}`,room.players.map(p=>p.id))
  }

  // ══ .تبديل ══
  if (cmd==='تبديل') {
    if(!cp.swaps||cp.swaps<=0) return sendRollBtn(conn, jid, `${D}\n${DS} ❌ لا تملك تبديل!\n${D}`,[sender])
    if(!chk()) return
    cp.swaps--; cp.usedPower=true
    const sd=Math.floor(Math.random()*6)+1, rd=Math.floor(Math.random()*6)+1
    const ok=Math.random()<0.5&&sd===rd
    if(ok){
      let ti=-1, mx=room.positions[room.turn]
      room.positions.forEach((pos,i)=>{if(i!==room.turn&&pos>mx){mx=pos;ti=i}})
      if(ti!==-1){
        [room.positions[room.turn],room.positions[ti]]=[room.positions[ti],room.positions[room.turn]]
        const tn=room.players[ti].isBot?BOT_NAME:mention(room.players[ti].id)
        return sendRollBtn(conn, jid, `${D}\n${DS} 🌀 *نجح التبديل!*\n${D}\n${DS} ✅ تبدلت مع: ${tn}\n${DS} 🎫 تبديل متبقي: ${cp.swaps}\n${DS} 📝 *.رمي*\n${D}`,[sender,room.players[ti].id])
      }
      return sendRollBtn(conn, jid, `${D}\n${DS} ⚠️ أنت في المقدمة!\n${D}`,[sender])
    }
    return sendRollBtn(conn, jid, `${D}\n${DS} ❌ *فشل التبديل!*\n${D}\n${DS} 🎲 الزار: ${sd} (المطلوب: ${rd})\n${DS} 📝 *.رمي*\n${D}`,[sender])
  }

  // ══ .بطاقة ══
  if (cmd==='بطاقة') {
    if(cp.lastCardTurn===undefined) cp.lastCardTurn=-100
    const rw=room.players.length*2, cm=room.moveCount||0
    if(cm-cp.lastCardTurn<rw){const l=Math.ceil((rw-(cm-cp.lastCardTurn))/room.players.length); return sendRollBtn(conn, jid, `${D}\n${DS} ⏳ انتظر *${l}* جولات للبطاقة\n${D}`,[sender])}
    if(!chk()) return
    await react('🃏'); cp.lastCardTurn=cm; cp.usedPower=true
    const rand=Math.random()*100; let cc='',et='',ce=''
    if(rand<=0.1){cc='الكونية 🌌';ce='👑';cp.traps=3;cp.doubles=3;cp.earthquakes=3;cp.shields=1;cp.swaps=1;cp.storms=2;cp.stars=1;cp.lightnings=1;cp.snipers=2;cp.reverses=1;cp.isShielded=true;cp.shieldTurns=5;room.positions[room.turn]=Math.min(room.target,room.positions[room.turn]+15);et='💥 كل القدرات Full + 15 خطوة + درع ملكي!'}
    else if(rand<=15){cc='الخضراء 🟢';ce='🟢';const p=Math.floor(Math.random()*3);if(p===0){let s=Math.floor(Math.random()*6)+5;room.positions[room.turn]=Math.min(room.target,room.positions[room.turn]+s);et=`✨ تقدمت ${s} خطوات!`}else if(p===1){cp.earthquakes=3;et='🌋 +3 زلازل!'}else{cp.isShielded=true;cp.shieldTurns=3;et='🛡️ درع 3 أدوار!'}}
    else if(rand<=60){cc='الصفراء 🟡';ce='🟡';const p=Math.floor(Math.random()*4);if(p===0){let s=Math.floor(Math.random()*3)+1;room.positions[room.turn]=Math.min(room.target,room.positions[room.turn]+s);et=`🏃 +${s} خطوات!`}else if(p===1){cp.traps=Math.min(3,(cp.traps||0)+1);et='🕸️ +1 فخ!'}else if(p===2){cp.doubles=Math.min(3,(cp.doubles||0)+1);et='⏩ +1 دبل!'}else{cp.storms=Math.min(2,(cp.storms||0)+1);et='🌪️ +1 عاصفة!'}}
    else{cc='الحمراء 🔴';ce='🔴';const p=Math.floor(Math.random()*3);if(p===0){let b=Math.floor(Math.random()*4)+3;room.positions[room.turn]=Math.max(0,room.positions[room.turn]-b);et=`📉 -${b} خطوات!`}else if(p===1){cp.earthquakes=Math.max(0,(cp.earthquakes||0)-1);et='🌑 -1 زلزال!'}else{cp.traps=Math.max(0,(cp.traps||0)-1);et='❌ -1 فخ!'}}
    return sendRollBtn(conn, jid, `${D}\n${DS} 🃏 *بطاقة الحظ 𝑴𝑼𝑹𝑨𝑻𝑨*\n${D}\n${DS} 👤 ${mention(sender)}\n${DS} ${ce} *${cc}*\n${D}\n${DS} 📝 ${et}\n${DS} 📍 [${room.positions[room.turn]}/${room.target}]\n${DS} 📝 *.رمي*\n${D}`,[sender])
  }

  // ══ .عاصفة ══
  if (cmd==='عاصفة') {
    if(!cp.storms||cp.storms<=0) return sendRollBtn(conn, jid, `${D}\n${DS} ❌ لا تملك عواصف!\n${D}`,[sender])
    if(!chk()) return
    const t=getMentioned()
    if(!t) return sendRollBtn(conn, jid, `${D}\n${DS} ⚠️ منشن الخصم!\n${DS} *.عاصفة @شخص* أو *.عاصفة رقم*\n${D}`,[sender])
    const ti=room.players.findIndex(p=>jidClean(p.id)===jidClean(t))
    if(ti===-1||jidClean(t)===jidClean(sender)) return sendRollBtn(conn, jid, `${D}\n${DS} ⚠️ هدف غير صحيح!\n${D}`,[sender])
    await react('🌪️'); cp.storms--; cp.usedPower=true
    if(room.players[ti].isStarred) return sendRollBtn(conn, jid, `${D}\n${DS} 💫 النجمة حمت ${mention(t)}!\n${DS} 🎫 عاصفة متبقي: ${cp.storms}\n${DS} 📝 *.رمي*\n${D}`,[sender,t])
    const steal=Math.floor(Math.random()*4)+3, oldT=room.positions[ti]
    room.positions[ti]=Math.max(0,room.positions[ti]-steal)
    const actual=oldT-room.positions[ti]; room.positions[room.turn]=Math.min(room.target,room.positions[room.turn]+actual)
    return sendRollBtn(conn, jid, `${D}\n${DS} 🌪️ *عاصفة ضاربة!*\n${D}\n${DS} 🎯 ${mention(t)}\n${DS} 💨 سرقت *${actual}* خطوة!\n${DS} 📍 موقعك: [${room.positions[room.turn]}/${room.target}]\n${DS} 🎫 عاصفة متبقي: ${cp.storms}\n${DS} 📝 *.رمي*\n${D}`,room.players.map(p=>p.id))
  }

  // ══ .نجمة ══
  if (cmd==='نجمة') {
    if(!cp.stars||cp.stars<=0) return sendRollBtn(conn, jid, `${D}\n${DS} ❌ لا تملك نجوم!\n${D}`,[sender])
    if(cp.isStarred) return sendRollBtn(conn, jid, `${D}\n${DS} 💫 النجمة مفعّلة!\n${D}`,[sender])
    if(!chk()) return
    await react('💫'); cp.stars--; cp.usedPower=true; cp.isStarred=true; cp.starTurns=room.players.length
    return sendRollBtn(conn, jid, `${D}\n${DS} 💫 *النجمة مفعّلة!*\n${D}\n${DS} 🛡️ محصن دور كامل\n${DS} ⏳ ${cp.starTurns} رميات\n${DS} 🎫 نجمة متبقي: ${cp.stars}\n${DS} 📝 *.رمي*\n${D}`,[sender])
  }

  // ══ .صاعقة ══
  if (cmd==='صاعقة') {
    if(!cp.lightnings||cp.lightnings<=0) return sendRollBtn(conn, jid, `${D}\n${DS} ❌ لا تملك صواعق!\n${D}`,[sender])
    if(!chk()) return
    await react('⚡'); cp.lightnings--; cp.usedPower=true
    let li=-1, mx=-1
    room.positions.forEach((pos,i)=>{if(i!==room.turn&&pos>mx){mx=pos;li=i}})
    if(li===-1) return sendRollBtn(conn, jid, `${D}\n${DS} ⚠️ أنت المتصدر!\n${D}`,[sender])
    const lead=room.players[li]
    if(lead.isShielded){lead.isShielded=false;return sendRollBtn(conn, jid, `${D}\n${DS} ⚡ الصاعقة تحطمت على الدرع!\n${DS} 🛡️ ${lead.isBot?BOT_NAME:mention(lead.id)}\n${DS} 🎫 صاعقة متبقي: ${cp.lightnings}\n${DS} 📝 *.رمي*\n${D}`,[sender,lead.id])}
    if(lead.isStarred) return sendRollBtn(conn, jid, `${D}\n${DS} 💫 النجمة حمت ${lead.isBot?BOT_NAME:mention(lead.id)}!\n${DS} 🎫 صاعقة متبقي: ${cp.lightnings}\n${DS} 📝 *.رمي*\n${D}`,[sender,lead.id])
    const oldL=room.positions[li]; room.positions[li]=Math.floor(oldL/2)
    return sendRollBtn(conn, jid, `${D}\n${DS} ⚡ *صاعقة مدمّرة!*\n${D}\n${DS} 🎯 ${lead.isBot?BOT_NAME:mention(lead.id)}\n${DS} 📉 ${oldL} ← ${room.positions[li]}\n${DS} 🎫 صاعقة متبقي: ${cp.lightnings}\n${DS} 📝 *.رمي*\n${D}`,room.players.map(p=>p.id))
  }

  // ══ .قناص ══
  if (cmd==='قناص') {
    if(!cp.snipers||cp.snipers<=0) return sendRollBtn(conn, jid, `${D}\n${DS} ❌ لا تملك قناص!\n${D}`,[sender])
    if(!chk()) return
    const t=getMentioned()
    if(!t) return sendRollBtn(conn, jid, `${D}\n${DS} ⚠️ منشن الخصم!\n${DS} *.قناص @شخص* أو *.قناص رقم*\n${D}`,[sender])
    const ti=room.players.findIndex(p=>jidClean(p.id)===jidClean(t))
    if(ti===-1||jidClean(t)===jidClean(sender)) return sendRollBtn(conn, jid, `${D}\n${DS} ⚠️ هدف غير صحيح!\n${D}`,[sender])
    await react('🎯'); cp.snipers--; cp.usedPower=true
    if(room.players[ti].isShielded){room.players[ti].isShielded=false;return sendRollBtn(conn, jid, `${D}\n${DS} 🎯 القناص تحطم على الدرع!\n${DS} 🛡️ ${mention(t)}\n${DS} 🎫 قناص متبقي: ${cp.snipers}\n${DS} 📝 *.رمي*\n${D}`,[sender,t])}
    if(room.players[ti].isStarred) return sendRollBtn(conn, jid, `${D}\n${DS} 💫 النجمة حمت ${mention(t)}!\n${DS} 🎫 قناص متبقي: ${cp.snipers}\n${DS} 📝 *.رمي*\n${D}`,[sender,t])
    const steal=Math.floor(Math.random()*5)+4, oldT=room.positions[ti]
    room.positions[ti]=Math.max(0,room.positions[ti]-steal)
    const actual=oldT-room.positions[ti]; room.positions[room.turn]=Math.min(room.target,room.positions[room.turn]+actual)
    return sendRollBtn(conn, jid, `${D}\n${DS} 🎯 *ضربة القناص!*\n${D}\n${DS} 🎯 ${mention(t)}\n${DS} 💨 سرقت *${actual}* خطوة!\n${DS} 📍 موقعك: [${room.positions[room.turn]}/${room.target}]\n${DS} 🎫 قناص متبقي: ${cp.snipers}\n${DS} 📝 *.رمي*\n${D}`,room.players.map(p=>p.id))
  }

  // ══ .عكس ══
  if (cmd==='عكس') {
    if(!cp.reverses||cp.reverses<=0) return sendRollBtn(conn, jid, `${D}\n${DS} ❌ لا تملك عكس!\n${D}`,[sender])
    if(!chk()) return
    await react('🔁'); cp.reverses--; cp.usedPower=true
    room.isReversed=!room.isReversed
    return sendRollBtn(conn, jid, `${D}\n${DS} 🔁 *عكس الأدوار!*\n${D}\n${DS} ${room.isReversed?'⬅️ الأدوار معكوسة':'➡️ الأدوار عادية'}\n${DS} 🎫 عكس متبقي: ${cp.reverses}\n${DS} 📝 *.رمي*\n${D}`,room.players.map(p=>p.id))
  }
}

handler.command = /^(لودو|ابدأ|انضمام|انسحاب|إنهاء|انهاء|رمي|فخ|حماية|دبل|زلزال|تبديل|بطاقة|باورز|عاصفة|نجمة|صاعقة|قناص|عكس|الحالة|ذكاء)$/i
handler.tags    = ['games']
handler.help    = ['لودو [هدف]','ذكاء [سهل|متوسط|صعب|خبير]','ابدأ','انضمام','انسحاب','إنهاء','رمي','فخ @شخص','حماية','دبل','زلزال','عاصفة @شخص','نجمة','صاعقة','قناص @شخص','عكس','تبديل','بطاقة','باورز','الحالة']
handler.group   = true

export default handler
