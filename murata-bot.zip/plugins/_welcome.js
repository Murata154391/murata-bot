import chalk from 'chalk'
let WAMessageStubType = (await import('@whiskeysockets/baileys')).default

const NEWSLETTER_JID  = '120363423359642420@newsletter'
const NEWSLETTER_NAME = '𝑴𝑼𝑹𝑨𝑻𝑨  𝑽𝑬𝑹𝑰𝑭𝑰𝑬𝑫  𝑺𝒀𝑺𝑻𝑬𝑴'

let rtxWelcome = `*⌬──══─┈•⤣🦅⤤•┈─══──⌬*`
let rtxBye     = `*⌬──══─┈•⤣🦅⤤•┈─══──⌬*`

let handler = (m) => m
handler.before = async function (m, { conn, participants, groupMetadata, isBotAdmin }) {
    if (!m.isGroup) return
    const chat = global.db?.data?.chats?.[m.chat] || {}
    if (!chat.welcome) return
    if (m.messageStubType === undefined) return

    let participantId = m.messageStubParameters?.[0] || m.sender
    let userName = participantId.split('@')[0]

    const contextInfo = {
        mentionedJid: [participantId],
        forwardedNewsletterMessageInfo: {
            newsletterJid: NEWSLETTER_JID,
            newsletterName: NEWSLETTER_NAME
        },
        isForwarded: true,
        forwardingScore: 9999999
    }

    // ترحيب
    if (m.messageStubType == 27) {
        let subject = groupMetadata.subject || 'المجموعة'
        let descs   = groupMetadata.desc || '۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ⃝𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻َ 𝅄'

        let defaultWelcome =
            `${rtxWelcome}\n\n` +
            `*⃝🦅┆👤 مــرحــبــًا @${userName}*\n` +
            `*⃝🌙┆📋 أهــلاً وســهــلاً بــك فــي مــجــمــوعــة:*\n` +
            `*⃝🦅┆📍 ${subject}*\n\n` +
            `*⃝🌙┆📝 وصــف الــمــجــمــوعــة:*\n` +
            `*⃝🦅┆💬 ${descs}*\n` +
            `${rtxWelcome}`

        let textWel = chat.sWelcome
            ? chat.sWelcome
                .replace(/@user/g, `@${userName}`)
                .replace(/@group/g, subject)
                .replace(/@desc/g, descs)
            : defaultWelcome

        await this.sendMessage(m.chat, { text: textWel, contextInfo }, { quoted: null })
        return
    }

    // وداع
    if (m.messageStubType == 28 || m.messageStubType == 32) {
        let subject = groupMetadata.subject || 'المجموعة'

        let defaultBye =
            `${rtxBye}\n\n` +
            `*⃝🦅┆👤 @${userName}*\n` +
            `*⃝🌙┆😢 غــادر الــمــجــمــوعــة*\n` +
            `*⃝🦅┆📍 ${subject}*\n` +
            `${rtxBye}`

        let textBye = chat.sBye
            ? chat.sBye
                .replace(/@user/g, `@${userName}`)
                .replace(/@group/g, subject)
            : defaultBye

        await this.sendMessage(m.chat, { text: textBye, contextInfo }, { quoted: null })
        return
    }
}

export default handler
