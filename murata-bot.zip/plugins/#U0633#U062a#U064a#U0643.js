/* تـم الـتـنـسـيـق بـحـسـب طـلـب الـمـطـور: 𝑴𝑼𝑹𝑨𝑻𝑨 🍁 */

import fetch from 'node-fetch'
import { addExif } from '../lib/sticker.js'
import { Sticker } from 'wa-sticker-formatter'
import { exec } from 'child_process'
import { writeFileSync, readFileSync, existsSync, unlinkSync } from 'fs'
import { downloadContentFromMessage } from '@whiskeysockets/baileys'

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//            𝑴𝑼𝑹𝑨𝑻𝑨 - هاندلر موحد للستيكر
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

let handler = async (m, { conn, args, usedPrefix, command }) => {
  const isAnimated = ['متحرك', 'animated', 'gif'].includes(command)
  let stiker = false

  try {
    let [packname, ...author] = args.join(' ').split('|')
    author = (author || []).join('|')
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || q.mediaType || ''

    // ── لا وسائط ولا رابط ──
    if (!mime && !(args[0] && isUrl(args[0]))) {
      await m.react('🦅')

      // ── أزرار الاختيار ──
      return await conn.sendMessage(m.chat, {
        text:
`⌬──══─┈•⤣🦅⤤•┈─══──⌬

🦅 *اخـتـر نـوع الـمـلـصـق:*

رد عـلـى وسـائـط ثـم اسـتـخـدم الأمـر:

✦ *${usedPrefix}ستيكر* — ملصق ثابت (صورة/webp)
✦ *${usedPrefix}متحرك* — ملصق متحرك (فيديو/gif)

لـحـقـوق مـخـصـصـة:
*${usedPrefix + command} اسـمـي | حـقـوقـي*

⌬──══─┈•⤣🦅⤤•┈─══──⌬`,
        buttons: [
          {
            buttonId: `${usedPrefix}ستيكر`,
            buttonText: { displayText: '🖼️ ملصق ثابت' },
            type: 1
          },
          {
            buttonId: `${usedPrefix}متحرك`,
            buttonText: { displayText: '🎞️ ملصق متحرك' },
            type: 1
          }
        ],
        headerType: 1
      }, { quoted: m })
    }

    await m.react('⏳⃝🦅')

    // ━━━━━━━━━━━━━━━━━━━━━━
    //   أمـر: ستيكر ثابت
    // ━━━━━━━━━━━━━━━━━━━━━━
    if (!isAnimated) {
      if (/webp/g.test(mime)) {
        let img = await q.download?.()
        stiker = await addExif(img, packname || global.packname, author || global.author)

      } else if (/image/g.test(mime)) {
        let img = await q.download?.()
        stiker = await createSticker(img, false, packname || global.packname, author || global.author)

      } else if (/video/g.test(mime)) {
        if ((q.msg || q).seconds > 10)
          return m.reply('⚠️⃝🦅 الـفـيـديـو طـويـل جـداً، أرسـل مـقـطع أقـل مـن 7 ثـوانٍ.')
        let img = await q.download?.()
        stiker = await mp4ToWebp(img, { pack: packname || global.packname, author: author || global.author })

      } else if (args[0] && isUrl(args[0])) {
        stiker = await createSticker(false, args[0], '', author, 20)

      } else {
        await m.react('🦅')
        return m.reply('⚠️⃝🦅 أرسـل صـورة أو فـيـديـو أو رابـط صـورة.')
      }

    // ━━━━━━━━━━━━━━━━━━━━━━
    //   أمـر: ستيكر متحرك
    // ━━━━━━━━━━━━━━━━━━━━━━
    } else {
      if (!/video/g.test(mime))
        return m.reply('⚠️⃝🦅 الـرجـاء الـرد عـلـى *فـيـديـو* قـصـيـر فـقـط.')

      if ((q.msg || q).seconds > 10)
        return m.reply('⚠️⃝🦅 الـفـيـديـو طـويـل جـداً، حـاول مـقـطع أقـل مـن 7 ثـوانٍ.')

      // تحميل الفيديو عبر Baileys
      const videoMsg = q.msg || q
      const stream = await downloadContentFromMessage(videoMsg, 'video')
      let buffer = Buffer.from([])
      for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk])

      const tempIn  = `./tmp_v_${Date.now()}.mp4`
      const tempOut = `./tmp_s_${Date.now()}.webp`
      writeFileSync(tempIn, buffer)

      // تحويل ffmpeg
      const ffmpegCmd = `ffmpeg -i ${tempIn} -vcodec libwebp \
-filter:v "fps=fps=12,scale=512:512:force_original_aspect_ratio=decrease,\
format=rgba,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000" \
-lossless 0 -compression_level 5 -q:v 30 -loop 0 \
-preset default -an -vsync 0 -t 5 ${tempOut}`

      stiker = await new Promise((resolve, reject) => {
        exec(ffmpegCmd, (err) => {
          if (err) {
            if (existsSync(tempIn)) unlinkSync(tempIn)
            return reject('ffmpeg_error')
          }
          const buf = readFileSync(tempOut)
          if (existsSync(tempIn))  unlinkSync(tempIn)
          if (existsSync(tempOut)) unlinkSync(tempOut)
          resolve(buf)
        })
      })
    }

  } catch (e) {
    console.error(e)
    if (e === 'ffmpeg_error')
      return m.reply('⚠️⃝🦅 تـأكـد مـن تـثـبـيـت ffmpeg:\n```pkg install ffmpeg```')
    stiker = false
    await m.react('❌⃝❄')
  } finally {
    if (stiker) {
      await conn.sendMessage(m.chat, { sticker: stiker }, { quoted: m })
      await m.react('✅')
    } else if (stiker === false && !m._replyHandled) {
      m.reply('⚠️⃝🦅 حـدث خـطـأ، تـأكـد مـن إرسـال وسـائـط صـالـحـة.')
    }
  }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//           مـعـلـومـات الأمـر
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
handler.help    = ['ملصق ⃝🦅', 'متحرك ⃝🦅']
handler.tags    = ['sticker ⃝🌙']
handler.command = ['ستيكر', 'ملصق', 's', 'sticker', 'متحرك', 'animated', 'gif']

export default handler

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//           الـدوال الـمـسـاعـدة
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
const isUrl = (text) =>
  text.match(new RegExp(
    /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)(jpe?g|gif|png)/,
    'gi'
  ))

async function createSticker(img, url, packName, authorName, quality) {
  const stickerMetadata = {
    type: 'full',
    pack: packName,
    author: authorName,
    quality: 100
  }
  return new Sticker(img ? img : url, stickerMetadata).toBuffer()
}

async function mp4ToWebp(file, stickerMetadata) {
  const getBase64 = file.toString('base64')
  const Format = {
    file: `data:video/mp4;base64,${getBase64}`,
    processOptions: {
      crop: false,
      startTime: '00:00:00.0',
      endTime: '00:00:7.0',
      loop: 0
    },
    stickerMetadata: { ...stickerMetadata },
    sessionInfo: { WA_VERSION: '2.2106.5' },
    config: { sessionId: 'session', headless: true }
  }

  const res = await fetch('https://sticker-api.openwa.dev/convertMp4BufferToWebpDataUrl', {
    method: 'post',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(Format)
  })

  if (!res.ok) throw 'فـشـل تـحـويـل الـفـيـديـو'
  return Buffer.from((await res.text()).split(';base64,')[1], 'base64')
}