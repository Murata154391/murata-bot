// ════════════════════════════════════════
//   ⚽ MURATA GOAL - أخبار كرة القدم
// ════════════════════════════════════════

import { createRequire } from 'module'
const require = createRequire(import.meta.url)
const axios   = require('axios')
const cheerio = require('cheerio')
const https   = require('https')

const { emitWarning } = process
process.emitWarning = (w, ...a) => {
  if (typeof w === 'string' && w.includes('NODE_TLS_REJECT_UNAUTHORIZED')) return
  return emitWarning(w, ...a)
}
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'

// ── مصادر RSS (25 مصدر) ──
const RSS_SOURCES = [
  // 🏴󠁧󠁢󠁥󠁮󠁧󠁿 الإنجليزي
  { url: 'https://feeds.bbci.co.uk/sport/football/premier-league/rss.xml',        league: 'Premier League', name: 'الدوري الإنجليزي الممتاز', icon: '🏴󠁧󠁢󠁥󠁮󠁧󠁿' },
  { url: 'https://www.skysports.com/rss/12040',                                    league: 'Premier League', name: 'الدوري الإنجليزي الممتاز', icon: '🏴󠁧󠁢󠁥󠁮󠁧󠁿' },
  // 🇪🇸 الإسباني
  { url: 'https://feeds.bbci.co.uk/sport/football/spanish-la-liga/rss.xml',       league: 'La Liga',        name: 'الدوري الإسباني',          icon: '🇪🇸' },
  { url: 'https://www.goal.com/feeds/en/news',                                    league: 'La Liga',        name: 'الدوري الإسباني',          icon: '🇪🇸' },
  // 🇩🇪 الألماني
  { url: 'https://feeds.bbci.co.uk/sport/football/german-bundesliga/rss.xml',     league: 'Bundesliga',     name: 'الدوري الألماني',          icon: '🇩🇪' },
  // 🇮🇹 الإيطالي
  { url: 'https://feeds.bbci.co.uk/sport/football/italian-serie-a/rss.xml',       league: 'Serie A',        name: 'الدوري الإيطالي',          icon: '🇮🇹' },
  // 🇫🇷 الفرنسي
  { url: 'https://feeds.bbci.co.uk/sport/football/french-ligue-one/rss.xml',      league: 'Ligue 1',        name: 'الدوري الفرنسي',           icon: '🇫🇷' },
  // 🌍 أبطال أوروبا
  { url: 'https://feeds.bbci.co.uk/sport/football/europe/rss.xml',                league: 'Champions League', name: 'دوري أبطال أوروبا',      icon: '🏆' },
  { url: 'https://www.skysports.com/rss/12490',                                   league: 'Champions League', name: 'دوري أبطال أوروبا',      icon: '🏆' },
  // ⚽ أخبار عامة
  { url: 'https://www.skysports.com/rss/12040',                                   league: 'Football',       name: 'أخبار كرة القدم',          icon: '⚽' },
  { url: 'https://www.espn.com/espn/rss/soccer/news',                             league: 'ESPN',           name: 'ESPN عربي',                icon: '📺' },
  { url: 'https://www.goal.com/feeds/ar/news',                                    league: 'Goal',           name: 'Goal عربي',                icon: '🎯' },
  { url: 'https://www.filgoal.com/rss',                                           league: 'FilGoal',        name: 'في الجول',                 icon: '🇸🇦' },
  { url: 'https://www.kooora.com/rss',                                            league: 'Kooora',         name: 'كورة',                     icon: '🟢' },
  // 🌍 دوريات إضافية
  { url: 'https://feeds.bbci.co.uk/sport/football/rss.xml',                       league: 'World Football', name: 'كرة القدم العالمية',       icon: '🌍' },
  { url: 'https://www.transfermarkt.com/rss/neuigkeiten/rss/news',                league: 'Transfers',      name: 'سوق الانتقالات',           icon: '🔄' },
]

const httpsAgent = new https.Agent({ rejectUnauthorized: false })

// ── كاش الأخبار (منع التكرار) ──
const _newsCache = {
  articles: [],
  sentIds:  new Set(),
  lastFetch: 0,
  FETCH_INTERVAL: 15 * 60 * 1000, // 15 دقيقة
}

// ── ترجمة ──
const translate = async (text) => {
  try {
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ar&dt=t&q=${encodeURIComponent(text)}`
    const res = await axios.get(url, { timeout: 6000 })
    return res.data[0].map(i => i[0]).join('')
  } catch { return text }
}

// ── جلب الأخبار ──
const fetchNews = async () => {
  const now = Date.now()
  // كاش لـ 15 دقيقة
  if (_newsCache.articles.length > 0 && (now - _newsCache.lastFetch) < _newsCache.FETCH_INTERVAL) {
    return _newsCache.articles
  }

  const all = []
  const seen = new Set()

  await Promise.allSettled(RSS_SOURCES.map(async (src) => {
    try {
      const { data: xml } = await axios.get(src.url, {
        httpsAgent,
        timeout: 8000,
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
      })

      const $ = cheerio.load(xml, { xmlMode: true })

      $('item').each((i, el) => {
        if (i >= 8) return false

        const title = $(el).find('title').text().trim()
        const url   = $(el).find('link').text().trim() || $(el).find('guid').text().trim()
        const pub   = $(el).find('pubDate').text().trim()

        if (!title || !url) return
        const id = Buffer.from(title).toString('base64').slice(0, 20)
        if (seen.has(id)) return
        seen.add(id)

        // الصورة
        let image =
          $(el).find('media\\:thumbnail').attr('url') ||
          $(el).find('media\\:content').attr('url') ||
          $(el).find('enclosure').attr('url') ||
          $(el).find('image > url').text().trim() ||
          null

        if (image?.includes('ichef.bbci.co.uk')) {
          image = image.replace(/\/\d+x\d+\//, '/1024x576/')
        }

        // التاريخ
        let date = 'اليوم', time = '', timestamp = 0
        if (pub) {
          try {
            const d = new Date(pub)
            timestamp = d.getTime()
            date = d.toLocaleDateString('ar-SA', { timeZone: 'Asia/Riyadh', weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })
            time = d.toLocaleTimeString('ar-SA', { timeZone: 'Asia/Riyadh', hour: '2-digit', minute: '2-digit' })
          } catch { date = pub }
        }

        all.push({ id, title, url, image, date, time, timestamp, league: src.league, name: src.name, icon: src.icon })
      })
    } catch { /* تخطي المصدر */ }
  }))

  // ترتيب من الأحدث
  all.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0))

  _newsCache.articles = all
  _newsCache.lastFetch = now
  console.log(`🦅 جول: جلبنا ${all.length} خبر`)
  return all
}

// ── إرسال خبر ──
const sendArticle = async (conn, m, article) => {
  const title = await translate(article.title)

  const caption = `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*
*⃝🦅┆⚡ عـاجـل: صـحـافـة الـمـلاعـب*
*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*

*⃝🔥┆الـحـدث الآن:*
「 ${title} 」

*⃝📅┆الـتـاريـخ:* ${article.date}
*⃝🕐┆الـتـوقـيـت:* ${article.time}
*⃝🏷️┆الـمـصـدر:* ${article.icon} ${article.name}

*⃝🔗┆رابـط الـخـبـر:*
${article.url}

*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*
 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫`

  const contextInfo = {
    forwardedNewsletterMessageInfo: {
      newsletterJid:  '120363423359642420@newsletter',
      newsletterName: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 🦅'
    },
    isForwarded: true,
    forwardingScore: 999
  }

  if (article.image) {
    await conn.sendMessage(m.chat, {
      image:       { url: article.image },
      caption,
      jpegQuality: 95,
      mimetype:    'image/jpeg',
      contextInfo
    }, { quoted: m })
  } else {
    await conn.sendMessage(m.chat, { text: caption, contextInfo }, { quoted: m })
  }

  // حفظ في المرسلة
  _newsCache.sentIds.add(article.id)
  if (_newsCache.sentIds.size > 200) {
    const first = [..._newsCache.sentIds][0]
    _newsCache.sentIds.delete(first)
  }
}

// ══════════════════════════════════════
let handler = async (m, { conn, text, usedPrefix, command }) => {
  const query = text?.trim()

  await m.react('⚽')

  const articles = await fetchNews()

  if (!articles.length) {
    return conn.reply(m.chat,
      `*⃝🦅┆❌ فـشـل جـلـب الأخـبـار حـالـيـاً*\n*⃝🌙┆💡 حـاول مـرة ثـانـيـة*`,
      m
    )
  }

  // ── بحث بكلمة معينة ──
  if (query) {
    const filtered = articles.filter(a =>
      a.title.toLowerCase().includes(query.toLowerCase()) ||
      a.name.includes(query) ||
      a.league.toLowerCase().includes(query.toLowerCase())
    )
    if (!filtered.length) {
      return conn.reply(m.chat,
        `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🦅┆❌ مـا لـقـيـنـا أخـبـار عـن:* 「 ${query} 」\n*⃝🌙┆💡 جـرب: ريال مدريد / برشلونة / مانشستر*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`,
        m
      )
    }
    return sendArticle(conn, m, filtered[0])
  }

  // ── خبر جديد (غير مرسل) ──
  const unsent = articles.filter(a => !_newsCache.sentIds.has(a.id))

  if (!unsent.length) {
    // كل الأخبار أُرسلت، نصفّي الكاش ونرسل الأحدث
    _newsCache.sentIds.clear()
    return sendArticle(conn, m, articles[0])
  }

  await sendArticle(conn, m, unsent[0])
  await m.react('✅')
}

handler.command = /^جول|goal|أخبار كرة|اخبار كرة$/i
export default handler
