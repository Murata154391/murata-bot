import { downloadContentFromMessage, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys'
import { createRequire } from 'module'
const require = createRequire(import.meta.url)
const axios = require('axios')
import { existsSync, readFileSync, writeFileSync, unlinkSync, mkdirSync } from 'fs'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'
import { exec as execCb } from 'child_process'
import { promisify } from 'util'
const exec = promisify(execCb)

const __dirname = dirname(fileURLToPath(import.meta.url))
const savedPath = join(__dirname, '../saved_note.mp4')

global.savedVideoBuffer = global.savedVideoBuffer || null
global.savedVideoUrl    = global.savedVideoUrl    || null

const GROQ_KEY = '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'

const translateGroq = async (text) => {
  try {
    const res = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
      model: 'llama-3.3-70b-versatile',
      max_tokens: 50,
      messages: [
        { role: 'system', content: 'Translate to best English TikTok search query. Return ONLY the query.' },
        { role: 'user',   content: `Translate: "${text}"` }
      ]
    }, {
      headers: { Authorization: `Bearer ${GROQ_KEY}`, 'Content-Type': 'application/json' },
      timeout: 8000
    })
    return res.data?.choices?.[0]?.message?.content?.trim() || text
  } catch { return text }
}

// ── تحويل الفيديو لمربع دائري بـ ffmpeg ──
const makeCircleVideo = async (inputUrl) => {
  const tmpDir = join(__dirname, '../tmp')
  if (!existsSync(tmpDir)) mkdirSync(tmpDir, { recursive: true })

  const outPath = join(tmpDir, `circle_${Date.now()}.mp4`)
  try {
    // تحميل الفيديو أولاً
    const res = await axios.get(inputUrl, {
      responseType: 'arraybuffer',
      timeout: 30000,
      headers: { 'User-Agent': 'Mozilla/5.0' }
    })
    const inPath = join(tmpDir, `in_${Date.now()}.mp4`)
    writeFileSync(inPath, Buffer.from(res.data))

    // تحويل لمربع 480x480
    await exec(`ffmpeg -i "${inPath}" -vf "crop=min(iw\\,ih):min(iw\\,ih),scale=480:480" -c:v libx264 -preset ultrafast -crf 28 -c:a aac -t 59 -movflags +faststart -y "${outPath}"`)

    const result = readFileSync(outPath)
    try { unlinkSync(inPath) } catch {}
    try { unlinkSync(outPath) } catch {}
    return result
  } catch (e) {
    console.log('ffmpeg failed:', e.message)
    try { unlinkSync(outPath) } catch {}
    return null
  }
}

let handler = async (m, { conn, text, usedPrefix }) => {
  const chatId = m.chat
  const input  = text?.trim() || ''

  const quotedMsg = m.message?.extendedTextMessage?.contextInfo?.quotedMessage
  let videoData = quotedMsg && (
    quotedMsg.videoMessage ||
    quotedMsg.viewOnceMessageV2?.message?.videoMessage ||
    quotedMsg.viewOnceMessage?.message?.videoMessage ||
    quotedMsg.viewOnceMessageV2Extension?.message?.videoMessage
  )

  // ── تغيير ──
  if (input === 'تغيير') {
    global.savedVideoBuffer = null
    global.savedVideoUrl    = null
    if (existsSync(savedPath)) unlinkSync(savedPath)
    await m.react('🗑️')
    return conn.reply(chatId, '✅ تم المسح، سيعود البحث من تيك توك.', m)
  }

  // ── حفظ ──
  if (input === 'حفظ') {
    if (!videoData) return conn.reply(chatId, '❌ رد على فيديو أو نوت لحفظه.', m)
    await m.react('💾')
    try {
      const stream = await downloadContentFromMessage(videoData, 'video')
      let buf = Buffer.from([])
      for await (const chunk of stream) buf = Buffer.concat([buf, chunk])
      global.savedVideoBuffer = buf
      global.savedVideoUrl    = null
      writeFileSync(savedPath, buf)
      return conn.reply(chatId, `✅ تم الحفظ! اكتب ${usedPrefix}نوت لإرساله.`, m)
    } catch {
      return conn.reply(chatId, '⚠️ فشل تحميل الفيديو.', m)
    }
  }

  await m.react('🤌🏻')

  try {
    let sendUrl    = null
    let sendBuffer = null

    // 1️⃣ ريبلاي
    if (videoData) {
      const stream = await downloadContentFromMessage(videoData, 'video')
      let buf = Buffer.from([])
      for await (const chunk of stream) buf = Buffer.concat([buf, chunk])
      sendBuffer = buf

    // 2️⃣ محفوظ
    } else if (!input && (global.savedVideoUrl || existsSync(savedPath) || global.savedVideoBuffer)) {
      sendUrl    = global.savedVideoUrl || null
      sendBuffer = !sendUrl ? (existsSync(savedPath) ? readFileSync(savedPath) : global.savedVideoBuffer) : null

    // 3️⃣ بحث تيك توك
    } else {
      const q = await translateGroq(input || 'anime edit 4k')
      console.log('🎬 Search:', q)

      const { data } = await axios.get('https://tikwm.com/api/feed/search', {
        params: { keywords: q, count: 20, region: 'US' },
        timeout: 15000
      })

      const videos = data?.data?.videos?.filter(v => v?.play)
      if (!videos?.length) throw new Error('ما لقينا فيديو، جرب كلمة ثانية')

      const picked = videos[Math.floor(Math.random() * Math.min(videos.length, 10))]
      sendUrl = picked.play
      console.log('🎬 URL:', sendUrl?.substring(0, 80))
    }

    // ── محاولة 1: ptv مباشر ──
    let sent = false
    try {
      if (sendUrl) {
        await conn.sendMessage(chatId, { video: { url: sendUrl }, ptv: true }, { quoted: m })
      } else {
        await conn.sendMessage(chatId, { video: sendBuffer, ptv: true }, { quoted: m })
      }
      sent = true
      console.log('✅ ptv sent')
    } catch (e) {
      console.log('ptv failed:', e.message)
    }

    // ── محاولة 2: viewOnce video ──
    if (!sent) {
      try {
        if (sendUrl) {
          const circleBuffer = await makeCircleVideo(sendUrl)
          if (circleBuffer) {
            const msg = generateWAMessageFromContent(chatId, {
              viewOnceMessage: {
                message: {
                  videoMessage: {
                    url: '',
                    seconds: 10,
                    gifPlayback: false,
                    viewOnce: true,
                    ptv: true
                  }
                }
              }
            }, { userJid: conn.user.jid, quoted: m, upload: conn.waUploadToServer })

            // إرسال بـ sendFile
            await conn.sendFile(chatId, circleBuffer, 'note.mp4', '', m, false, { mimetype: 'video/mp4', ptv: true })
            sent = true
            console.log('✅ sendFile ptv sent')
          }
        }
      } catch (e) {
        console.log('viewOnce failed:', e.message)
      }
    }

    // ── محاولة 3: sendFile عادي بـ ptv ──
    if (!sent) {
      try {
        if (sendUrl) {
          await conn.sendFile(chatId, sendUrl, 'note.mp4', '', m, false, { ptv: true })
        } else {
          await conn.sendFile(chatId, sendBuffer, 'note.mp4', '', m, false, { ptv: true })
        }
        sent = true
        console.log('✅ sendFile sent')
      } catch (e) {
        console.log('sendFile failed:', e.message)
      }
    }

    // ── محاولة 4: video عادي كـ fallback ──
    if (!sent) {
      if (sendUrl) {
        await conn.sendMessage(chatId, { video: { url: sendUrl }, caption: '🎬' }, { quoted: m })
      } else {
        await conn.sendMessage(chatId, { video: sendBuffer, caption: '🎬' }, { quoted: m })
      }
      console.log('✅ fallback video sent')
    }

    await m.react('✅')

  } catch (e) {
    console.error('Note Error:', e.message)
    await m.react('❌')
    return conn.reply(chatId, `⚠️ ${e.message}`, m)
  }
}

handler.command = /^(نوت|vnote)$/i
handler.tags    = ['media']
handler.help    = ['نوت', 'نوت [بحث]', 'نوت حفظ', 'نوت تغيير']
export default handler
