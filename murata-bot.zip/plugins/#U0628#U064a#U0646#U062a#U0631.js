import axios from 'axios'
import { proto, generateWAMessageFromContent, generateWAMessageContent } from '@whiskeysockets/baileys'
import cheerio from 'cheerio'

process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'

// ── جلسات الانتظار ──
const waitingSessions = new Map()

let handler = async (m, { conn, text, args, usedPrefix, command }) => {

    // ── فحص الجلسة أولاً ──
    const session = waitingSessions.get(m.sender)
    if (session && text && !text.startsWith(usedPrefix)) {
        waitingSessions.delete(m.sender)
        const searchText = session.type ? `${session.type} ${text}` : text
        await doPinterestSearch(conn, m, searchText, usedPrefix, fkontak(m, await getGroupName(conn, m)))
        return
    }

    // ── قائمة رئيسية ──
    if (!text) {
        const interactiveMessage = {
            body: { text: `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝📌┆مـرحـبـاً فـي بـحـث Pinterest*\n*⃝🦅┆اختر نوع البحث:*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*` },
            footer: { text: '🦅 𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻' },
            header: { hasMediaAttachment: false },
            nativeFlowMessage: {
                buttons: [{
                    name: 'single_select',
                    buttonParamsJson: JSON.stringify({
                        title: '📌 اختر نوع البحث',
                        sections: [{
                            title: '🔍 أنواع البحث',
                            rows: [
                                { title: '🔍 بحث عام',        description: 'ابحث عن أي شيء',           id: `${usedPrefix}بينتر _عام` },
                                { title: '👤 شخصيات',         description: 'ابحث عن شخص معين',          id: `${usedPrefix}بينتر _شخص` },
                                { title: '👗 أزياء وموضة',    description: 'صور أزياء وستايل',           id: `${usedPrefix}بينتر _ازياء` },
                                { title: '🏠 ديكور وتصميم',   description: 'أفكار ديكور المنزل',          id: `${usedPrefix}بينتر _ديكور` },
                                { title: '🎨 فن وإبداع',      description: 'صور فنية وإبداعية',          id: `${usedPrefix}بينتر _فن` },
                                { title: '⚽ رياضة',          description: 'صور رياضية',                 id: `${usedPrefix}بينتر _رياضة` },
                                { title: '🌿 طبيعة',          description: 'مناظر طبيعية',               id: `${usedPrefix}بينتر _طبيعة` },
                                { title: '⬇️ تحميل رابط',    description: 'حمّل من رابط Pinterest',      id: `${usedPrefix}بينتر _رابط` },
                            ]
                        }]
                    })
                }]
            }
        }
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: { message: { interactiveMessage } }
        }, { userJid: conn.user.jid, quoted: m })
        return conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
    }

    const gName = await getGroupName(conn, m)
    const fk    = fkontak(m, gName)

    try {
        await m.react('🕒')

        // ── اختار نوع ← ينتظر الإدخال ──
        const typeMap = {
            '_عام':    { msg: '🔍 *اكتب ما تريد البحث عنه:*', type: '' },
            '_شخص':   { msg: '👤 *اكتب اسم الشخص الذي تريد البحث عنه:*', type: 'portrait' },
            '_ازياء': { msg: '👗 *اكتب نوع الأزياء التي تريدها:*\nمثال: فستان سهرة / كاجوال / رجالي', type: 'fashion outfit' },
            '_ديكور': { msg: '🏠 *اكتب نوع الديكور الذي تريده:*\nمثال: غرفة نوم / مطبخ / صالة', type: 'home decor interior' },
            '_فن':    { msg: '🎨 *اكتب نوع الفن الذي تريده:*\nمثال: رسم / خط عربي / ديجيتال', type: 'art' },
            '_رياضة': { msg: '⚽ *اكتب اسم اللاعب أو الرياضة:*\nمثال: رونالدو / كرة قدم / تنس', type: 'sports' },
            '_طبيعة': { msg: '🌿 *اكتب نوع الطبيعة التي تريدها:*\nمثال: شلالات / جبال / شاطئ', type: 'nature landscape' },
            '_رابط':  { msg: '⬇️ *أرسل رابط Pinterest للتحميل:*', type: 'link' },
        }

        if (typeMap[text]) {
            const t = typeMap[text]
            waitingSessions.set(m.sender, { type: t.type, isLink: t.type === 'link' })
            setTimeout(() => waitingSessions.delete(m.sender), 60000) // تنتهي بعد دقيقة
            await m.react('⏳')
            return conn.reply(m.chat,
                `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🦅┆${t.msg}*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`, m
            )
        }

        // ── تحميل رابط مباشر ──
        if (text.includes("https://")) {
            const waitMsg = generateWAMessageFromContent(m.chat, {
                extendedTextMessage: {
                    text: `> ⏳ *جـاري تـحـمـيـل الـرابـط...*`,
                    contextInfo: { forwardedNewsletterMessageInfo: { newsletterJid: '120363423359642420@newsletter', newsletterName: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑽𝑬𝑹𝑰𝑭𝑰𝑬𝑫 𝑺𝒀𝑺𝑻𝑬𝑴' }, isForwarded: true, quotedMessage: fk.message, participant: '0@s.whatsapp.net' }
                }
            }, { quoted: fk })
            await conn.relayMessage(m.chat, waitMsg.message, { messageId: waitMsg.key.id })
            let i = await dl(text)
            if (!i?.download) { await m.react('❌'); return conn.reply(m.chat, '> `❌ تعذر تحميل الرابط`', m) }
            let isVideo = i.download.includes(".mp4")
            await conn.sendMessage(m.chat, { [isVideo ? "video" : "image"]: { url: i.download }, caption: i.title || '🦅 𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻' }, { quoted: m })
            return m.react('✅')
        }

        // ── بحث عادي ──
        await doPinterestSearch(conn, m, text, usedPrefix, fk)

    } catch (e) {
        await m.react('✖️')
        await conn.reply(m.chat, '> `⚠️ حدث خطاء`\n\n> `' + e.message + '`', m)
    }
}

// ── دالة الجلسة عند الرد ──
handler.all = async function (m) {
    const session = waitingSessions.get(m.sender)
    if (!session) return
    if (!m.text || m.text.startsWith('.')) return
    waitingSessions.delete(m.sender)

    const conn  = this
    const gName = await getGroupName(conn, m)
    const fk    = fkontak(m, gName)

    try {
        await m.react('🕒')
        if (session.isLink) {
            if (!m.text.includes('http')) return conn.reply(m.chat, '> `❌ أرسل رابط صحيح`', m)
            const i = await dl(m.text)
            if (!i?.download) { await m.react('❌'); return conn.reply(m.chat, '> `❌ تعذر تحميل الرابط`', m) }
            const isVideo = i.download.includes(".mp4")
            await conn.sendMessage(m.chat, { [isVideo ? "video" : "image"]: { url: i.download }, caption: i.title || '🦅 𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻' }, { quoted: m })
            return m.react('✅')
        }
        const searchText = session.type ? `${m.text} ${session.type}` : m.text
        await doPinterestSearch(conn, m, searchText, '.', fk)
    } catch (e) {
        await m.react('✖️')
        await conn.reply(m.chat, '> `⚠️ حدث خطاء`\n\n> `' + e.message + '`', m)
    }
}

// ── دوال مساعدة ──
const getGroupName = async (conn, m) => m.isGroup
    ? (await conn.groupMetadata(m.chat).catch(() => null))?.subject || '𝑴𝑼𝑹𝑨𝑻𝑨'
    : '𝑴𝑼𝑹𝑨𝑻𝑨 𝑺𝒀𝑺𝑻𝑬𝑴'

const fkontak = (m, name) => ({
    key: { fromMe: false, participant: '0@s.whatsapp.net', remoteJid: m.chat },
    message: { contactMessage: { displayName: name, vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:${name}\nORG:𝑴𝑼𝑹𝑨𝑻𝑨 𝑺𝒀𝑺𝑻𝑬𝑴;\nTEL;type=CELL;waid=${m.chat.split('@')[0]}:+${m.chat.split('@')[0]}\nEND:VCARD` } }
})

async function doPinterestSearch(conn, m, text, usedPrefix, fk) {
    const waitMsg = generateWAMessageFromContent(m.chat, {
        extendedTextMessage: {
            text: `> ⏳ *جـاري الـبـحـث فـي Pinterest عـن:* ${text} ...`,
            contextInfo: { forwardedNewsletterMessageInfo: { newsletterJid: '120363423359642420@newsletter', newsletterName: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑽𝑬𝑹𝑰𝑭𝑰𝑬𝑫 𝑺𝒀𝑺𝑻𝑬𝑴' }, isForwarded: true, quotedMessage: fk.message, participant: '0@s.whatsapp.net' }
        }
    }, { quoted: fk })
    await conn.relayMessage(m.chat, waitMsg.message, { messageId: waitMsg.key.id })

    const results = await pins(text)
    if (!results.length) { await m.react('❌'); return conn.reply(m.chat, '> `❌ لم يتم العثور على نتائج لـ "' + text + '"`', m) }

    const pinsToShow = results.slice(0, 6)
    const cards = []
    let counter = 1

    for (let i = 0; i < pinsToShow.length; i++) {
        const pin = pinsToShow[i]
        const info = await getPinInfo(pin)
        try {
            const { imageMessage } = await generateWAMessageContent(
                { image: { url: pin.image_large_url } },
                { upload: conn.waUploadToServer }
            )
            cards.push({
                body:   { text: `🔎 *نتائج البحث عن:* ${text}\n📸 الـصـورة رقـم ${counter++}` },
                header: { hasMediaAttachment: true, imageMessage },
                nativeFlowMessage: {
                    buttons: [
                        { name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: '🔗 فتح الرابط', url: info.link }) },
                        { name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: '📥 تحميل الصورة', url: pin.image_large_url }) }
                    ]
                }
            })
        } catch { continue }
    }

    if (!cards.length) { await m.react('❌'); return conn.reply(m.chat, '> `❌ فشل تحميل الصور`', m) }

    const message = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body:   proto.Message.InteractiveMessage.Body.create({ text: `> 📸 *تـم الـعـثـور عـلـى الـصـور بـواسـطـة مُـوراتـا 🦅*` }),
                    footer: proto.Message.InteractiveMessage.Footer.create({ text: '🦅 𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻' }),
                    header: proto.Message.InteractiveMessage.Header.create({ hasMediaAttachment: false }),
                    carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards }),
                    contextInfo: { forwardedNewsletterMessageInfo: { newsletterJid: '120363423359642420@newsletter', newsletterName: '𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 🦅' }, isForwarded: true, quotedMessage: fk.message, participant: '0@s.whatsapp.net' }
                })
            }
        }
    }, { quoted: fk })
    await conn.relayMessage(m.chat, message.message, { messageId: message.key.id })

    // أزرار بعد النتائج
    const moreMsg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: { message: { interactiveMessage: {
            body: { text: `*⃝🦅┆هـل تـريـد الـمـزيـد؟*` },
            footer: { text: '🦅 𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻' },
            header: { hasMediaAttachment: false },
            nativeFlowMessage: { buttons: [
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🔄 نتائج أخرى', id: `.بينتر ${text}` }) },
                { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🔍 بحث جديد', id: `.بينتر` }) },
            ]}
        }}}
    }, { userJid: conn.user.jid, quoted: m })
    await conn.relayMessage(m.chat, moreMsg.message, { messageId: moreMsg.key.id })
    await m.react('✅')
}

handler.help    = ['بينتر']
handler.command = /^بينتر|بينتريست|بين|pin$/i
handler.tags    = ['صور']

export default handler

async function getPinInfo(imageData) {
    try {
        if (imageData.pinner) return {
            user: `*${imageData.pinner.full_name || imageData.pinner.username}*`,
            title: `*${imageData.title || imageData.grid_title || 'بدون عنوان'}*`,
            board: `*${imageData.board?.name || 'غير محدد'}*`,
            link: imageData.url || `https://pinterest.com/pin/${imageData.id}/`
        }
        return { user: '*غير متوفر*', title: '*بدون عنوان*', board: '*غير محدد*', link: '#' }
    } catch { return { user: '*غير متوفر*', title: '*بدون عنوان*', board: '*غير محدد*', link: '#' } }
}

async function dl(url) {
    try {
        let res = await axios.get(url, { headers: { "User-Agent": "Mozilla/5.0" } }).catch(e => e.response)
        let $ = cheerio.load(res.data)
        let tag = $('script[data-test-id="video-snippet"]')
        if (tag.length) { let r = JSON.parse(tag.text()); return { title: r.name, download: r.contentUrl } }
        let json = JSON.parse($("script[data-relay-response='true']").eq(0).text())
        let r = json.response.data["v3GetPinQuery"].data
        return { title: r.title, download: r.imageLargeUrl }
    } catch { return { msg: "حدث خطأ" } }
}

const pins = async (judul) => {
    const link = `https://id.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${encodeURIComponent(judul)}%26rs%3Dtyped&data=%7B%22options%22%3A%7B%22applied_unified_filters%22%3Anull%2C%22appliedProductFilters%22%3A%22---%22%2C%22article%22%3Anull%2C%22auto_correction_disabled%22%3Afalse%2C%22corpus%22%3Anull%2C%22customized_rerank_type%22%3Anull%2C%22domains%22%3Anull%2C%22dynamicPageSizeExpGroup%22%3A%22control%22%2C%22filters%22%3Anull%2C%22journey_depth%22%3Anull%2C%22page_size%22%3Anull%2C%22price_max%22%3Anull%2C%22price_min%22%3Anull%2C%22query_pin_sigs%22%3Anull%2C%22query%22%3A%22${encodeURIComponent(judul)}%22%2C%22redux_normalize_feed%22%3Atrue%2C%22request_params%22%3Anull%2C%22rs%22%3A%22typed%22%2C%22scope%22%3A%22pins%22%2C%22selected_one_bar_modules%22%3Anull%2C%22seoDrawerEnabled%22%3Afalse%2C%22source_id%22%3Anull%2C%22source_module_id%22%3Anull%2C%22source_url%22%3A%22%2Fsearch%2Fpins%2F%3Fq%3D${encodeURIComponent(judul)}%26rs%3Dtyped%22%2C%22top_pin_id%22%3Anull%2C%22top_pin_ids%22%3Anull%7D%2C%22context%22%3A%7B%7D%7D`
    try {
        const res = await axios.get(link, { headers: { 'accept': 'application/json, text/javascript, */*; q=0.01', 'referer': 'https://id.pinterest.com/', 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36', 'x-app-version': 'c056fb7', 'x-pinterest-appstate': 'active', 'x-pinterest-pws-handler': 'www/index.js', 'x-pinterest-source-url': '/', 'x-requested-with': 'XMLHttpRequest' } })
        if (res.data?.resource_response?.data?.results) {
            return res.data.resource_response.data.results.filter(item => item.images).map(item => ({
                image_large_url: item.images.orig?.url || null,
                image_medium_url: item.images['564x']?.url || null,
                pinner: item.pinner, title: item.title, board: item.board, id: item.id, url: item.url
            }))
        }
        return []
    } catch (e) { console.error('Pinterest Error:', e.message); return [] }
}