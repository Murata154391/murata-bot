import { useMultiFileAuthState, DisconnectReason, makeCacheableSignalKeyStore, fetchLatestBaileysVersion, jidNormalizedUser } from "@whiskeysockets/baileys"
import qrcode from "qrcode"
import NodeCache from "node-cache"
import fs from "fs"
import path from "path"
import pino from 'pino'
import chalk from 'chalk'
import * as ws from 'ws'
const { exec } = await import('child_process')
import { makeWASocket } from '../lib/simple.js'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// ══════════ ملف بيانات البوتات الفرعية ══════════
const SUBS_FILE = path.join('./src/database/', 'subbotsData.json')

function loadSubsData() {
    try {
        if (!fs.existsSync(SUBS_FILE)) return {}
        return JSON.parse(fs.readFileSync(SUBS_FILE, 'utf-8'))
    } catch { return {} }
}

function saveSubsData(data) {
    try {
        fs.writeFileSync(SUBS_FILE, JSON.stringify(data, null, 2))
    } catch (e) {
        console.error('[SubBots] فشل حفظ البيانات:', e.message)
    }
}

function addSubBot(jid, info) {
    const data = loadSubsData()
    data[jid] = { ...info, connectedAt: new Date().toISOString() }
    saveSubsData(data)
}

function removeSubBot(jid) {
    const data = loadSubsData()
    if (data[jid]) {
        delete data[jid]
        saveSubsData(data)
        console.log(chalk.bold.yellow(`[SubBots] تم حذف بيانات ${jid} من subbotsData.json`))
    }
}

// ══════════ ثوابت ══════════
const NEWSLETTER_JID  = '120363423359642420@newsletter'
const NEWSLETTER_NAME = '𝑴𝑼𝑹𝑨𝑻𝑨  𝑽𝑬𝑹𝑰𝑭𝑰𝑬𝑫  𝑺𝒀𝑺𝑻𝑬𝑴'
const CHANNEL_URL     = 'https://whatsapp.com/channel/0029Vb76oO3BA1euG0eIvA3a'

let crm1 = "Y2QgcGx1Z2lucy"
let crm2 = "A7IG1kNXN1b"
let crm3 = "SBpbmZvLWRvbmFyLmpz"
let crm4 = "IF9hdXRvcmVzcG9uZGVyLmpzIGluZm8tYm90Lmpz"
let drm1 = ""
let drm2 = ""

let rtx = "*❀ سيرفر البوت • وضع QR*\n\n✰ باستخدام هاتف آخر أو على الكمبيوتر، امسح رمز QR هذا ضوئيًا لتصبح *بوت فرعي* مؤقت.\n\n\`1\` » انقر على النقاط الثلاث في الزاوية اليمنى العليا\n\n\`2\` » انقر على الأجهزة المرتبطة\n\n\`3\` » امسح رمز QR هذا ضوئيًا لتسجيل الدخول باستخدام البوت\n\n✧ ينتهي صلاحية رمز QR هذا بعد 45 ثانية!"

const yukiJBOptions = {}

if (global.conns instanceof Array) console.log()
else global.conns = []

function isSubBotConnected(jid) {
    return global.conns.some(sock => sock?.user?.jid && sock.user.jid.split("@")[0] === jid.split("@")[0])
}

let handler = async (m, { conn, args, usedPrefix, command, isOwner }) => {
    if (!globalThis.db.data.settings[conn.user.jid].jadibotmd) return m.reply(`ꕥ الأمر *${command}* معطل مؤقتًا.`)
    let time = global.db.data.users[m.sender].Subs + 120000
    if (new Date - global.db.data.users[m.sender].Subs < 120000) return conn.reply(m.chat, `ꕥ يجب الانتظار ${msToTime(time - new Date())} لربط *بوت فرعي* مرة أخرى.`, m)
    let socklimit = global.conns.filter(sock => sock?.user).length
    if (socklimit >= 200) return m.reply(`ꕥ لم يتم العثور على مساحات متاحة لـ *البوتات الفرعية*.`)

    let mentionedJid = await m.mentionedJid
    let who = mentionedJid && mentionedJid[0] ? mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
    let id = `${who.split`@`[0]}`
    let pathYukiJadiBot = path.join(`./${jadi}/`, id)
    if (!fs.existsSync(pathYukiJadiBot)) fs.mkdirSync(pathYukiJadiBot, { recursive: true })

    yukiJBOptions.pathYukiJadiBot = pathYukiJadiBot
    yukiJBOptions.m = m
    yukiJBOptions.conn = conn
    yukiJBOptions.args = args
    yukiJBOptions.usedPrefix = usedPrefix
    yukiJBOptions.command = command
    yukiJBOptions.fromCommand = true
    yukiJadiBot(yukiJBOptions)
    global.db.data.users[m.sender].Subs = new Date * 1
}

handler.help = ['qr', 'code', 'تنصيب']
handler.tags = ['serbot']
handler.command = ['qr', 'code', 'تنصيب']
export default handler

export async function yukiJadiBot(options) {
    let { pathYukiJadiBot, m, conn, args, usedPrefix, command } = options

    if (command === 'code' || command === 'تنصيب') {
        command = 'qr'
        args.unshift('code')
    }

    const mcode = args[0] && /(--code|code)/.test(args[0].trim()) ? true : args[1] && /(--code|code)/.test(args[1].trim()) ? true : false
    let txtCode, codeBot, txtQR

    if (mcode) {
        args[0] = args[0].replace(/^--code$|^code$/, "").trim()
        if (args[1]) args[1] = args[1].replace(/^--code$|^code$/, "").trim()
        if (args[0] == "") args[0] = undefined
    }

    const pathCreds = path.join(pathYukiJadiBot, "creds.json")
    if (!fs.existsSync(pathYukiJadiBot)) fs.mkdirSync(pathYukiJadiBot, { recursive: true })

    try {
        args[0] && args[0] != undefined ? fs.writeFileSync(pathCreds, JSON.stringify(JSON.parse(Buffer.from(args[0], "base64").toString("utf-8")), null, '\t')) : ""
    } catch {
        conn.reply(m.chat, `ꕥ استخدم الأمر بشكل صحيح » ${usedPrefix + command}`, m)
        return
    }

    const comb = Buffer.from(crm1 + crm2 + crm3 + crm4, "base64")
    exec(comb.toString("utf-8"), async (err, stdout, stderr) => {
        let { version } = await fetchLatestBaileysVersion()
        const msgRetry = (MessageRetryMap) => { }
        const msgRetryCache = new NodeCache()
        const { state, saveCreds } = await useMultiFileAuthState(pathYukiJadiBot)

        // ✅ نفس groupCache للأصلي — كل فرعي عنده cache خاص فيه
        const subGroupCache = {}

        const connectionOptions = {
            logger: pino({ level: "fatal" }),
            printQRInTerminal: false,
            auth: { creds: state.creds, keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' })) },
            msgRetry,
            msgRetryCache,
            browser: ['Ubuntu', 'Chrome', '110.0.1587.56'], // ✅ أخف من Firefox
            version,
            generateHighQualityLinkPreview: false, // ✅ أسرع — ما يحتاجها الفرعي
            defaultQueryTimeoutMs: undefined, // ✅ بدون timeout يعلق
            // ✅ cache الجروبات — نفس تحسين الأصلي
            cachedGroupMetadata: async (jid) => subGroupCache[jid] || null,
            getMessage: async (key) => {
                return { conversation: '' }
            }
        }

        let sock = makeWASocket(connectionOptions)
        sock.isInit = false
        let isInit = true
        const botJid = path.basename(pathYukiJadiBot)

        // ✅ تحديث cache الجروبات للفرعي
        sock.ev.on('groups.update', (updates) => {
            for (const update of updates) {
                if (subGroupCache[update.id]) Object.assign(subGroupCache[update.id], update)
            }
        })
        sock.ev.on('group-participants.update', async ({ id }) => {
            try { subGroupCache[id] = await sock.groupMetadata(id).catch(() => null) } catch {}
        })

        // تنظيف تلقائي لو ما اتصل خلال 60 ثانية
        setTimeout(async () => {
            if (!sock.user) {
                try { fs.rmSync(pathYukiJadiBot, { recursive: true, force: true }) } catch {}
                try { sock.ws?.close() } catch {}
                sock.ev.removeAllListeners()
                let i = global.conns.indexOf(sock)
                if (i >= 0) global.conns.splice(i, 1)
                removeSubBot(botJid)
                console.log(chalk.bold.yellow(`[SubBots] تم حذف جلسة ${botJid} بسبب انتهاء الوقت`))
            }
        }, 60000)

        async function connectionUpdate(update) {
            const { connection, lastDisconnect, isNewLogin, qr } = update

            if (isNewLogin) sock.isInit = false

            if (qr && !mcode) {
                if (m?.chat) {
                    txtQR = await conn.sendMessage(m.chat, { image: await qrcode.toBuffer(qr, { scale: 8 }), caption: rtx.trim() }, { quoted: m })
                }
                if (txtQR?.key) setTimeout(() => { conn.sendMessage(m.chat, { delete: txtQR.key }) }, 30000)
                return
            }

            if (qr && mcode) {
                let secret = await sock.requestPairingCode((m.sender.split`@`[0]))
                secret = secret.match(/.{1,4}/g)?.join("-")

                const installationGuide =
                    `*🛠️ دليل تنصيب 𝑴𝑼𝑹𝑨𝑻𝑨 🛠️*\n\n` +
                    `مرحبًا بك في عائلة 𝑴𝑼𝑹𝑨𝑻𝑨!\n\n` +
                    `📱 *الخطوات:*\n` +
                    `تأكد أنه لا يوجد أجهزة مرتبطة سابقاً\n` +
                    `1. سيظهر الرمز المكون من 8 أرقام\n` +
                    `2. اضغط عليه ضغطاً مطولاً وانسخه\n` +
                    `3. اذهب لإشعار واتساب في الأعلى\n` +
                    `4. اضغط تأكيد والصق الرمز\n\n` +
                    `⚡ *متطلبات التشغيل:*\n` +
                    `- واتساب ماسنجر\n` +
                    `- اتصال إنترنت مستقر\n\n` +
                    `📢 *قناة 𝑴𝑼𝑹𝑨𝑻𝑨:*\n` +
                    `${CHANNEL_URL}\n\n` +
                    `🎯 *ملاحظة:* لتجنب الحظر اجعل الرقم خاصاً بالبوت\n\n` +
                    `*مع تحيات، 𝑴𝑼𝑹𝑨𝑻𝑨 👑*`

                await conn.sendMessage(m.chat, {
                    image: { url: 'https://files.catbox.moe/lyug34.jpg' },
                    caption: installationGuide,
                    contextInfo: {
                        forwardedNewsletterMessageInfo: { newsletterJid: NEWSLETTER_JID, newsletterName: NEWSLETTER_NAME },
                        isForwarded: true
                    }
                }, { quoted: m })

                codeBot = await m.reply(`\`\`\`${secret}\`\`\``)
                if (codeBot?.key) setTimeout(() => { conn.sendMessage(m.chat, { delete: codeBot.key }) }, 30000)
            }

            const reason = lastDisconnect?.error?.output?.statusCode || lastDisconnect?.error?.output?.payload?.statusCode

            if (connection === 'close') {
                const msgs = {
                    428: `تم إغلاق الاتصال بشكل غير متوقع`,
                    408: `فقد الاتصال أو انتهت صلاحيته`,
                    440: `تم استبدال الاتصال بجلسة نشطة أخرى`,
                    500: `فقد الاتصال - جاري حذف البيانات`,
                    515: `إعادة تشغيل تلقائي`,
                    403: `تم إغلاق الجلسة أو الحساب`
                }

                console.log(chalk.bold.magentaBright(`[SubBots] +${botJid}: ${msgs[reason] || 'انقطع الاتصال'} (${reason})`))

                if (reason == 405 || reason == 401 || reason == 403) {
                    removeSubBot(botJid)
                    try { fs.rmdirSync(pathYukiJadiBot, { recursive: true }) } catch {}
                    if (options.fromCommand) m?.chat ? await conn.sendMessage(m.chat, { text: '⚠︎ جلسة معلقة.\n\n> يرجى المحاولة مرة أخرى.' }, { quoted: m || null }) : ""
                    return
                }

                if ([428, 408, 500, 515].includes(reason)) await creloadHandler(true).catch(console.error)
                if (reason === 440 && options.fromCommand) m?.chat ? await conn.sendMessage(m.chat, { text: '⚠︎ جلسة نشطة أخرى موجودة. يرجى حذف الجلسة القديمة.' }, { quoted: m || null }) : ""
            }

            if (global.db.data == null) loadDatabase()

            if (connection === 'open') {
                if (!global.db.data?.users) loadDatabase()
                await joinChannels(sock)

                const userName = sock.authState.creds.me?.name || 'مجهول'
                const userJid  = sock.authState.creds.me?.jid || `${botJid}@s.whatsapp.net`

                addSubBot(botJid, {
                    name: userName,
                    jid: userJid,
                    owner: m?.sender || 'unknown'
                })

                console.log(chalk.bold.cyanBright(`[SubBots] ${userName} (+${botJid}) متصل ✅`))

                sock.isInit = true
                global.conns.push(sock)

                m?.chat ? await conn.sendMessage(m.chat, {
                    text: isSubBotConnected(m.sender)
                        ? `@${m.sender.split('@')[0]}, أنت متصل بالفعل، جاري قراءة الرسائل الواردة...`
                        : `❀ تم ربط *بوت فرعي* جديد! [@${m.sender.split('@')[0]}]\n\n> يمكنك رؤية معلومات البوت باستخدام الأمر *#infobot*`,
                    mentions: [m.sender]
                }, { quoted: m }) : ''
            }
        }

        // ✅ تنظيف الجلسات الميتة كل دقيقة
        setInterval(async () => {
            if (!sock.user) {
                try { sock.ws.close() } catch {}
                sock.ev.removeAllListeners()
                let i = global.conns.indexOf(sock)
                if (i < 0) return
                global.conns.splice(i, 1)
                removeSubBot(botJid)
            }
        }, 60000)

        let handler = await import('../handler.js')
        let creloadHandler = async function (restatConn) {
            try {
                const Handler = await import(`../handler.js?update=${Date.now()}`).catch(console.error)
                if (Object.keys(Handler || {}).length) handler = Handler
            } catch (e) {
                console.error('⚠︎ خطأ:', e)
            }

            if (restatConn) {
                const oldChats = sock.chats
                try { sock.ws.close() } catch {}
                sock.ev.removeAllListeners()
                sock = makeWASocket(connectionOptions, { chats: oldChats })
                isInit = true
            }

            if (!isInit) {
                sock.ev.off("messages.upsert", sock.handler)
                sock.ev.off("connection.update", sock.connectionUpdate)
                sock.ev.off('creds.update', sock.credsUpdate)
            }

            sock.handler = handler.handler.bind(sock)
            sock.connectionUpdate = connectionUpdate.bind(sock)
            sock.credsUpdate = saveCreds.bind(sock, true)

            sock.ev.on("messages.upsert", sock.handler)
            sock.ev.on("connection.update", sock.connectionUpdate)
            sock.ev.on("creds.update", sock.credsUpdate)

            isInit = false
            return true
        }

        creloadHandler(false)
    })
}

function msToTime(duration) {
    let seconds = Math.floor((duration / 1000) % 60)
    let minutes = Math.floor((duration / (1000 * 60)) % 60)
    minutes = (minutes < 10) ? '0' + minutes : minutes
    seconds = (seconds < 10) ? '0' + seconds : seconds
    return minutes + ' دقيقة و ' + seconds + ' ثانية'
}

async function joinChannels(conn) {
    const MAIN_CHANNEL = '120363425747059340@newsletter'
    try {
        await conn.newsletterFollow(MAIN_CHANNEL).catch(() => {})
        if (global.ch && typeof global.ch === 'object') {
            for (const channelId of Object.values(global.ch)) {
                if (!channelId || channelId === MAIN_CHANNEL) continue
                await conn.newsletterFollow(channelId).catch(() => {})
            }
        }
    } catch {}
}

export { yukiJadiBot as mashJadiBot }
