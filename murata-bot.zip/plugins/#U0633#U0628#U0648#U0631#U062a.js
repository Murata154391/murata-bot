import { generateWAMessageFromContent } from '@whiskeysockets/baileys'
import { createRequire } from 'module'
const require = createRequire(import.meta.url)
const axios = require('axios')

const GROQ_API_KEY = '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'

const { emitWarning } = process
process.emitWarning = (warning, ...args) => {
  if (typeof warning === 'string' && warning.includes('NODE_TLS_REJECT_UNAUTHORIZED')) return
  return emitWarning(warning, ...args)
}
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'

// ══════════════════════════════════════
//   🦅 MURATA SPORT - EPIC EDITION
// ══════════════════════════════════════

const SEARCHES = {
  عشوائي:    'football amazing goal',
  افضل:      'best football goals ever',
  اليوم:     'football goal today 2025',
  ابطال:     'champions league goal',
  'ركلة حرة': 'free kick goal football',
  اخير:      'last minute goal football',
  مهارات:    'football skills and goals',
  فولي:      'volley goal football',
}

const sendList = (conn, chat, m, bodyText, title, sections) => {
  const interactiveMessage = {
    body: { text: bodyText },
    footer: { text: '🦅 𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻' },
    header: { hasMediaAttachment: false },
    nativeFlowMessage: {
      buttons: [{
        name: 'single_select',
        buttonParamsJson: JSON.stringify({ title, sections })
      }]
    }
  }
  const msg = generateWAMessageFromContent(chat, {
    viewOnceMessage: { message: { interactiveMessage } }
  }, { userJid: conn.user.jid, quoted: m })
  return conn.relayMessage(chat, msg.message, { messageId: msg.key.id })
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const query = text?.trim()

  // ── القائمة الرئيسية ──
  if (!query) {
    const body = `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*
*⃝🦅┆⚽ مـرحـبـاً بـك فـي بـوت الأهـداف*
*⃝🌙┆اختر نوع الهدف من القائمة أدناه*
*⃝🦅┆أو اكتب: ${usedPrefix}سبورت هدف رونالدو*
*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`

    return sendList(conn, m.chat, m, body, '⚽ اختر الآن', [
      {
        title: '🔥 أنواع الأهداف',
        rows: [
          { title: '🎲 هدف عشوائي',         description: 'هدف مفاجأة من أي مباراة',   id: `${usedPrefix}سبورت عشوائي` },
          { title: '🏆 أفضل الأهداف',        description: 'أجمل أهداف كرة القدم',       id: `${usedPrefix}سبورت افضل` },
          { title: '📅 أهداف اليوم',         description: 'أحدث الأهداف اليوم',         id: `${usedPrefix}سبورت اليوم` },
          { title: '🌍 دوري أبطال أوروبا',   description: 'أهداف UCL الأسطورية',        id: `${usedPrefix}سبورت ابطال` },
        ]
      },
      {
        title: '⚡ أنواع خاصة',
        rows: [
          { title: '🍃 ركلة حرة',            description: 'أجمل الركلات الحرة',         id: `${usedPrefix}سبورت ركلة حرة` },
          { title: '⏱️ هدف اللحظة الأخيرة', description: 'أهداف القلب القوي',           id: `${usedPrefix}سبورت اخير` },
          { title: '🎪 مهارات وأهداف',       description: 'تمريرات ومهارات + أهداف',    id: `${usedPrefix}سبورت مهارات` },
          { title: '🌀 هدف فولي',            description: 'أهداف الفولي الخرافية',       id: `${usedPrefix}سبورت فولي` },
        ]
      }
    ])
  }

  // ── ريأكت + انتظار ──
  await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } })
  await conn.reply(
    m.chat,
    `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🦅┆🔍 جـاري الـبـحـث...*\n*⃝🌙┆「 ${query} 」*\n*⃝🦅┆⏳ ثـوانـي...*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`,
    m
  )

  // ── البحث ──
  let searchQuery = SEARCHES[query] || `football goal ${query}`

  if (!SEARCHES[query]) {
    try {
      const groqRes = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
        model: 'llama-3.3-70b-versatile',
        max_tokens: 60,
        messages: [{
          role: 'system',
          content: `You are a football search expert. Convert Arabic football queries to best English TikTok search to find raw goal footage. NO montage, NO edit, NO compilation. Short and direct.`
        }, {
          role: 'user',
          content: `Convert to English football TikTok search: "${query}"`
        }]
      }, {
        headers: { 'Authorization': `Bearer ${GROQ_API_KEY}`, 'Content-Type': 'application/json' },
        timeout: 8000
      })
      const translated = groqRes.data?.choices?.[0]?.message?.content?.trim()
      if (translated) searchQuery = translated
    } catch (e) { console.log('Groq failed:', e.message) }
  }

  // ── TikTok ──
  try {
    const { data } = await axios.get('https://tikwm.com/api/feed/search', {
      params: { keywords: searchQuery, count: 20 },
      timeout: 20000
    })

    const videos = data?.data?.videos
    if (!Array.isArray(videos) || videos.length === 0) {
      await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
      return conn.reply(
        m.chat,
        `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*\n*⃝🦅┆❌ مـا لـقـيـنـا نـتـائـج لـ:*\n*⃝🌙┆「 ${query} 」*\n*⃝🦅┆💡 جـرب كـلـمـات ثـانـيـة*\n*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*`,
        m
      )
    }

    const pool  = videos.slice(0, 5)
    const video = pool[Math.floor(Math.random() * pool.length)]
    if (!video?.play) return conn.reply(m.chat, `*⃝🦅┆⚠️ تـعـذر جـلـب الـفـيـديـو، حـاول مـرة ثـانـيـة*`, m)

    const caption = `*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*
*⃝🦅┆✅ تـم الـعـثـور عـلـى الـهـدف*
*⃝🌙┆🎯 طـلـبـك: ${query}*
*⃝🦅┆🔗 الـمـصـدر: X.com/marfwe*
*꒷꒦꒷꒷꒦꒷꒷꒦꒷꒷𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  ꒷꒦꒷꒦꒷꒷꒷꒦꒷*
 ۫ ִᗀᩙᰰ ̼𝆬🌙̸〫 ᮭ࣪࣪ ⸼۫  𝑴𝑼𝑹𝑨𝑻𝑨 𝑩𝑶𝑻 𝅄 ۫ ִᗀᩙᰰ ̼𝆬🌙`

    await conn.sendMessage(m.chat, {
      video: { url: video.play },
      mimetype: 'video/mp4',
      caption,
      mentions: [m.sender]
    }, { quoted: m })

    // قائمة بعد الفيديو
    await sendList(conn, m.chat, m, '🎯 *شو تبي الحين؟*', '🔥 خيارات', [{
      title: '⚡ خيارات سريعة',
      rows: [
        { title: '🔄 هدف آخر نفس البحث', description: query,       id: `${usedPrefix}سبورت ${query}` },
        { title: '🎲 هدف عشوائي',         description: 'فاجئني!',   id: `${usedPrefix}سبورت عشوائي` },
        { title: '🏠 القائمة الرئيسية',   description: 'رجوع',      id: `${usedPrefix}سبورت` },
      ]
    }])

    await conn.sendMessage(m.chat, { react: { text: '🔥', key: m.key } })

  } catch (err) {
    console.error('سبورت error:', err?.message)
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
    return conn.reply(m.chat, `*⃝🦅┆⚠️ حـدث خـطـأ، حـاول مـرة ثـانـيـة*`, m)
  }
}

handler.command = /^سبورت|اهداف|أهداف|sport$/i
handler.register = false
export default handler