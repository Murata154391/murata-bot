let handler = async (m, { conn }) => {

  const developerNumber = '201030943917@s.whatsapp.net'
  const senderNum = m.sender.split('@')[0]
  const devNum = developerNumber.split('@')[0]
  if (senderNum !== devNum && !m.fromMe) return

  console.log('chat:', m.chat, 'sender:', m.sender, 'fromMe:', m.fromMe)

  const reply = `*نعم يا مطوري 𝑴𝑼𝑹𝑨𝑻𝑨 😗*`

  await conn.sendMessage(m.chat, {
    text: reply,
    contextInfo: {
      mentions: [m.sender],
      forwardingScore: 999,
      externalAdReply: {
        title: '✧⸙murata⸙✧',
        body: '🧠 بــﹻ۬ۦٕ٘۬ـــوت مــوراتا ڪـآرف',
        mediaType: 1,
        thumbnailUrl: 'https://files.catbox.moe/bhukq3.jpg'
      }
    }
  }, { quoted: m })

}

handler.customPrefix = /(بوتي)/i
handler.command = new RegExp
handler.rowner = false

export default handler