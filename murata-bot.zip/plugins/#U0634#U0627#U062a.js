let handler = async (m, { conn, text }) => {

    if (!text) return m.reply(
`⏱️ استخدم بالطريقة:
شات فتح 10ث
شات قفل 1د

الثواني = ث
الدقائق = د
الساعات = س`
    )

    let args = text.split(" ")
    if (args.length < 2) return m.reply("⚠️ صيغة الأمر غلط\nمثال: شات فتح 15ث")

    let mode = args[0] // فتح أو قفل
    let time = args[1] // الوقت مثل 10ث

    if (!/فتح|قفل/.test(mode)) return m.reply("⚠️ لازم تقول (فتح) أو (قفل)")

    let extract = time.match(/(\d+)(ث|د|س)/i)
    if (!extract) return m.reply("⚠️ صيغة الوقت غلط — مثال: 10ث | 1د | 2س")

    let num = parseInt(extract[1])
    let unit = extract[2]

    let ms = 0
    if (unit === "ث") ms = num * 1000
    if (unit === "د") ms = num * 60000
    if (unit === "س") ms = num * 3600000

    // تنفيذ الإجراء الآن
    await conn.groupSettingUpdate(
        m.chat,
        mode === "فتح" ? "not_announcement" : "announcement"
    )

    m.reply(`✅ تم *${mode} الشات* لمدة: ${num}${unit}\n⏳ سيتم التغيير تلقائياً بعد انتهاء الوقت.`)

    // استرجاع الحالة بعد الوقت المحدد
    setTimeout(async () => {
        let back = mode === "فتح" ? "قفل" : "فتح"
        await conn.groupSettingUpdate(
            m.chat,
            mode === "فتح" ? "announcement" : "not_announcement"
        )
        conn.sendMessage(m.chat, { text: `⏱️ انتهى الوقت!\nتم الآن: *${back} الشات* تلقائياً.` })
    }, ms)

}

handler.help = ['شات فتح <وقت>', 'شات قفل <وقت>']
handler.tags = ['group']
handler.command = /^شات$/i
handler.group = true

export default handler